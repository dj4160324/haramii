#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 source/scripts/build.py
cp source/dist/index.html index.html
