"""Build from the retained, released v0.12.0 baseline without losing newer policies."""
from pathlib import Path
from rest_balance_patch import apply
from continuity_patch import apply as continuity
from recovery_patch import apply as recovery

root = Path(__file__).resolve().parents[1]
source = (root / 'src/base-v0120.html').read_text()
result = recovery(continuity(apply(source, root), root), root)
(root / 'dist').mkdir(exist_ok=True)
(root / 'dist/index.html').write_text(result)
print(f'Built v0.12.4-recovery.2: {len(result.encode())} bytes')
