def apply(source, root):
    s = source
    def replace(old, new, count=1):
        nonlocal s
        if s.count(old) != count:
            raise RuntimeError(f'Continuity expected {count}, got {s.count(old)}: {old[:100]}')
        s = s.replace(old, new)
    s=s.replace('v0.12.1','v0.12.2')
    replace('    window.koreanHolidays = {', (root/'src/continuity.js').read_text()+'\n    window.koreanHolidays = {')
    replace('input.restSpreadPolicy=2;', 'input.restSpreadPolicy=2;input.continuityPolicy=1;')
    replace("if(input.restSpreadPolicy!==undefined&&input.restSpreadPolicy!==2)", "if(input.continuityPolicy!==undefined&&(input.continuityPolicy!==1||input.restSpreadPolicy!==2||input.weekendPolicy!==2))throw Error('누적 주말·야간 분산 기준을 확인해 주세요.');\n    if(input.restSpreadPolicy!==undefined&&input.restSpreadPolicy!==2)")
    replace("let cost=sh==='N'?legacy.nightCost(x,s,row,d)*4:0;", "let cost=sh==='N'?legacy.nightCost(x,s,row,d)*4:0;if(RosterContinuity.enabled(x))cost+=Math.max(0,RosterContinuity.nightDelta(x,s,row,d,sh))*1200;")
    replace("if(!RosterWeekend.notWorseLimit(nx,m,next))return note(ids,'주말 OFF 최대 차이');", "if(!RosterWeekend.notWorseLimit(nx,m,next)||!RosterContinuity.weekendSafe(nx,m,next))return note(ids,'누적 주말 OFF 균형');")
    replace("const next=needs?await improve(x,current,{...options,maxMs:3500,maxChecks:1800}):current;\n    return checked(x,next,next.spread?.status||'checked');", "let next=needs?await improve(x,current,{...options,maxMs:3500,maxChecks:1800}):current;\n    next=await RosterContinuity.improve(x,next,options);\n    return checked(x,next,next.spread?.status||'checked');")
    # Reconstructing ordinary OFF must never create a new N-density event.
    replace('if(spread&&!RosterSpread.notWorse(input,matrix,next,changed))return false;', 'if(!RosterContinuity.nightSafe(input,matrix,next,changed))return false;\n    if(spread&&!RosterSpread.notWorse(input,matrix,next,changed))return false;')
    replace('if(!RosterWeekend.notWorseLimit(input,matrix,next))return false;', 'if(!RosterWeekend.notWorseLimit(input,matrix,next)||!RosterContinuity.weekendSafe(input,matrix,next))return false;')
    # A later workload-count repair must not undo the safe N distribution.
    replace("if(RosterSpread.modern(input)&&(!RosterSpread.preservesRequests(input,current.matrix,matrix,[i,j])", "if(!RosterContinuity.nightSafe(input,current.matrix,matrix,[i,j]))continue;\n              if(RosterSpread.modern(input)&&(!RosterSpread.preservesRequests(input,current.matrix,matrix,[i,j])")
    replace("if(RosterSpread.modern(input)&&(!RosterSpread.preservesRequests(input,current.matrix,matrix,changes.map(c=>c[0]))", "if(!RosterContinuity.nightSafe(input,current.matrix,matrix,changes.map(c=>c[0])))return;\n        if(RosterSpread.modern(input)&&(!RosterSpread.preservesRequests(input,current.matrix,matrix,changes.map(c=>c[0]))")
    # Fine rest-spacing ties cannot override past weekend deficits outright.
    old="RosterSpread.assignmentCost(input,s,m[i],a.d,'D')-RosterSpread.assignmentCost(input,s,m[i],b.d,'D')||a.weekendCost-b.weekendCost||a.tie-b.tie"
    new="RosterContinuity.enabled(input)?(RosterSpread.assignmentCost(input,s,m[i],a.d,'D')+RosterWeekend.workCost(input,m,i,a.d,weekendGuide))-(RosterSpread.assignmentCost(input,s,m[i],b.d,'D')+RosterWeekend.workCost(input,m,i,b.d,weekendGuide))||a.tie-b.tie:("+old+")"
    replace(old,new)
    replace("if(!modern(x)||!weekend(x.dates[d])||!plan)return 0;\n    const rest=", "if(!modern(x)||!weekend(x.dates[d])||!plan)return 0;\n    if(RosterContinuity.enabled(x))return RosterContinuity.workCost(x,m,i,d,plan);\n    const rest=")
    replace("-near*0.6+RosterSpread.assignmentCost(input,s,a,d,sh)", "+(RosterContinuity.enabled(input)&&sh==='N'?RosterWeekend.workCost(input,m,i,d,weekendGuide):0)-near*0.6+RosterSpread.assignmentCost(input,s,a,d,sh)")
    # Worst accumulated gap precedes aggregate variance, without adding a cap.
    replace("});return {score,pairs};\n  }\n  function groups(x,m,plan)", "});if(p.continuity){const rolling=pairs.filter(q=>q.scope==='rolling'),peak=Math.max(0,...rolling.map(q=>Math.abs(q.gap)-1)),days=Math.max(1,...rolling.map(q=>q.pastDays+q.days.length));score[2]+=peak*(pairs.length+1)*(days+1)**2;}return {score,pairs};\n  }\n  function groups(x,m,plan)")
    replace('return {version:2,rows,pairs,windows};', 'return {version:2,rows,pairs,windows,continuity: RosterContinuity.enabled(x)};')
    replace('validatePlan,notWorseLimit,level};', 'validatePlan,notWorseLimit,level,signature};')
    return s
