"""Package the applied-methods baseline, without experimental runners or histories."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[2]
out = root / 'output'
out.mkdir(exist_ok=True)
name = 'haramii-v0.12.4-recovery.2-applied-methods-20261103'
html = (root / 'index.html').read_bytes()
digest = hashlib.sha256(html).hexdigest()
assert html == (root / 'source/dist/index.html').read_bytes()
checks = (root / 'validation/applied-methods-backup/checks.log').read_text()
assert sum(line.startswith('PASS ') for line in checks.splitlines()) == 43
nonblocking = json.loads((root / 'validation/applied-methods-backup/nonblocking.json').read_text())
assert nonblocking['unchangedRosterReturned'] and nonblocking['repeatedStaff'] > 0
assert nonblocking['hardErrors'] == nonblocking['fairnessBreaches'] == 0

readme = '''# 병동 근무표 — 적용 방법 3가지 보관본

보관일: 2026-11-03
프로그램 버전: v0.12.4-recovery.2
보관본 구분: applied-methods (이후 시험 3가지 미통합)

## 실행

ZIP을 모두 압축 해제한 뒤 index.html을 Chrome 또는 Edge에서 여세요.
프로그램 실행에는 설치 스크립트·Python·Node.js·서버가 필요하지 않습니다.
입력한 직원 정보와 근무표는 프로그램의 JSON 저장 기능으로 별도로 내려받아
보관하세요. 이 ZIP에는 사용자의 브라우저에 저장된 데이터가 포함되지 않습니다.

## 포함된 방법

1. 여러 직원·날짜 공동 재배치, 부담이 큰 사람부터 점진 개선.
2. 누적 집계에서 빠질 실제 기록을 미리 고려하는 보조 평가:
   N 횟수·기본 OFF·주말 OFF, 기본 OFF와 별도인 자동연차 수혜,
   신청 수와 비율을 고려한 희망반영 공평성. 미래 균형을 위해 현재 균형을 악화시키지 않습니다.
3. 문제 구간 D/E/OFF 공동 재배치, 회차 경계 휴식 우선도,
   보강 목표가 휴식 개선을 막는지 진단. 실제 최소인원·보강 하한은 유지합니다.

## 통합하지 않은 이후 시험

1. 세 목표 전체를 N 집중 → 휴식분산 → 주말 OFF 순으로 바꾸는 우선순위 실험.
2. CP-SAT 등을 이용해 28일 N/D/E/OFF 전체를 동시에 푸는 최적화 실험.
3. 같은 직원의 편성당 2회 이상 반복을 제한하거나 첫 1회를 다른 직원에게
   분산하는 것을 별도 정책으로 삼는 실험.

기존 평가식의 반복 횟수 집계·부담 비교·N 보호는 유지합니다.
이런 기존 개선 기준이 있다는 것이 이후 실험의 통합을 뜻하지는 않습니다.

## 반드시 유지할 의미

7일 중 6일 근무는 최대한 줄여 없애는 개선 목표입니다.
1회 또는 2회 이상 남아도 그 사실만으로 생성·확정을 막지 않습니다.
개선안을 찾지 못하거나 탐색 한도에 도달하면 현재 표를 반환하고 경고합니다.
기존 최소인원·확정 입력·근무 전환 등 필수조건은 그대로 유지합니다.

## 검증과 한계

기능·회귀 검사 43개 통과. 반복 구간이 남은 표를 반환하는 확인 시험도 통과했습니다.
이번 보관 작업에서 새 7회 연속 시험은 하지 않았습니다.
유실된 원본 v0.12.4와 동일한 파일이 아니라 대화와 남은 소스에 따른 복구판입니다.
HTML은 기존 recovery.2와 동일하며, 이번에는 보관 범위와 설명을 고정했습니다.
다른 실험 실행 스크립트와 장기 시험 이력은 이 보관본에서 제외했습니다.

## 파일 구성과 소스 재빌드

- index.html: 실행용 프로그램
- source/src/: 빌드 원본
- source/scripts/: 빌드·백업 스크립트
- source/tests/: 포함된 방법과 기존 규칙의 검증 코드
- validation/applied-methods-backup/: 이번 확인 결과
- CONVERSATION-RECOVERY.md: 사용자가 확인한 복구 기준
- POLICY.json: 적용/미적용 범위와 HTML 해시
- MANIFEST.json: 각 파일 크기와 SHA-256

소스를 수정해 다시 빌드할 때만 Python 3와 Node.js가 필요합니다.
저장소 최상위에서 `bash build.sh`를 실행하세요.
Windows에서 Bash 없이 빌드하려면 `python source/scripts/build.py`를 실행하고,
생성된 source/dist/index.html을 사용하세요.
검사는 `node source/tests/recovery-balance.cjs` 등 각 검사 파일로 실행합니다.
'''
policy = {
    'version': 'v0.12.4-recovery.2', 'snapshot': name, 'htmlSHA256': digest,
    'applied': ['joint_reassignment_and_gradual_worst_burden_reduction',
                'expiring_actual_history_lookahead_with_current_balance_protection',
                'DE_OFF_joint_reassignment_boundary_rest_and_boost_diagnostics'],
    'laterExperimentsIntegrated': {'global_N_rest_weekend_priority': False,
                                  'whole_28_day_CP_SAT': False,
                                  'per_roster_repeat_cap_or_first_episode_sharing': False},
    'sixWorkdaysInSeven': {'goal': 'reduce_toward_zero', 'blocksGenerationByItself': False,
                           'blocksConfirmationByItself': False},
    'newSevenPeriodTestRun': False, 'checksPassed': 43,
}
paths = ['index.html', 'build.sh', 'CONVERSATION-RECOVERY.md', 'source/dist/index.html']
paths += [str(p.relative_to(root)) for p in sorted((root / 'source/src').glob('*')) if p.is_file()]
paths += ['source/scripts/' + n for n in ['build.py', 'rest_balance_patch.py', 'continuity_patch.py',
                                        'recovery_patch.py', 'package_applied_backup.py']]
paths += ['source/tests/' + n + '.cjs' for n in ['helpers', 'recovery-balance', 'recovery-restoration',
                                               'rest-policy', 'night-transition', 'continuity']]
paths += [str(p.relative_to(root)) for p in sorted((root / 'validation/applied-methods-backup').glob('*')) if p.is_file()]
files = {n: (root / n).read_bytes() for n in paths}
files['README.md'] = readme.encode()
files['POLICY.json'] = (json.dumps(policy, ensure_ascii=False, indent=2) + '\n').encode()
manifest = {n: {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()} for n, b in files.items()}
archive = out / (name + '.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for n, b in files.items():
        z.writestr(n, b)
    z.writestr('MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n, entry in manifest.items():
        assert hashlib.sha256(z.read(n)).hexdigest() == entry['sha256']
(out / (name + '.html')).write_bytes(html)
(out / (name + '-README.md')).write_text(readme)
(out / (name + '-SHA256SUMS.txt')).write_text('\n'.join(
    hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name
    for p in [archive, out / (name + '.html'), out / (name + '-README.md')]) + '\n')
print(json.dumps({'archive': str(archive), 'files': len(manifest), 'bytes': archive.stat().st_size,
                  'htmlSHA256': digest, 'checksPassed': 43}))
