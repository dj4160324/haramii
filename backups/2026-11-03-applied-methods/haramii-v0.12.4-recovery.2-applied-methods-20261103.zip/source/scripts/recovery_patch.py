"""Recovery hooks. Lost source is not represented as a byte-identical release."""
def apply(source, root):
    s = source
    def replace(old, new):
        nonlocal s
        if s.count(old) != 1:
            raise RuntimeError(f'Recovery anchor count {s.count(old)}: {old[:100]}')
        s = s.replace(old, new)
    s = s.replace('v0.12.2', 'v0.12.4-recovery.2')
    replace('    window.koreanHolidays = {', (root/'src/recovery-balance.js').read_text() + '\n    window.koreanHolidays = {')
    replace('input.continuityPolicy=1;', 'input.continuityPolicy=1;input.futureBalancePolicy=1;input.restRebuildPolicy=1;')
    replace("let cost=sh==='N'?legacy.nightCost(x,s,row,d)*4:0;",
            "let cost=sh==='N'?legacy.nightCost(x,s,row,d)*4:0;if(RosterRebuild.enabled(x))cost+=RosterRebuild.boundaryCost(x,s,row,d,sh);")
    replace("p.grants.push({key:key(owner.s),date:input.dates[date].iso,source:decision?'manager':'auto'",
            "({chosen,owner,date}=await RosterFuture.chooseAnnual(input,m,{chosen,owner,date},people,{trial:attempt,stop,onProgress}));\n        p.grants.push({key:key(owner.s),date:input.dates[date].iso,source:decision?'manager':'auto'")
    replace('next=await RosterContinuity.improve(x,next,options);',
            'next=await RosterContinuity.improve(x,next,options);\n    next=await RosterRebuild.improve(x,next,{onProgress:options.onProgress});\n    next=await RosterFuture.improve(x,next,{onProgress:options.onProgress});')
    replace('if(input.continuityPolicy!==undefined&&',
            "for(const flag of ['futureBalancePolicy','restRebuildPolicy'])if(input[flag]!==undefined&&(input[flag]!==1||input.continuityPolicy!==1||input.weekendPolicy!==2||input.restSpreadPolicy!==2))throw Error('복구판 균형 기준을 확인해 주세요.');\n    if(input.continuityPolicy!==undefined&&")
    return s
