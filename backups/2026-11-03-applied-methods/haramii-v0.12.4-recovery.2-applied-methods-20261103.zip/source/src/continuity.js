/* Preserve earned weekend balance and move whole night/recovery bundles.
 * Quality repair only: immutable input, actual work, leave ownership and floors
 * remain constraints. No new confirmation prohibition is introduced here. */
const RosterContinuity=(()=>{
  const enabled=x=>x?.continuityPolicy===1,SH=['D','E','N'],REST=['OFF','LEAVE'],cmp=(a,b)=>{for(let i=0;i<Math.max(a.length,b.length);i++){const d=(a[i]||0)-(b[i]||0);if(Math.abs(d)>1e-8)return d;}return 0;};
  function nightScore(x,s,row){
    if(s.isNightOnly||s.isDispatch)return 0;
    const before=s.previousShifts||[],after=RosterTraining.nextShifts(x,s)||[],get=d=>d<0?before[before.length+d]:d>=row.length?after[d-row.length]:row[d];let score=0;
    for(let start=-6;start<row.length;start++){
      const ds=Array.from({length:7},(_,i)=>start+i),active=ds.filter(d=>d>=0&&d<row.length);
      if(active.every(d=>RosterTraining.trainee(x,s,d)||['MATERNITY','PARENTAL','DISPATCH'].includes(row[d])))continue;
      score+=Math.max(0,ds.filter(d=>get(d)==='N').length-3)**2;
    }return score;
  }
  function nightDelta(x,s,row,d,sh){
    if(!enabled(x)||s.isNightOnly||s.isDispatch||sh!=='N'&&row[d]!=='N'||sh===row[d])return 0;
    const previous=s.previousShifts||[],future=RosterTraining.nextShifts(x,s)||[],get=k=>k<0?previous[previous.length+k]:k>=row.length?future[k-row.length]:row[k];let value=0;
    for(let from=d-6;from<=d;from++){let n=0;for(let k=from;k<from+7;k++)n+=get(k)==='N';const next=n+Number(sh==='N')-Number(row[d]==='N');value+=Math.max(0,next-3)**2-Math.max(0,n-3)**2;}return value;
  }
  function nightSafe(x,before,after,ids){return !enabled(x)||[...ids].every(i=>nightScore(x,x.staff[i],after[i])<=nightScore(x,x.staff[i],before[i]));}
  function weekendScore(x,m,plan=RosterWeekend.prepare(x,m)){
    const r=RosterWeekend.evaluate(m,plan),rolling=r.pairs.filter(p=>p.scope==='rolling');
    return [Math.max(0,...rolling.map(p=>Math.abs(p.gap)-1)),rolling.reduce((n,p)=>n+Math.max(0,Math.abs(p.gap)-1)**2,0),rolling.reduce((n,p)=>n+p.gap*p.gap,0)];
  }
  function weekendSafe(x,before,after){return !enabled(x)||cmp(weekendScore(x,after),weekendScore(x,before))<=0;}
  function workCost(x,m,i,d,plan){
    if(!enabled(x)||!plan||!RosterWeekend.weekend(x.dates[d]))return null;
    const rest=v=>v===null||REST.includes(v);let hard=0,past=0,current=0,peers=0;
    for(const p of plan.pairs){if(p.a!==i&&p.b!==i||!p.days.includes(d))continue;
      const gap=p.pastA-p.pastB+p.days.reduce((n,t)=>n+Number(rest(m[p.a][t]))-Number(rest(m[p.b][t])),0),next=gap+(p.a===i?-1:1);
      if(p.scope==='current'){hard+=Math.max(0,Math.abs(next)-2)**2-Math.max(0,Math.abs(gap)-2)**2;current+=next*next-gap*gap;peers++;}
      else past+=Math.max(0,Math.abs(next)-1)**2-Math.max(0,Math.abs(gap)-1)**2;
    }return (hard*150+past*16+current)/Math.max(1,peers);
  }
  function quality(x,m){const b=RosterSpread.report(x,m),w=RosterWeekend.report(x,m);return {night:b.score[0],weekend:w.currentGap,rolling:w.rollingGap,weekendScore:weekendScore(x,m),rest:b.objective};}
  async function improve(x,result,{maxMs=16000,maxChecks=6000,maxMoves=40,onProgress=()=>{}}={}){
    if(!enabled(x)||x.actualRecording||x.surplusPlan?.decision==='KEEP')return result;
    const E=RosterEngine,F=RosterFairness,P=RosterPreferences,B=RosterSpread,W=RosterWeekend,C=RosterComposition,T=RosterTraining;
    const start=Date.now();let lastYield=start,m=result.matrix.map(r=>r.slice()),issues=E.validate(x,m),fair=F.analyse(x,m),pref=P.analyse(x,m),composition=C.report(x,m);
    const original=quality(x,m),cache=x.staff.map(()=>new Map()),reasons={},stages=[],beams=[];let moves=0,checks=0,proposals=0,limited=false;
    const rowReport=(i,row)=>{const k=row.join(',');if(!cache[i].has(k)){if(cache[i].size>4000)cache[i].clear();cache[i].set(k,B.rowReport(x,x.staff[i],row));}return cache[i].get(k);};
    let rows=x.staff.map((s,i)=>rowReport(i,m[i])),wp=W.prepare(x,m),wr=W.evaluate(m,wp);
    const stop=()=>{if(Date.now()-start>=maxMs||checks>=maxChecks||proposals>=90000){limited=true;return true;}return false;};
    const tick=async()=>{if(Date.now()-lastYield>=55){onProgress();await new Promise(r=>setTimeout(r,0));lastYield=Date.now();}};
    const note=reason=>{reasons[reason]=(reasons[reason]||0)+1;return null;};
    const key=s=>RosterSurplus.identity(s),grant=(i,d)=>x.surplusPlan?.grants?.find(g=>g.key===key(x.staff[i])&&g.date===x.dates[d].iso);
    const mutable=(i,d)=>{const s=x.staff[i],g=grant(i,d),req=s.reqShiftsMap?.[x.dates[d].date],decision=s.requestDecisions?.[x.dates[d].date];return !s.isDispatch&&!T.trainee(x,s,d)&&!E.fixed(x,s,d).length&&
      !(req&&!(decision?.status==='rejected'&&decision.code===req&&decision.date===x.dates[d].iso))&&!(x.weekendPlan?.credits||[]).some(c=>c.key===key(s)&&c.date===x.dates[d].iso)&&
      (SH.includes(m[i][d])||m[i][d]==='OFF'||m[i][d]==='M-LEAVE'&&s.isMLeaveActive&&s.mLeaveOption==='EXTRA'||m[i][d]==='LEAVE'&&g)&&!(g?.requestId||g?.source==='manual');};
    const count=(row,sh,month=null)=>row.reduce((n,v,d)=>n+Number(v===sh&&(!month||x.dates[d].iso.startsWith(month))),0);
    const rolling=r=>{const p=r.pairs.filter(p=>p.scope==='rolling');return [Math.max(0,...p.map(p=>Math.abs(p.gap)-1)),p.reduce((n,p)=>n+Math.max(0,Math.abs(p.gap)-1)**2,0),p.reduce((n,p)=>n+p.gap*p.gap,0)];};
    function attempt(changes,stage){
      if(stop())return null;proposals++;changes=changes.filter(([i,d,sh])=>m[i][d]!==sh);if(!changes.length||changes.some(([i,d])=>!mutable(i,d)))return null;
      const ids=[...new Set(changes.map(c=>c[0]))],next=m.slice();ids.forEach(i=>next[i]=m[i].slice());for(const [i,d,sh] of changes)next[i][d]=sh;
      // Weekend menstrual leave is outside the OFF comparison cohort. Keep
      // those dates fixed so a repair cannot improve a gap by hiding a day.
      const healthMoved=changes.some(([i,d,sh])=>(m[i][d]==='M-LEAVE')!==(sh==='M-LEAVE'));
      if(healthMoved&&changes.some(([i,d,sh])=>W.weekend(x.dates[d])&&(m[i][d]==='M-LEAVE'||sh==='M-LEAVE')))return null;
      const nextRows=rows.slice();for(const i of ids){nextRows[i]=rowReport(i,next[i]);if(nextRows[i].score[0]>rows[i].score[0])return null;}
      const nightImproved=nextRows.reduce((n,r)=>n+r.score[0],0)<rows.reduce((n,r)=>n+r.score[0],0);
      if(nextRows.reduce((n,r)=>n+r.singleNights+r.edgeSingles,0)>rows.reduce((n,r)=>n+r.singleNights+r.edgeSingles,0))return null;
      for(const i of ids){
        if(count(next[i],'OFF')!==count(m[i],'OFF'))return null;
        if(count(next[i],'M-LEAVE')!==count(m[i],'M-LEAVE'))return null;
        for(const month of new Set(x.dates.map(t=>t.iso.slice(0,7))))if(count(next[i],'LEAVE',month)!==count(m[i],'LEAVE',month))return null;
        // Preserve independent overload episodes and their peak. Overlapping
        // views of the same episode must not veto a cumulative OFF correction.
        if(nextRows[i].peakWork>Math.max(6,rows[i].peakWork)||nextRows[i].episodes.length>Math.max(1,rows[i].episodes.length))return null;
        if(!nightImproved&&(nextRows[i].singleNights+nextRows[i].edgeSingles>rows[i].singleNights+rows[i].edgeSingles||nextRows[i].nightRun>Math.max(2,rows[i].nightRun)))return null;
      }
      let grants=x.surplusPlan?.grants,changedGrants=false;
      if(grants){grants=grants.map(g=>({...g}));for(const i of ids){const lost=grants.filter(g=>g.key===key(x.staff[i])&&next[i][x.dates.findIndex(t=>t.iso===g.date)]!=='LEAVE'),gained=x.dates.flatMap((t,d)=>m[i][d]!=='LEAVE'&&next[i][d]==='LEAVE'?[d]:[]);if(lost.length!==gained.length)return null;
        for(const g of lost){const at=gained.findIndex(d=>x.dates[d].iso.slice(0,7)===g.date.slice(0,7));if(at<0)return null;const d=gained.splice(at,1)[0];g.date=x.dates[d].iso;g.from=m[i][d];changedGrants=true;}}}
      const nx=changedGrants?{...x,surplusPlan:{...x.surplusPlan,grants}}:x,np=changedGrants||healthMoved?W.prepare(nx,next):wp,nw=W.evaluate(next,np),beforeRoll=rolling(wr),afterRoll=rolling(nw);
      if(cmp(nw.score.slice(0,2),wr.score.slice(0,2))>0||cmp(afterRoll,beforeRoll)>0)return null;
      const weekendImproved=cmp(afterRoll,beforeRoll)<0||cmp(nw.score.slice(0,2),wr.score.slice(0,2))<0;
      if(!nightImproved&&!weekendImproved)return null;
      checks++;
      for(const i of ids)if(E.patternIssuesForSurplus(nx,x.staff[i],next[i]).some(e=>e.level!=='warning'))return note('근무 전환·야간 회복·연속휴무');
      for(const floor of x.surplusPlan?.floors||[])if(x.staff.reduce((n,s,i)=>n+Number(next[i][floor.d]===floor.shift&&E.eligible(s,x.rules,nx,floor.d)&&E.covers(nx,s,floor.d,floor.shift)),0)<floor.floor)return note('확보한 보강 인원');
      const ni=E.validate(nx,next);if(ni.some(e=>e.level==='error'))return note('최소인원·기본 OFF·확정조건');
      const oldWarnings=new Set(issues.filter(e=>e.level==='warning').map(e=>JSON.stringify(e)));if(ni.some(e=>e.level==='warning'&&!oldWarnings.has(JSON.stringify(e))))return note('회복 확인');
      const nf=F.analyse(nx,next);if(ids.some(i=>nf.counts[i].protectedOff!==fair.counts[i].protectedOff)||nf.breaches.some(b=>b.gap>Math.max(b.limit,fair.breaches.find(p=>p.key===b.key&&p.shift===b.shift&&p.scope===b.scope&&p.month===b.month)?.gap||0)))return note('근무횟수 공평성');
      const pr=P.analyse(nx,next);if(pref.rows.some((r,i)=>r.details.some(v=>v.status==='applied'&&pr.rows[i].details.find(t=>t.d===v.d&&t.code===v.code)?.status!=='applied')))return note('반영된 신청');
      const nc=C.report(nx,next);if(nc.days.some((day,d)=>cmp(day.score.slice(0,2),composition.days[d].score.slice(0,2))>0)||nc.periodGroups.some(g=>g.gap>Math.max(1,composition.periodGroups.find(p=>p.key===g.key)?.gap||0)))return note('선임 집중 방지');
      return {m:next,rows:nextRows,wp:np,wr:nw,issues:ni,fair:nf,pref:pr,composition:nc,grants,stage};
    }
    async function rebuildPair(i,j,{width=96,maxPairMs=4000,third=null,nightOnly=false}={}){
      const ids=third===null?[i,j]:[i,j,third],trace={ids,day:0,states:0};beams.push(trace);const began=Date.now(),len=m[i].length,codes=['OFF','N','D','E','M-LEAVE'],target=ids.map(i=>codes.map(sh=>count(m[i],sh))),patterns=ids.map(()=>new Map());
      const suffix=Array(len+1).fill(0),remainingN=Array(len+1).fill(0);
      for(let d=len-1;d>=0;d--){suffix[d]=suffix[d+1]+ids.filter(i=>m[i][d]==='OFF').length;remainingN[d]=remainingN[d+1]+ids.filter(i=>m[i][d]==='N').length;}
      let states=[{r:ids.map(()=>Array(len).fill(null)),counts:ids.map(()=>codes.map(()=>0)),swaps:[],rank:[0]}];
      const pattern=(k,row)=>{const key=row.join(',');if(!patterns[k].has(key))patterns[k].set(key,E.patternIssuesForSurplus(x,x.staff[ids[k]],row).some(e=>e.level!=='warning'));return patterns[k].get(key);};
      for(let d=0;d<len;d++){
        trace.day=d;trace.states=states.length;
        if(stop()||Date.now()-began>=maxPairMs)return null;
        const perms=ids.length===2?[[0,1],[1,0]]:[[0,1,2],[1,0,2],[2,1,0],[0,2,1],[1,2,0],[2,0,1]];
        const options=perms.filter(p=>p.every((owner,k)=>owner===k||mutable(ids[k],d)&&mutable(ids[owner],d)&&[...SH,'OFF','M-LEAVE'].includes(m[ids[owner]][d])));
        const next=[],seen=new Set();
        for(const state of states)for(const perm of options){
          const values=perm.map(k=>m[ids[k]][d]),r=state.r.map(row=>row.slice()),counts=state.counts.map(c=>c.slice());let bad=false;
          for(let k=0;k<ids.length;k++){
            r[k][d]=values[k];const c=codes.indexOf(values[k]);if(c>=0)counts[k][c]++;
            // OFF totals are exact. A generous bound avoids pruning a later
            // compensating swap; terminal checks enforce both owners' counts.
            if(counts[k][0]>target[k][0]||counts[k][4]>target[k][4]||counts[k][0]+suffix[d+1]<target[k][0]||nightOnly&&(counts[k][1]>target[k][1]||counts[k][1]+remainingN[d+1]<target[k][1])||pattern(k,r[k])){bad=true;break;}
          }
          if(bad)continue;
          const rr=r.map((row,k)=>rowReport(ids[k],row));
          if(rr.some((v,k)=>v.score[0]>rows[ids[k]].score[0]||v.peakWork>Math.max(6,rows[ids[k]].peakWork)||v.episodes.length>Math.max(1,rows[ids[k]].episodes.length)))continue;
          const changes=ids.flatMap((i,k)=>m[i][d]!==values[k]?[[i,d,values[k]]]:[]),swaps=[...state.swaps,...changes],signature=r.map(row=>row.slice(0,d+1).join(',')).join(';');if(seen.has(signature))continue;seen.add(signature);
          const drift=counts.reduce((n,c,k)=>n+c.reduce((s,v,c)=>s+(v-m[ids[k]].slice(0,d+1).filter(sh=>sh===codes[c]).length)**2*(c===1?3:1),0),0);
          let weekend=0;if(RosterWeekend.weekend(x.dates[d])||d===len-1){const projected=m.slice();ids.forEach((id,k)=>projected[id]=r[k].map((v,t)=>v??m[id][t]));const q=rolling(W.evaluate(projected,wp));weekend=q[0]*30+q[1];}else weekend=state.weekend||0;
          const rank=[rr.reduce((n,v)=>n+v.score[0],0),weekend,drift+rr.reduce((n,v)=>n+v.score[1]*8,0),swaps.length];
          next.push({r,counts,swaps,rank,weekend});
        }
        next.sort((a,b)=>cmp(a.rank,b.rank));
        // Keep paths with different OFF/N balances as well as the best score;
        // a temporary count difference may be needed for a complete bundle.
        const diverse=[],keys=new Set();for(const state of next){const key=state.counts.map(c=>[c[0],c[1],c[4]].join(',')).join(';')+'|'+state.r.map(r=>r.slice(Math.max(0,d-2),d+1).join(',')).join(';');if(!keys.has(key)){keys.add(key);diverse.push(state);if(diverse.length>=Math.floor(width/2))break;}}
        const kept=new Set(diverse);for(const state of next)if(!kept.has(state)){diverse.push(state);if(diverse.length>=width)break;}states=diverse;
        if(!states.length)return null;await tick();
      }
      states.sort((a,b)=>cmp(a.rank,b.rank));trace.rank=states[0]?.rank;trace.states=states.length;
      for(const state of states){if(state.counts.some((c,k)=>c[0]!==target[k][0]||c[4]!==target[k][4]||nightOnly&&c[1]!==target[k][1]))continue;const found=attempt(state.swaps,ids.length===2?'pair-sequence':'three-sequence');if(found&&(!nightOnly||found.rows.reduce((n,r)=>n+r.score[0],0)<rows.reduce((n,r)=>n+r.score[0],0))){trace.adopted=true;return found;}if(stop())break;}
      return null;
    }
    if(!issues.some(e=>e.level==='error'))for(let pass=0;pass<maxMoves&&!stop();pass++){
      let found=null;const hasNight=rows.some(r=>r.score[0]),pairs=wr.pairs.filter(p=>p.scope==='rolling'&&Math.abs(p.gap)>1||p.scope==='current'&&Math.abs(p.gap)>2).sort((a,b)=>Number(b.scope==='current'&&Math.abs(b.gap)>2)-Number(a.scope==='current'&&Math.abs(a.gap)>2)||Math.abs(b.gap)-Math.abs(a.gap));
      const people=[...new Set([...rows.flatMap((r,i)=>r.score[0]?[i]:[]),...pairs.flatMap(p=>[p.gap>0?p.b:p.a,p.gap>0?p.a:p.b])])];
      if(!people.length)break;
      if(hasNight){
        nightSearch:for(const i of people.filter(i=>rows[i].score[0])){
          const peers=x.staff.map((s,j)=>j).filter(j=>j!==i&&!x.staff[j].isDispatch&&!x.staff[j].isPregnant&&!x.staff[j].isNightOnly).sort((a,b)=>Number(x.staff[b].isSenior===x.staff[i].isSenior)-Number(x.staff[a].isSenior===x.staff[i].isSenior)||rows[a].score[0]-rows[b].score[0]);
          for(const j of peers.filter(j=>x.staff[j].isSenior===x.staff[i].isSenior)){found=await rebuildPair(i,j,{maxPairMs:1200,nightOnly:true});if(found||stop())break nightSearch;}
          const near=peers.filter(j=>x.staff[j].isSenior===x.staff[i].isSenior).slice(0,7);
          for(let u=0;u<near.length;u++)for(let v=u+1;v<near.length;v++){found=await rebuildPair(i,near[u],{third:near[v],width:96,maxPairMs:3500,nightOnly:true});if(found||stop())break nightSearch;}
        }
      }else{
        quickWeekend:for(const p of pairs){
          for(const i of [p.gap>0?p.b:p.a,p.gap>0?p.a:p.b])for(const d of p.days){
            if(!mutable(i,d))continue;
            for(let t=0;t<m[i].length;t++){
              if(W.weekend(x.dates[t])||!mutable(i,t))continue;
              if(SH.includes(m[i][d])&&m[i][t]==='OFF')for(const sh of [...new Set([m[i][d],'D','E'])]){found=attempt([[i,d,'OFF'],[i,t,sh]],'weekend-date');if(found||stop())break quickWeekend;}
              if(m[i][d]==='OFF'&&SH.includes(m[i][t]))for(const sh of [...new Set([m[i][t],'D','E'])]){found=attempt([[i,d,sh],[i,t,'OFF']],'weekend-date');if(found||stop())break quickWeekend;}
              await tick();
            }
          }
        }
        if(!found)for(const p of pairs.slice(0,4)){found=await rebuildPair(p.a,p.b,{width:64,maxPairMs:2500});if(found||stop())break;}
      }
      const anchors=i=>[...new Set([...m[i].flatMap((sh,d)=>rows[i].score[0]&&sh==='N'?[d]:[]),...pairs.filter(p=>p.a===i||p.b===i).flatMap(p=>p.days)])];
      search:for(const i of found?[]:people){
        const ds=anchors(i).filter(d=>mutable(i,d));
        // A whole N block can relocate within the same row without breaking
        // its recovery days; old single-cell swaps could not make this move.
        for(const d of ds)for(const width of [2,3,4,5,6,7])for(const from of [d,Math.max(0,d-width+1)]){
          if(from+width>m[i].length)continue;
          for(let to=0;to+width<=m[i].length;to++){
            if(Math.abs(from-to)<width)continue;
            const changes=Array.from({length:width},(_,k)=>[[i,from+k,m[i][to+k]],[i,to+k,m[i][from+k]]]).flat();
            found=attempt(changes,'own-bundle-'+width);if(found)break search;if(stop())break search;await tick();
          }
        }
        for(const d of ds)for(let t=0;t<m[i].length;t++){
          if(d===t||!mutable(i,t))continue;
          found=attempt([[i,d,m[i][t]],[i,t,m[i][d]]],'own-date');if(found)break search;
          if(SH.includes(m[i][d])&&REST.includes(m[i][t]))for(const sh of ['D','E']){found=attempt([[i,d,m[i][t]],[i,t,sh]],'own-date-shift');if(found)break search;}
          for(let j=0;j<x.staff.length;j++)if(j!==i){
            found=attempt([i,j].flatMap(k=>[[k,d,m[k][t]],[k,t,m[k][d]]]),'pair-dates');if(found)break search;
            // N can transfer to another eligible employee without moving OFF.
            found=attempt([[i,d,m[j][d]],[j,d,m[i][d]]],'same-day');if(found)break search;
          }
          if(stop())break search;await tick();
        }
        // Atomic intervals exchange N and recovery together across employees.
        for(const d of ds)for(const width of [2,3,4,5,7,10,14])for(const offset of [0,-2,-4]){
          const from=Math.max(0,Math.min(m[i].length-width,d+offset));if(from+width>m[i].length)continue;const days=Array.from({length:width},(_,k)=>from+k);
          for(let j=0;j<x.staff.length;j++)if(i!==j){
            found=attempt(days.flatMap(t=>[[i,t,m[j][t]],[j,t,m[i][t]]]),'pair-bundle-'+width);if(found)break search;if(stop())break search;await tick();
          }
        }
      }
      if(!found)break;
      ({m,rows,wp,wr,issues,fair,pref,composition}=found);if(x.surplusPlan)x.surplusPlan.grants=found.grants;moves++;stages.push(found.stage);await tick();
    }
    const after=quality(x,m),run={version:1,before:original,after,moves,checks,proposals,ms:Date.now()-start,limited,stages,reasons,beams};
    const weekend={version:2,signature:W.signature(x,m),status:issues.some(e=>e.level==='error')?'blocked':limited?'limited':'checked',moves:(result.weekend?.moves||0)+moves,checks:(result.weekend?.checks||0)+checks,ms:(result.weekend?.ms||0)+run.ms,before:result.weekend?.before||W.evaluate(result.matrix,W.prepare(x,result.matrix)).score,after:W.evaluate(m,W.prepare(x,m)).score,reasons:Object.keys(reasons).slice(0,3)};
    return {...result,matrix:m,issues,fairness:fair,preferences:pref,composition,continuity:run,weekend,weekendObjective:weekend.after,carryover:E.carryover(x,m)};
  }
  return {enabled,nightScore,nightDelta,nightSafe,weekendScore,weekendSafe,workCost,quality,improve};
})();
