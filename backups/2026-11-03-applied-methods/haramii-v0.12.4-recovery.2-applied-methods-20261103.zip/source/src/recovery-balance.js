/* Reconstructed policy, not the lost v0.12.4 source.
 * Forecasts contain only observed/assigned dates surviving calendar expiry.
 * They never invent future duties or change a confirmed history entry.
 */
const RosterRecovery = (() => {
  const SH = ['D', 'E', 'N', 'OFF'];
  const cmp = (a, b) => RosterFairness.compare(a, b);
  function current(x, m) {
    const fair = RosterFairness.analyse(x, m), weekend = RosterWeekend.report(x, m);
    const spread = RosterSpread.report(x, m), preferences = RosterPreferences.analyse(x, m);
    const composition = RosterComposition.report(x, m), issues = RosterEngine.validate(x, m);
    const metrics = {};
    function group(prefix, g, values) {
      const mean = values.reduce((a, b) => a + b, 0) / values.length;
      metrics[prefix + '|' + g + '|gap'] = Math.max(...values) - Math.min(...values);
      metrics[prefix + '|' + g + '|squares'] = values.reduce((n, v) => n + (v - mean) ** 2, 0);
    }
    for (const [j, g] of fair.groups.entries()) if (g.comparable) for (const sh of g.shifts) {
      group('current|' + sh, j, g.indices.map(i => fair.counts[i][sh] - (sh === 'OFF' ? fair.counts[i].extraOff : 0)));
    }
    for (const w of fair.rolling.windows) for (const [j, g] of w.groups.entries()) if (g.comparable) {
      for (const sh of ['N', 'OFF']) group('rolling|' + w.month + '|' + sh, j,
        g.indices.map(i => w.rows.find(r => r.index === i).total[sh]));
    }
    for (const scope of new Set(weekend.pairs.map(p => p.scope + '|' + (p.month || '')))) {
      const gaps = weekend.pairs.filter(p => p.scope + '|' + (p.month || '') === scope).map(p => p.gap);
      metrics['weekend|' + scope + '|peak'] = Math.max(0, ...gaps.map(Math.abs));
      metrics['weekend|' + scope + '|squares'] = gaps.reduce((n, v) => n + v * v, 0);
    }
    weekend.groups.forEach((g, i) => metrics['weekendGroup|' + i] = g.gap);
    if (RosterAnnual.enabled(x)) {
      const annual = RosterAnnual.comparison(x, m);
      for (const w of annual.windows) {
        const gaps = w.rows.flatMap(r => r.peers.filter(p => r.i < p.i).map(p => p.gap));
        metrics['annual|' + w.month + '|peak'] = Math.max(0, ...gaps.map(Math.abs));
        metrics['annual|' + w.month + '|squares'] = gaps.reduce((n, v) => n + v * v, 0);
      }
      metrics['annualGroup'] = RosterAnnual.group(x, m).gap;
    }
    composition.days.forEach((v, d) => v.score.slice(0, 2).forEach((n, j) => metrics['composition|' + d + '|' + j] = n));
    composition.periodGroups.forEach((g, i) => metrics['compositionPeriod|' + i] = g.gap);
    for (const k of ['AVOID', 'SHIFT', 'OFF']) metrics['requests|' + k] = preferences.totals[k].unmet;
    return {fair, weekend, spread, preferences, composition, issues, metrics};
  }
  const noWorse = (before, after) => Object.keys(before).length === Object.keys(after).length &&
    Object.keys(before).every(k => Number.isFinite(after[k]) && after[k] <= before[k] + 1e-8);
  function mutable(x, m, i, d) {
    const s = x.staff[i];
    return !s.isDispatch && !s.isPregnant && !RosterTraining.trainee(x, s, d) &&
      SH.includes(m[i][d]) && !RosterEngine.fixed(x, s, d).length &&
      !(x.weekendPlan?.credits || []).some(c => c.key === RosterSurplus.identity(s) && c.date === x.dates[d].iso);
  }
  function counts(x, row, month, sh) {
    return row.reduce((n, v, d) => n + Number(v === sh && x.dates[d].iso.startsWith(month)), 0);
  }
  function floorBlockers(x, m) {
    return (x.surplusPlan?.floors || []).flatMap(f => {
      const actual = x.staff.reduce((n, s, i) => n + Number(m[i][f.d] === f.shift &&
        RosterEngine.eligible(s, x.rules, x, f.d) && RosterEngine.covers(x, s, f.d, f.shift)), 0);
      return actual < f.floor ? [{d: f.d, date: x.dates[f.d].iso, shift: f.shift,
        actual, floor: f.floor, goal: f.goal ?? f.floor, minimum: RosterEngine.quota(x, f.d, f.shift), shortage: f.floor - actual}] : [];
    });
  }
  function safe(x, before, m, prior, {exactCounts = false, preserveDailyTotals = true} = {}) {
    const ids = x.staff.flatMap((_, i) => m[i].some((v, d) => v !== before[i][d]) ? [i] : []);
    for (const i of ids) {
      for (let d = 0; d < x.dates.length; d++) if (m[i][d] !== before[i][d] && !mutable(x, before, i, d)) return null;
      if (!RosterSpread.preservesRequests(x, before, m, [i])) return null;
      if (RosterEngine.patternIssuesForSurplus(x, x.staff[i], m[i]).some(e => e.level !== 'warning')) return null;
      if (exactCounts) for (const month of new Set(x.dates.map(t => t.iso.slice(0, 7)))) {
        for (const sh of SH) if (counts(x, before[i], month, sh) !== counts(x, m[i], month, sh)) return null;
      }
      const a = prior.spread.rows[i], b = RosterSpread.rowReport(x, x.staff[i], m[i]);
      // This recovery preserves the former individual burden floor. Sharing a
      // first episode with a different employee is a separate experiment.
      if (b.episodes.length > a.episodes.length || b.peakWork > Math.max(6, a.peakWork) ||
          b.score.slice(0, 2).some((n, j) => n > a.score[j] + 1e-8) ||
          b.singleNights + b.edgeSingles > a.singleNights + a.edgeSingles || b.nightRun > Math.max(2, a.nightRun)) return null;
    }
    if (floorBlockers(x, m).length) return null;
    if (preserveDailyTotals) for (let d = 0; d < x.dates.length; d++) for (const sh of ['D', 'E', 'N']) {
      const staff = matrix => x.staff.flatMap((s, i) => matrix[i][d] === sh &&
        RosterEngine.eligible(s, x.rules, x, d) && RosterEngine.covers(x, s, d, sh) ? [s] : []);
      const a = staff(before), b = staff(m);
      if (a.length !== b.length || a.filter(s => s.isSenior).length !== b.filter(s => s.isSenior).length) return null;
    }
    const next = current(x, m);
    if (!exactCounts && next.spread.score[2] > prior.spread.score[2] + 1e-8) return null;
    if (next.issues.some(e => e.level === 'error') || next.fair.breaches.length || !noWorse(prior.metrics, next.metrics)) return null;
    const warnings = new Set(prior.issues.filter(e => e.level === 'warning').map(e => JSON.stringify(e)));
    if (next.issues.some(e => e.level === 'warning' && !warnings.has(JSON.stringify(e)))) return null;
    if (next.fair.counts.some((c, i) => c.protectedOff !== prior.fair.counts[i].protectedOff)) return null;
    return next;
  }
  function result(x, r, matrix, q) {
    return {...r, matrix, issues: q.issues, fairness: q.fair, preferences: q.preferences,
      composition: q.composition, carryover: RosterEngine.carryover(x, matrix),
      weekendObjective: q.weekend.score, restObjective: q.spread.objective};
  }
  function* candidates(x, m, {blocks = false} = {}) {
    const n = x.staff.length, days = x.dates.length;
    const people = x.staff.map((_, i) => i);
    if (blocks) people.sort((i, j) => RosterSpread.rowReport(x, x.staff[j], m[j]).episodes.length -
      RosterSpread.rowReport(x, x.staff[i], m[i]).episodes.length);
    if (blocks) for (let left = 0; left < n; left++) for (let right = left + 1; right < n; right++) {
      const i = people[left], j = people[right];
      if (x.staff[i].isSenior !== x.staff[j].isSenior) continue;
      for (let d = 0; d < days; d++) for (let t = d + 1; t < days; t++) {
        if (m[i][d] === m[j][d] || m[i][d] !== m[j][t] || m[j][d] !== m[i][t] ||
            ![i, j].every(k => [d, t].every(day => mutable(x, m, k, day)))) continue;
        const next = m.slice(); next[i] = m[i].slice(); next[j] = m[j].slice();
        for (const day of [d, t]) [next[i][day], next[j][day]] = [next[j][day], next[i][day]];
        yield next;
      }
    }
    // Same-day exchanges preserve the complete staffing profile. Whole blocks
    // move nights with their recovery days; compensating dates preserve totals.
    for (const width of blocks ? [2, 3, 4, 5, 7, 10, 14, 1] : [1, 2, 3, 4, 7]) {
      for (let left = 0; left < n; left++) for (let right = left + 1; right < n; right++) {
        const i = people[left], j = people[right];
        if (x.staff[i].isSenior !== x.staff[j].isSenior) continue;
        for (let from = 0; from + width <= days; from++) {
          const changed = Array.from({length: width}, (_, k) => from + k).filter(d => m[i][d] !== m[j][d]);
          if (!changed.length || changed.some(d => !mutable(x, m, i, d) || !mutable(x, m, j, d))) continue;
          const next = m.slice(); next[i] = m[i].slice(); next[j] = m[j].slice();
          for (const d of changed) [next[i][d], next[j][d]] = [next[j][d], next[i][d]];
          yield next;
        }
      }
    }
    if (!blocks) for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
      if (x.staff[i].isSenior !== x.staff[j].isSenior) continue;
      for (let d = 0; d < days; d++) for (let t = d + 1; t < days; t++) {
        if (m[i][d] === m[j][d] || m[i][d] !== m[j][t] || m[j][d] !== m[i][t] ||
            ![i, j].every(k => [d, t].every(day => mutable(x, m, k, day)))) continue;
        const next = m.slice(); next[i] = m[i].slice(); next[j] = m[j].slice();
        for (const day of [d, t]) [next[i][day], next[j][day]] = [next[j][day], next[i][day]];
        yield next;
      }
    }
  }
  return {current, safe, noWorse, result, candidates, cmp, mutable, floorBlockers};
})();

const RosterFuture = (() => {
  const enabled = x => x?.futureBalancePolicy === 1;
  const key = s => RosterWorkload.identity(s);
  const month = (iso, offset) => {
    const [y, m] = iso.slice(0, 7).split('-').map(Number);
    return new Date(Date.UTC(y, m - 1 + offset, 1)).toISOString().slice(0, 7);
  };
  function prepare(x, m) {
    const fair = RosterFairness.analyse(x, m), w = RosterWeekend.prepare(x, m), pairs = [], excluded = [], preferences = [];
    const requests = RosterPreferences.prepare(x);
    const latest = fair.rolling.windows.at(-1), lastMonth = x.dates.at(-1).iso.slice(0, 7);
    for (const offset of [1, 2]) {
      const targetMonth = month(lastMonth, offset), start = RosterSurplus.windowStart(targetMonth);
      for (const p of w.pairs.filter(p => p.scope === 'current')) {
        const left = w.rows[p.a], right = w.rows[p.b];
        const past = [...left.past.keys()].filter(d => d >= start && right.past.has(d));
        const days = p.days.filter(d => x.dates[d].iso >= start);
        if (!days.length && !past.length) continue;
        pairs.push({metric: 'weekend', offset, targetMonth, start, a: p.a, b: p.b, days,
          pastA: past.reduce((n, d) => n + left.past.get(d), 0), pastB: past.reduce((n, d) => n + right.past.get(d), 0), observedDays: past.length + days.length});
      }
      for (const g of latest.groups.filter(g => g.comparable)) for (const sh of ['N', 'OFF']) {
        const rows = new Map();
        for (const i of g.indices) {
          const days = x.dates.flatMap((t, d) => t.iso >= start ? [d] : []);
          let past = 0, reason = '', observedDays = days.length;
          for (const p of x.workloadHistory?.periods || []) {
            if (p.basis !== 'actual' || p.end >= x.dates[0].iso || p.end < start) continue;
            const r = p.rows.find(r => r.key === key(x.staff[i]));
            if (!r) { reason = 'missing historical employee'; break; }
            const from = Math.max(0, Math.round((Date.parse(start) - Date.parse(p.start)) / 86400000));
            const duty = r.shifts.slice(from); observedDays += duty.length;
            past += duty.filter(v => v === sh).length;
            if (sh === 'OFF') {
              if (from && (r.protectedExtraOff ?? r.extraOff)) { reason = 'protected OFF cannot be located across expiry'; break; }
              past -= Array.isArray(r.surplusDates) ? (r.protectedExtraOff || 0) + r.surplusDates.filter(d => d >= start).length : r.extraOff;
            }
          }
          const c = fair.counts[i];
          if (sh === 'OFF' && days.length !== x.dates.length && c.protectedOff) reason = 'current protected OFF cannot be located across expiry';
          if (reason) { excluded.push({i, metric: sh, offset, reason}); continue; }
          const correction = sh === 'OFF' ? c.protectedOff + (x.surplusPlan?.grants || []).filter(v =>
            v.key === key(x.staff[i]) && v.date >= start && m[i][x.dates.findIndex(t => t.iso === v.date)] === 'OFF').length : 0;
          rows.set(i, {past: past - correction, days, observedDays});
        }
        for (let a = 0; a < g.indices.length; a++) for (let b = a + 1; b < g.indices.length; b++) {
          const i = g.indices[a], j = g.indices[b], p = rows.get(i), q = rows.get(j);
          if (!p || !q || p.observedDays !== q.observedDays || !p.observedDays) continue;
          pairs.push({metric: sh, offset, targetMonth, start, a: i, b: j, days: p.days,
            pastA: p.past, pastB: q.past, observedDays: p.observedDays});
        }
      }
      if (RosterAnnual.enabled(x)) {
        const points = x.staff.map(() => new Map());
        for (const p of x.surplusHistory?.periods || []) {
          if (p.status !== 'actual' || p.end >= x.dates[0].iso || p.end < start || !RosterAnnual.enabled(p.input)) continue;
          x.staff.forEach((s, i) => {
            const j = p.input.staff.findIndex(t => key(t) === key(s));
            if (j < 0 || !RosterAnnual.eligible(p.input, p.input.staff[j])) return;
            p.input.dates.forEach((t, d) => {
              if (t.iso >= start && RosterAnnual.activeDay(p.input, p.input.staff[j], d)) points[i].set(t.iso,
                Number(p.actual[j][d] === 'LEAVE' && (p.actualGrants || []).some(g => g.key === key(s) && g.date === t.iso)));
            });
          });
        }
        x.staff.forEach((s, i) => {
          if (!RosterAnnual.eligible(x, s)) return;
          x.dates.forEach((t, d) => {
            if (t.iso >= start && RosterAnnual.activeDay(x, s, d)) points[i].set(t.iso,
              Number(m[i][d] === 'LEAVE' && (x.surplusPlan?.grants || []).some(g => g.key === key(s) && g.date === t.iso)));
          });
        });
        for (let i = 0; i < x.staff.length; i++) for (let j = i + 1; j < x.staff.length; j++) {
          if (!RosterAnnual.eligible(x, x.staff[i]) || !RosterAnnual.eligible(x, x.staff[j])) continue;
          const common = [...points[i].keys()].filter(d => points[j].has(d));
          if (!common.length) continue;
          pairs.push({metric: 'annual', offset, targetMonth, start, a: i, b: j, days: [],
            pastA: common.reduce((n, d) => n + points[i].get(d), 0), pastB: common.reduce((n, d) => n + points[j].get(d), 0), observedDays: common.length});
        }
      }
      for (const type of ['AVOID', 'SHIFT', 'OFF']) {
        const rows = [];
        requests.staff.forEach((s, i) => {
          const current = s.requests.filter(r => r.type === type && !r.excluded && r.date >= start);
          if (!current.length) return;
          let submitted = 0, unmet = 0;
          for (const p of x.preferenceHistory?.periods || []) {
            if (p.basis !== 'actual' || p.end >= x.dates[0].iso || p.end < start) continue;
            const training = (x.workloadHistory?.periods || []).find(w => w.start === p.start && w.end === p.end)?.rows.find(r => r.key === s.key)?.kind === 'newbie';
            if (training) continue;
            for (const d of p.rows.find(r => r.key === s.key)?.details || []) {
              if (d.type !== type || d.status === 'excluded' || d.date < start || x.staff[i].independenceDate && d.date < x.staff[i].independenceDate) continue;
              submitted++; unmet += d.status !== 'applied';
            }
          }
          rows.push({i, current, submitted, unmet});
        });
        preferences.push({type, offset, start, targetMonth, rows});
      }
    }
    return {pairs, preferences, excluded, assumptions: 'known retained records only; future work is unassigned'};
  }
  function evaluate(m, plan) {
    const pairs = plan.pairs.map(p => {
      const value = sh => p.metric === 'weekend' ? Number(sh === 'OFF' || sh === 'LEAVE') : Number(sh === p.metric);
      const own = p.pastA + p.days.reduce((n, d) => n + value(m[p.a][d]), 0);
      const other = p.pastB + p.days.reduce((n, d) => n + value(m[p.b][d]), 0);
      return {...p, own, other, gap: own - other};
    });
    const score = [Math.max(0, ...pairs.map(p => Math.abs(p.gap) - 1)),
      pairs.reduce((n, p) => n + Math.max(0, Math.abs(p.gap) - 1) ** 2, 0),
      pairs.reduce((n, p) => n + p.gap ** 2, 0)];
    const preferences = (plan.preferences || []).map(p => ({...p, rows: p.rows.map(r => {
      const unmet = r.unmet + r.current.filter(d => d.rejected || !RosterPreferences.matches(d.code, m[r.i][d.d])).length;
      const submitted = r.submitted + r.current.length;
      return {...r, unmet, submitted, rate: (unmet + 1) / (submitted + 2)};
    })}));
    // Existing request type priority and small-sample correction remain intact.
    for (const type of ['AVOID', 'SHIFT', 'OFF']) {
      const rates = preferences.filter(p => p.type === type).flatMap(p => p.rows.map(r => r.rate));
      score.push(Math.max(0, ...rates), rates.reduce((n, r) => n + r * r, 0));
    }
    return {pairs, preferences, score, excluded: plan.excluded, assumptions: plan.assumptions};
  }
  async function chooseAnnual(x, m, baseline, people, {trial, stop, onProgress = () => {}}) {
    if (!enabled(x)) return baseline;
    const context = choice => ({...x, surplusPlan: {...x.surplusPlan, grants: [...x.surplusPlan.grants,
      {key: key(choice.owner.s), date: x.dates[choice.date].iso, source: 'auto', requestId: null, from: m[choice.owner.i][choice.date]}]}});
    let best = baseline, nx = context(best), q = RosterRecovery.current(nx, best.chosen);
    let score = evaluate(best.chosen, prepare(nx, best.chosen)).score;
    const began = Date.now(); let checked = 0;
    for (const owner of people) {
      // First/second leave rounds and current accumulated benefit ordering take
      // precedence. Expiry only distinguishes already tied allocation choices.
      if (owner.n !== baseline.owner.n || Math.abs(owner.history - baseline.owner.history) > 1e-8) continue;
      for (let d = 0; d < x.dates.length; d++) {
        if (stop() || Date.now() - began >= 150 || checked >= 12) return best;
        if (owner.i === baseline.owner.i && d === baseline.date || !['D', 'E', 'N'].includes(m[owner.i][d]) ||
            !RosterAnnual.activeDay(x, owner.s, d) || RosterEngine.fixed(x, owner.s, d).length) continue;
        checked++; const chosen = trial([[owner.i, d, 'LEAVE']]); if (!chosen) continue;
        const choice = {chosen, owner, date: d}, cx = context(choice), cq = RosterRecovery.current(cx, chosen);
        if (!RosterRecovery.noWorse(q.metrics, cq.metrics)) continue;
        if (cq.spread.rows.some((r, i) => r.episodes.length > q.spread.rows[i].episodes.length ||
          r.score.slice(0, 2).some((v, k) => v > q.spread.rows[i].score[k]))) continue;
        const nextScore = evaluate(chosen, prepare(cx, chosen)).score;
        if (RosterRecovery.cmp(nextScore, score) < 0) { best = choice; q = cq; score = nextScore; }
        onProgress(); await new Promise(r => setTimeout(r, 0));
      }
    }
    return best;
  }
  async function improve(x, r, {maxMs = 3500, maxChecks = 1000, onProgress = () => {}} = {}) {
    if (!enabled(x) || x.actualRecording || x.surplusPlan?.decision === 'KEEP') return r;
    const started = Date.now(), plan = prepare(x, r.matrix); let matrix = r.matrix, q = RosterRecovery.current(x, matrix);
    if (q.issues.some(e => e.level === 'error') || q.fair.breaches.length) return r;
    let score = evaluate(matrix, plan).score, checks = 0, proposals = 0, moves = 0, lastYield = started;
    const before = score.slice(), stop = () => Date.now() - started >= maxMs || checks >= maxChecks;
    while (!stop()) {
      let found = false;
      for (const next of RosterRecovery.candidates(x, matrix)) {
        if (stop()) break; proposals++;
        if (Date.now() - lastYield > 50) { onProgress(); await new Promise(r => setTimeout(r, 0)); lastYield = Date.now(); }
        const nextScore = evaluate(next, plan).score;
        if (RosterRecovery.cmp(nextScore, score) >= 0) continue;
        checks++; const checked = RosterRecovery.safe(x, matrix, next, q);
        if (!checked) continue;
        matrix = next; q = checked; score = nextScore; moves++; found = true; break;
      }
      if (!found) break;
    }
    return {...RosterRecovery.result(x, r, matrix, q), futureBalance: {version: 1, reconstructed: true,
      before, after: score, moves, checks, proposals, limited: stop(), ms: Date.now() - started}};
  }
  return {enabled, prepare, evaluate, improve, chooseAnnual, current: RosterRecovery.current};
})();

const RosterRebuild = (() => {
  const enabled = x => x?.restRebuildPolicy === 1;
  // A 3,3 -> 3,2 improvement is accepted without requiring the overall maximum
  // to fall first. Continue through one remaining episode toward zero.
  const rank = q => [...q.rows.map(r => r.episodes.length).sort((a, b) => b - a),
    q.rows.reduce((n, r) => n + r.restWindows.length, 0)];
  const WORK = new Set(['D', 'E', 'N', 'MID']);
  const REST = new Set(['OFF', 'LEAVE', 'M-LEAVE', 'SICK', 'MATERNITY', 'PARENTAL']);
  function boundaryPlan(x, s) {
    if (!enabled(x) || s.isDispatch || s.isPregnant) return [];
    const previous = s.previousShifts || [], windows = [];
    for (let end = 0; end < Math.min(6, x.dates.length); end++) {
      const needed = 6 - end, past = previous.slice(-needed);
      if (past.length !== needed || past.some(sh => !WORK.has(sh) && !REST.has(sh))) continue;
      if (Array.from({length: end + 1}, (_, d) => d).every(d => RosterTraining.trainee(x, s, d))) continue;
      const pastWork = past.filter(sh => WORK.has(sh)).length, minRest = Math.max(0, pastWork + end + 1 - 5);
      if (minRest) windows.push({end, minRest, pastWork});
    }
    return windows;
  }
  function boundaryCost(x, s, row, d, sh) {
    // Rest reservation influences the D/E fill stage, not the existing N
    // placement/density policy. Night recovery already has its own rules.
    if (!['D', 'E'].includes(sh) || d > 5 || WORK.has(row[d])) return 0;
    let cost = 0;
    for (const w of boundaryPlan(x, s)) {
      if (d > w.end) continue;
      const segment = row.slice(0, w.end + 1), rest = segment.filter(v => REST.has(v)).length;
      const free = segment.filter(v => v == null).length + Number(REST.has(row[d]));
      const remaining = Math.max(0, w.minRest - rest + Number(REST.has(row[d])));
      if (remaining) cost += 90 * remaining / Math.max(1, free) + (free - 1 < remaining ? 240 : 0);
    }
    return cost;
  }
  function* restCandidates(x, m, rows) {
    const people = x.staff.map((_, i) => i).sort((i, j) => rows[j].episodes.length - rows[i].episodes.length ||
      rows[j].restWindows.length - rows[i].restWindows.length || i - j);
    const mutable = (i, d) => RosterRecovery.mutable(x, m, i, d) && ['D', 'E', 'OFF'].includes(m[i][d]);
    const sameMonth = (d, t) => x.dates[d].iso.slice(0, 7) === x.dates[t].iso.slice(0, 7);
    for (const i of people) {
      if (!rows[i].restWindows.length) continue;
      const pressure = Array(x.dates.length).fill(0);
      for (const w of rows[i].restWindows) for (let d = Math.max(0, w.from); d <= w.to; d++) pressure[d] += w.from < 0 ? 4 : 1;
      const duties = x.dates.flatMap((_, d) => pressure[d] && ['D', 'E'].includes(m[i][d]) && mutable(i, d) ? [d] : [])
        .sort((d, t) => pressure[t] - pressure[d] || d - t);
      for (const d of duties) for (let t = 0; t < x.dates.length; t++) {
        if (!sameMonth(d, t) || m[i][t] !== 'OFF' || !mutable(i, t)) continue;
        const own = m.slice(); own[i] = m[i].slice(); [own[i][d], own[i][t]] = [own[i][t], own[i][d]];
        yield {matrix: own, stage: d < 6 ? 'boundary-DE-OFF' : 'own-DE-OFF'};
        const peers = people.filter(j => j !== i && mutable(j, d) && mutable(j, t));
        for (const j of peers) {
          const pair = own.slice(); pair[j] = m[j].slice(); [pair[j][d], pair[j][t]] = [pair[j][t], pair[j][d]];
          yield {matrix: pair, stage: 'two-person-DE-OFF'};
          // Three different codes circulate between three employees on two
          // dates. Every employee retains each shift count; daily totals also
          // stay exact for the cycle. N cells remain untouched in this stage.
          if (m[j][d] !== m[i][t]) continue;
          for (const k of peers) if (k !== j && m[k][d] === m[j][t] && m[k][t] === m[i][d]) {
            const next = pair.slice(); next[k] = m[k].slice(); [next[k][d], next[k][t]] = [next[k][t], next[k][d]];
            yield {matrix: next, stage: 'three-person-DE-OFF'};
          }
        }
      }
    }
  }
  function diagnoseBoost(x, before, candidate, prior) {
    const blocked = RosterRecovery.floorBlockers(x, candidate);
    if (!blocked.length || blocked.some(v => v.actual < v.minimum)) return null;
    const relaxed = {...x, surplusPlan: {...x.surplusPlan, floors: (x.surplusPlan.floors || []).map(f =>
      ({...f, floor: RosterEngine.quota(x, f.d, f.shift)}))}};
    const q = RosterRecovery.safe(relaxed, before, candidate, prior, {exactCounts: true, preserveDailyTotals: false});
    return q && RosterRecovery.cmp(rank(q.spread), rank(prior.spread)) < 0 ? {blocked, episodeReduction: prior.spread.independentWindows - q.spread.independentWindows,
      windowReduction: prior.spread.rows.reduce((n, r) => n + r.restWindows.length, 0) -
        q.spread.rows.reduce((n, r) => n + r.restWindows.length, 0)} : null;
  }
  async function improve(x, r, {maxMs = 5000, maxChecks = 1000, onProgress = () => {}} = {}) {
    if (!enabled(x) || x.actualRecording || x.surplusPlan?.decision === 'KEEP') return r;
    const started = Date.now(); let matrix = r.matrix, q = RosterRecovery.current(x, matrix);
    if (q.issues.some(e => e.level === 'error') || q.fair.breaches.length) return r;
    let score = rank(q.spread), checks = 0, proposals = 0, moves = 0, lastYield = started;
    const stages = [], boostDiagnostics = {checked: 0, examples: [], maximumEpisodeReduction: 0};
    const before = score.slice(), stop = () => Date.now() - started >= maxMs || checks >= maxChecks;
    while (!stop() && score[0] >= 1) {
      let found = false;
      const candidates = function* () {
        // Bounded targeted phase leaves a share of the time budget for whole
        // N/recovery blocks and broader interval exchanges.
        const phaseStart = Date.now();
        for (const c of restCandidates(x, matrix, q.spread.rows)) {
          if (Date.now() - phaseStart >= maxMs * 0.55) break;
          yield c;
        }
        for (const next of RosterRecovery.candidates(x, matrix, {blocks: true})) yield {matrix: next, stage: 'whole-block'};
      };
      for (const candidate of candidates()) {
        const next = candidate.matrix;
        if (stop()) break; proposals++;
        if (Date.now() - lastYield > 50) { onProgress(); await new Promise(r => setTimeout(r, 0)); lastYield = Date.now(); }
        const rows = q.spread.rows.map((r, i) => next[i] === matrix[i] ? r : RosterSpread.rowReport(x, x.staff[i], next[i]));
        const nextScore = rank({rows, repeatedStaff: rows.filter(r => r.episodes.length >= 2).length,
          independentWindows: rows.reduce((n, r) => n + r.episodes.length, 0)});
        if (RosterRecovery.cmp(nextScore, score) >= 0) continue;
        checks++; const checked = RosterRecovery.safe(x, matrix, next, q, {exactCounts: true, preserveDailyTotals: false});
        if (!checked) {
          if (boostDiagnostics.checked < 16 && RosterRecovery.floorBlockers(x, next).length) {
            boostDiagnostics.checked++;
            const diagnostic = diagnoseBoost(x, matrix, next, q);
            if (diagnostic) {
              boostDiagnostics.maximumEpisodeReduction = Math.max(boostDiagnostics.maximumEpisodeReduction, diagnostic.episodeReduction);
              if (boostDiagnostics.examples.length < 3) boostDiagnostics.examples.push(diagnostic);
            }
          }
          continue;
        }
        matrix = next; q = checked; score = nextScore; moves++; stages.push(candidate.stage); found = true; break;
      }
      if (!found) break;
    }
    return {...RosterRecovery.result(x, r, matrix, q), restRebuild: {version: 2, reconstructed: true,
      before, after: score, moves, checks, proposals, stages, boostDiagnostics,
      boundaryWindows: x.staff.map(s => boundaryPlan(x, s)), limited: stop(), ms: Date.now() - started}};
  }
  return {enabled, rank, improve, boundaryPlan, boundaryCost, restCandidates, diagnoseBoost};
})();
