/* Rest distribution v2. This is a quality objective, never an extra prohibition.
 * Protected inputs are immutable. Non-overlapping seven-day windows measure
 * repetition without counting the same six working days several times. */
const RosterSpread=(()=>{
  const legacy=RosterSpreadLegacy,WORK=new Set(['D','E','N','MID']);
  const REST=new Set(['OFF','LEAVE','M-LEAVE','SICK','MATERNITY','PARENTAL']);
  const SH=['D','E','N'],DAY=86400000,modern=x=>x?.restSpreadPolicy===2;
  const cmp=(a,b)=>{for(let k=0;k<Math.max(a.length,b.length);k++){const d=(a[k]||0)-(b[k]||0);if(Math.abs(d)>1e-8)return d;}return 0;};
  const date=(x,d)=>new Date(Date.parse(x.dates[0].iso+'T00:00:00Z')+d*DAY).toISOString().slice(0,10);
  const independent=windows=>{const out=[];let last=-Infinity;for(const w of [...windows].sort((a,b)=>a.to-b.to||a.from-b.from))if(w.from>last){out.push(w);last=w.to;}return out;};
  function rowReport(x,s,row,options={}){
    const base=legacy.rowReport(x,s,row,options);if(!modern(x))return base;
    const previous=s.previousShifts||[],next=RosterTraining.nextShifts(x,s)||[];
    const get=d=>d<0?previous[previous.length+d]??null:d>=row.length?next[d-row.length]??null:row[d];
    const windows=[];let peak=0;
    if(!s.isDispatch)for(let end=0;end<row.length;end++){
      const block=Array.from({length:7},(_,k)=>({d:end-6+k,sh:get(end-6+k)}));
      if(block.some(t=>t.sh==null||t.sh==='DISPATCH'))continue;
      const active=block.filter(t=>t.d>=0&&t.d<row.length);
      if(active.every(t=>RosterTraining.trainee(x,s,t.d)||['MATERNITY','PARENTAL'].includes(t.sh)))continue;
      const work=block.filter(t=>WORK.has(t.sh)),rest=block.filter(t=>REST.has(t.sh));peak=Math.max(peak,work.length);
      if(work.length<6)continue;
      const fixedWork=work.filter(t=>t.d<0||RosterEngine.fixed(x,s,t.d).includes(t.sh)||protectedRequest(x,s,t.d,t.sh)).length;
      windows.push({from:end-6,to:end,work:work.length,rest:rest.length,forced:fixedWork>=6});
    }
    const episodes=independent(windows),monthly={};
    for(const month of [...new Set(windows.map(w=>date(x,w.to).slice(0,7)))])monthly[month]=independent(windows.filter(w=>date(x,w.to).startsWith(month)));
    return {...base,restWindows:windows,episodes,monthlyEpisodes:monthly,peakWork:peak};
  }
  function rowObjective(row){return [row.score[0],Math.max(0,(row.episodes?.length||0)-1),row.score[1],row.score[2]];}
  function aggregate(rows){
    const maxRepeat=Math.max(0,...rows.map(r=>Math.max(0,(r.episodes?.length||0)-1)));
    return [rows.reduce((n,r)=>n+r.score[0],0),maxRepeat,rows.reduce((n,r)=>n+Math.max(0,(r.episodes?.length||0)-1),0),rows.reduce((n,r)=>n+r.score[1],0),rows.reduce((n,r)=>n+r.score[2],0)];
  }
  function objective(x,m){return modern(x)?aggregate(x.staff.map((s,i)=>rowReport(x,s,m[i]))):[];}
  function protectedRequest(x,s,d,shift){
    const t=x.dates[d],code=s.reqShiftsMap?.[t?.date],decision=s.requestDecisions?.[t?.date];
    return !!(code&&!(decision?.date===t.iso&&decision.code===code&&decision.status==='rejected')&&RosterPreferences.matches(code,shift));
  }
  function hasRequest(x,s,d){
    const t=x.dates[d],code=s.reqShiftsMap?.[t.date],decision=s.requestDecisions?.[t.date];
    return !!(code&&!(decision?.date===t.iso&&decision.code===code&&decision.status==='rejected'));
  }
  const preservesRequests=(x,before,after,ids)=>[...ids].every(i=>x.dates.every((_,d)=>!protectedRequest(x,x.staff[i],d,before[i][d])||protectedRequest(x,x.staff[i],d,after[i][d])));
  function assignmentCost(x,s,row,d,sh){
    if(!modern(x))return sh==='N'?legacy.nightCost(x,s,row,d):0;
    if(s.isDispatch||!WORK.has(sh))return 0;
    const prev=s.previousShifts||[],next=RosterTraining.nextShifts(x,s)||[];
    const get=k=>k<0?prev[prev.length+k]:k>=row.length?next[k-row.length]:row[k];
    let cost=sh==='N'?legacy.nightCost(x,s,row,d)*4:0;
    for(let from=d-6;from<=d;from++){
      let w=0;for(let k=from;k<from+7;k++)w+=WORK.has(get(k));
      const after=w+1-Number(WORK.has(row[d]));
      // A small look-ahead reserves room before a sixth duty is inevitable.
      const penalty=n=>70*Math.max(0,n-5)**2+2*Math.max(0,n-4)**2;
      cost+=penalty(after)-penalty(w);
    }
    return cost;
  }
  function offCost(x,s,row,d){
    if(!modern(x))return legacy.offCost(x,s,row,d);
    if(!WORK.has(row[d]))return legacy.offCost(x,s,row,d);
    const copy=row.slice(),sh=copy[d];copy[d]='OFF';
    return -assignmentCost(x,s,copy,d,sh)+legacy.offCost(x,s,row,d);
  }
  function safeRows(before,after){
    return after.score[0]<=before.score[0]&&after.score[1]<=before.score[1]&&
      (after.episodes?.length||0)<=Math.max(1,before.episodes?.length||0)&&
      after.singleNights+after.edgeSingles<=before.singleNights+before.edgeSingles&&after.nightRun<=Math.max(2,before.nightRun);
  }
  function notWorse(x,before,after,ids){return !modern(x)?legacy.notWorse(x,before,after,ids):[...ids].every(i=>safeRows(rowReport(x,x.staff[i],before[i]),rowReport(x,x.staff[i],after[i])));}
  function requiredLimitSafe(x,before,after,ids,improvesRequiredLimit){
    if(!modern(x)||!improvesRequiredLimit)return notWorse(x,before,after,ids);
    // A soft work-density goal cannot veto repair of the agreed weekend limit.
    // Night concentration and block integrity remain protected independently.
    return [...ids].every(i=>{const a=rowReport(x,x.staff[i],before[i]),b=rowReport(x,x.staff[i],after[i]);return b.score[0]<=a.score[0]&&b.singleNights+b.edgeSingles<=a.singleNights+a.edgeSingles&&b.nightRun<=Math.max(2,a.nightRun);});
  }
  const signature=(x,m)=>RosterPreferences.fingerprint({restSpreadPolicy:2,dates:x.dates,staff:x.staff,rules:x.rules,grants:x.surplusPlan?.grants},m);
  function report(x,m,run=null){
    if(!modern(x))return legacy.report(x,m,run);
    const old=legacy.report(x,m),rows=x.staff.map((s,i)=>({i,...rowReport(x,s,m[i],{details:true})}));
    const valid=run?.version===2&&run.signature===signature(x,m)?run:null;
    return {...old,rows,objective:aggregate(rows),run:valid,repeatedStaff:rows.filter(r=>r.episodes.length>=2).length,
      restStaff:rows.filter(r=>r.restWindows.length).length,independentWindows:rows.reduce((n,r)=>n+r.episodes.length,0)};
  }
  function diagnostics(x,m,run){
    if(!modern(x))return legacy.diagnostics(x,m,run);
    const r=report(x,m,run),out=legacy.diagnostics(x,m,null).filter(v=>v.code!=='REST_DROUGHT');
    for(const row of r.rows){
      if(!row.restWindows.length)continue;
      const example=[...row.restWindows].sort((a,b)=>b.work-a.work||a.from-b.from)[0],s=x.staff[row.i];
      const reasons=r.run?.reasons?.[row.i]||[],forced=row.restWindows.some(w=>w.forced);
      const description=forced?'확정조건·반영된 신청을 유지하면 남는 구간이 있습니다.':r.run?.status==='kept'?'관리자가 현재 배치를 유지했습니다.':r.run?.status==='blocked'?'필수조건 미충족을 먼저 확인해 주세요.':r.run?'현재 탐색 범위에서 조건을 지키는 추가 분산안을 찾지 못했습니다.':'근무가 몰린 날짜를 확인해 주세요.';
      out.push({phase:'post',category:'review',level:'warning',code:'REST_DROUGHT',staffId:s.id,d:Math.max(0,example.from),target:'scheduleTable',comparisonKey:s.id+'|rest-v2',
        message:`${s.name} · ${date(x,example.from).slice(5)}~${date(x,example.to).slice(5)}: 7일 중 근무 ${example.work}일${row.episodes.length>=2?' · 중복 없는 구간 '+row.episodes.length+'회':''}`,
        action:description+(reasons.length?' 확인된 제약: '+reasons.slice(0,2).join(', ')+'.':''),
        evidence:[{name:'판단 기준',detail:'OFF·연차·보건휴가·병가 등 출근하지 않는 날을 함께 확인합니다. 반복 횟수는 서로 겹치지 않는 7일 구간으로 셉니다. 2회 이상도 생성·확정을 막지 않습니다.'},
          ...row.episodes.map(w=>({name:date(x,w.from)+' ~ '+date(x,w.to),detail:`근무 ${w.work}일 · 휴식 ${w.rest}일${w.forced?' · 확정조건·반영된 신청 포함':''}`}))]});
    }
    return out;
  }
  function checked(x,result,status='checked'){
    if(!modern(x))return result;
    const r=report(x,result.matrix,result.spread),old=r.run;
    return {...result,restObjective:r.objective,spread:{version:2,signature:signature(x,result.matrix),status,finalChecked:true,moves:old?.moves||0,checks:old?.checks||0,ms:old?.ms||0,before:old?.before||r.score,after:r.score,reasons:old?.reasons||{},repeatedStaff:r.repeatedStaff,independentWindows:r.independentWindows,stages:old?.stages||[]}};
  }
  async function finalise(x,result,options={}){
    if(!modern(x))return result;
    let current=result;
    if(!x.actualRecording&&x.surplusPlan?.decision!=='KEEP'&&RosterWeekend.modern(x)&&RosterWeekend.report(x,current.matrix).limitExceeded)current=await RosterWeekend.improve(x,current,{...options,maxMs:5000,maxChecks:6000});
    const before=report(x,current.matrix),needs=before.score[0]||before.score[1];
    const next=needs?await improve(x,current,{...options,maxMs:3500,maxChecks:1800}):current;
    return checked(x,next,next.spread?.status||'checked');
  }
  async function recoverDrafts(x,result,pool,original,{onProgress=()=>{},maxCandidates=2,maxMs=45000}={}){
    if(!modern(x)||!original||x.actualRecording||RosterWeekend.report(x,result.matrix).currentGap<=2)return result;
    const clone=v=>JSON.parse(JSON.stringify(v)),started=Date.now(),E=RosterEngine,F=RosterFairness,trace=[];
    let best=result,bestInput=x,bestGap=RosterWeekend.report(x,result.matrix).currentGap;
    const candidates=pool.filter(r=>r.seed!==result.seed).slice(0,maxCandidates);
    for(const candidate of candidates){
      if(Date.now()-started>=maxMs)break;
      const nextInput=clone(original),deadline=Math.min(started+maxMs,Date.now()+7000),options={shouldStop:()=>Date.now()>=deadline};
      let next={...candidate,matrix:candidate.matrix.map(r=>r.slice())};
      next=E.balance(nextInput,E.repair(nextInput,next,{...options,passes:1,rounds:1,tradeBudget:1000}),F.prepare(nextInput),options);
      next={...next,issues:E.validate(nextInput,next.matrix),fairness:F.analyse(nextInput,next.matrix),preferences:RosterPreferences.analyse(nextInput,next.matrix)};
      if(next.issues.some(e=>e.level==='error')||next.fairness.breaches.length){trace.push({seed:candidate.seed,status:'unmet'});continue;}
      onProgress();await new Promise(r=>setTimeout(r,0));
      next=await RosterComposition.improve(nextInput,next,{onProgress});next=await RosterSurplus.apply(nextInput,next,{onProgress});
      const gap=RosterWeekend.report(nextInput,next.matrix).currentGap;
      trace.push({seed:candidate.seed,status:'checked',weekendGap:gap,rest:objective(nextInput,next.matrix)});
      if(next.issues.some(e=>e.level==='error')||next.fairness.breaches.length)continue;
      if(gap<bestGap){best=next;bestInput=nextInput;bestGap=gap;}
      if(bestGap<=2)break;
    }
    if(bestInput!==x){for(const field of ['surplusPlan','weekendPlan']){if(bestInput[field]===undefined)delete x[field];else x[field]=clone(bestInput[field]);}}
    return {...best,restFallback:{checked:trace.length,ms:Date.now()-started,adopted:best!==result,trace}};
  }
  async function improve(x,result,{maxMs=8500,maxChecks=5500,maxMoves=60,onProgress=()=>{}}={}){
    if(!modern(x))return legacy.improve(x,result,{maxMs:Math.min(maxMs,2200),maxChecks:Math.min(maxChecks,1400),onProgress});
    if(x.actualRecording||x.surplusPlan?.decision==='KEEP')return checked(x,result,x.actualRecording?'actual':'kept');
    const E=RosterEngine,F=RosterFairness,P=RosterPreferences,C=RosterComposition,T=RosterTraining,S=RosterSurplus;
    const started=Date.now();let lastYield=started,m=result.matrix.map(r=>r.slice()),issues=E.validate(x,m),fairness=F.analyse(x,m),preferences=P.analyse(x,m),composition=C.report(x,m);
    let rows=x.staff.map((s,i)=>rowReport(x,s,m[i])),score=aggregate(rows),checks=0,proposals=0,moves=0,limited=false;
    const before=report(x,m),reasons={},stages=[],cache=x.staff.map(()=>new Map());
    const stop=()=>{if(Date.now()-started>=maxMs||checks>=maxChecks||proposals>=100000||moves>=maxMoves){limited=true;return true;}return false;};
    const tick=async()=>{if(Date.now()-lastYield>55){onProgress();await new Promise(r=>setTimeout(r,0));lastYield=Date.now();}};
    const note=(ids,msg)=>{for(const i of ids){reasons[i]??=[];if(reasons[i].length<3&&!reasons[i].includes(msg))reasons[i].push(msg);}return null;};
    const key=s=>S.identity(s),grant=(i,d)=>x.surplusPlan?.grants?.find(g=>g.key===key(x.staff[i])&&g.date===x.dates[d].iso);
    const mutable=(i,d)=>{const s=x.staff[i],sh=m[i][d],g=grant(i,d);return !s.isDispatch&&!T.trainee(x,s,d)&&!E.fixed(x,s,d).length&&!hasRequest(x,s,d)&&!(x.weekendPlan?.credits||[]).some(c=>c.key===key(s)&&c.date===x.dates[d].iso)&&
      (SH.includes(sh)||sh==='OFF'||sh==='LEAVE'&&x.surplusPlan?.kind==='annual'&&g)&&!(g?.requestId||g?.source==='manual'||x.surplusPlan?.kind!=='annual'&&g?.source==='manager');};
    const sameMonth=(a,b)=>x.dates[a].iso.slice(0,7)===x.dates[b].iso.slice(0,7);
    const reportRow=(i,row)=>{const key=row.join(',');if(!cache[i].has(key)){if(cache[i].size>2500)cache[i].clear();cache[i].set(key,rowReport(x,x.staff[i],row));}return cache[i].get(key);};
    function moveGrants(next,ids){
      if(!x.surplusPlan)return null;
      const code=x.surplusPlan.kind==='annual'?'LEAVE':'OFF',updates=new Map();
      for(const i of ids){
        const lost=(x.surplusPlan.grants||[]).filter(g=>g.key===key(x.staff[i])&&next[i][x.dates.findIndex(t=>t.iso===g.date)]!==code);
        const gained=x.dates.flatMap((t,d)=>next[i][d]===code&&m[i][d]!==code?[d]:[]);
        if(code==='LEAVE'&&lost.length!==gained.length)return false;
        for(const g of lost){const at=gained.findIndex(d=>x.dates[d].iso.slice(0,7)===g.date.slice(0,7));if(at<0)return false;
          const d=gained.splice(at,1)[0];updates.set(g,{...g,date:x.dates[d].iso,from:m[i][d]});}
      }
      return updates.size?{...x.surplusPlan,grants:x.surplusPlan.grants.map(g=>updates.get(g)||g)}:x.surplusPlan;
    }
    function attempt(changes,stage){
      if(stop())return null;proposals++;
      changes=changes.filter(([i,d,sh])=>m[i][d]!==sh);if(!changes.length||changes.some(([i,d])=>!mutable(i,d)))return null;
      const ids=[...new Set(changes.map(c=>c[0]))],next=m.slice();ids.forEach(i=>next[i]=m[i].slice());for(const [i,d,sh] of changes)next[i][d]=sh;
      const changed=ids.map(i=>reportRow(i,next[i]));
      if(changed.some((r,k)=>!safeRows(rows[ids[k]],r)))return null;
      const nextRows=rows.slice();ids.forEach((i,k)=>nextRows[i]=changed[k]);const after=aggregate(nextRows);
      if(cmp(after,score)>=0)return null;
      // Preserve each employee's basic OFF and automatic leave in each month.
      for(const i of ids)for(const month of new Set(x.dates.map(t=>t.iso.slice(0,7))))for(const sh of ['OFF','LEAVE']){
        const count=row=>x.dates.reduce((n,t,d)=>n+Number(t.iso.startsWith(month)&&row[d]===sh),0);
        if(count(next[i])!==count(m[i]))return null;
      }
      const plan=moveGrants(next,ids);if(plan===false)return null;
      const nx=plan?{...x,surplusPlan:plan}:x;
      for(const i of ids){const error=E.patternIssuesForSurplus(nx,x.staff[i],next[i]).find(v=>v.level!=='warning');
        if(error)return note(ids,/RECOVERY|NOD|NOE|TRANSITION/.test(error.code)?'야간 회복·근무 전환':/OFF/.test(error.code)?'연속휴무·연차 연결':'연속근무·야간 제한');}
      checks++;
      const ni=E.validate(nx,next);if(ni.some(e=>e.level==='error'))return note(ids,'최소인원·선임·확정조건');
      const warnings=new Set(issues.filter(e=>e.level==='warning').map(e=>JSON.stringify(e)));
      if(ni.some(e=>e.level==='warning'&&!warnings.has(JSON.stringify(e))))return note(ids,'기간 경계·회복 확인');
      for(const floor of x.surplusPlan?.floors||[])if(x.staff.reduce((n,s,i)=>n+Number(next[i][floor.d]===floor.shift&&E.eligible(s,x.rules,nx,floor.d)&&E.covers(nx,s,floor.d,floor.shift)),0)<floor.floor)return note(ids,'확보한 보강 인원');
      const nf=F.analyse(nx,next);
      if(ids.some(i=>nf.counts[i].protectedOff!==fairness.counts[i].protectedOff)||nf.breaches.some(b=>b.gap>Math.max(b.limit,fairness.breaches.find(p=>p.key===b.key&&p.shift===b.shift&&p.scope===b.scope&&p.month===b.month)?.gap||0)))return note(ids,'근무횟수 공평성');
      if(!RosterWeekend.notWorseLimit(nx,m,next))return note(ids,'주말 OFF 최대 차이');
      const np=P.analyse(nx,next);if(preferences.rows.some((r,i)=>r.details.some(v=>v.status==='applied'&&np.rows[i].details.find(t=>t.d===v.d&&t.code===v.code)?.status!=='applied')))return note(ids,'반영된 신청');
      const nc=C.report(nx,next);
      if(nc.days.some((day,d)=>cmp(day.score.slice(0,2),composition.days[d].score.slice(0,2))>0)||nc.periodGroups.some(g=>g.gap>Math.max(1,composition.periodGroups.find(p=>p.key===g.key)?.gap||0)))return note(ids,'선임 집중 방지');
      return {matrix:next,rows:nextRows,score:after,issues:ni,fairness:nf,preferences:np,composition:nc,plan,stage,ids};
    }
    function commit(c){m=c.matrix;rows=c.rows;score=c.score;issues=c.issues;fairness=c.fairness;preferences=c.preferences;composition=c.composition;if(c.plan)x.surplusPlan=c.plan;moves++;c.ids.forEach(i=>delete reasons[i]);stages.push(c.stage);}
    const swaps=(ids,d,t)=>ids.flatMap(i=>[[i,d,m[i][t]],[i,t,m[i][d]]]);
    if(!issues.some(e=>e.level==='error'))for(let pass=0;!stop();pass++){
      let chosen=null;
      const people=x.staff.map((_,i)=>i).sort((a,b)=>cmp(rowObjective(rows[b]),rowObjective(rows[a]))||a-b);
      const shortStart=proposals;
      search:for(const i of people){
        if(!rows[i].score[0]&&!rows[i].score[1])continue;
        const pressure=Array(x.dates.length).fill(0);
        for(const w of rows[i].restWindows)for(let d=Math.max(0,w.from);d<=w.to;d++)pressure[d]+=WORK.has(m[i][d])?1:0;
        if(rows[i].score[0])m[i].forEach((sh,d)=>{if(sh==='N')pressure[d]+=20;});
        const days=x.dates.map((_,d)=>d).filter(d=>pressure[d]>0&&SH.includes(m[i][d])&&mutable(i,d)).sort((a,b)=>pressure[b]-pressure[a]||a-b);
        for(const d of days){
          const rests=x.dates.map((_,t)=>t).filter(t=>t!==d&&sameMonth(d,t)&&['OFF','LEAVE'].includes(m[i][t])&&mutable(i,t)).sort((a,b)=>Math.abs(d-b)-Math.abs(d-a));
          for(const t of rests){
            if(stop()||proposals-shortStart>=3500)break search;await tick();
            chosen=attempt(swaps([i],d,t),'own-date');if(chosen)break search;
            // Keep the monthly OFF total while allowing D/E within their
            // agreed fairness limits. Exact shift counts must not freeze rest.
            if(['D','E'].includes(m[i][d]))for(const sh of ['D','E'])if(sh!==m[i][d]){
              chosen=attempt([[i,d,m[i][t]],[i,t,sh]],'own-date-shift');if(chosen)break search;
            }
            const peers=people.filter(j=>j!==i&&mutable(j,d)&&mutable(j,t));
            for(const j of peers){
              chosen=attempt(swaps([i,j],d,t),'two-person');if(chosen)break search;
            }
            // A cycle of three or four owners preserves all daily shift counts.
            const first=m[i][d],last=m[i][t];
            for(const j of peers){if(m[j][d]!==last)continue;
              for(const k of peers){if(k===j||m[k][d]!==m[j][t])continue;
                if(m[k][t]===first){chosen=attempt(swaps([i,j,k],d,t),'three-person');if(chosen)break search;}
                for(const l of peers){if(l===j||l===k||m[l][d]!==m[k][t]||m[l][t]!==first)continue;
                  chosen=attempt(swaps([i,j,k,l],d,t),'four-person');if(chosen)break search;}
              }
            }
          }
        }
      }
      if(chosen){commit(chosen);continue;}
      if(stop())break;
      const broadStart=proposals;
      // Broader atomic intervals keep night blocks and recovery days together.
      broad:for(const i of people){
        if(!rows[i].score[0]&&!rows[i].score[1])continue;
        const anchors=[...new Set([...rows[i].restWindows.map(w=>Math.max(0,w.from)),...m[i].flatMap((sh,d)=>rows[i].score[0]&&sh==='N'?[d]:[])])];
        const spans=new Map();
        for(const width of [4,7,10,14])for(const anchor of anchors)for(const offset of [-3,0,3]){
          const from=Math.max(0,Math.min(x.dates.length-width,anchor+offset)),to=Math.min(x.dates.length,from+width);
          if(to>from)spans.set(from+':'+to,Array.from({length:to-from},(_,k)=>from+k));
        }
        const peers=people.filter(j=>j!==i&&!x.staff[j].isDispatch).sort((a,b)=>Number(x.staff[b].isSenior===x.staff[i].isSenior)-Number(x.staff[a].isSenior===x.staff[i].isSenior));
        for(const ds of spans.values()){
          if(stop()||proposals-broadStart>=6500)break broad;await tick();
          for(const j of peers){
            chosen=attempt(ds.flatMap(d=>[[i,d,m[j][d]],[j,d,m[i][d]]]),'interval-'+ds.length);if(chosen)break broad;
          }
          // Expand participants only after direct interval exchanges fail.
          for(let a=0;a<Math.min(10,peers.length);a++)for(let b=a+1;b<Math.min(10,peers.length);b++){
            const j=peers[a],k=peers[b];if(stop())break broad;
            chosen=attempt(ds.flatMap(d=>[[i,d,m[j][d]],[j,d,m[k][d]],[k,d,m[i][d]]]),'three-person-interval-'+ds.length);if(chosen)break broad;
            chosen=attempt(ds.flatMap(d=>[[i,d,m[k][d]],[k,d,m[j][d]],[j,d,m[i][d]]]),'three-person-interval-'+ds.length);if(chosen)break broad;
          }
        }
      }
      if(!chosen)break;commit(chosen);
    }
    const after=report(x,m),spread={version:2,signature:signature(x,m),status:issues.some(e=>e.level==='error')?'blocked':limited?'limited':'checked',moves,checks,proposals,ms:Date.now()-started,before:before.score,after:after.score,reasons,stages,repeatedStaff:after.repeatedStaff,independentWindows:after.independentWindows};
    return {...result,matrix:m,issues,fairness,preferences,composition,spread,restObjective:after.objective,carryover:E.carryover(x,m)};
  }
  return {...legacy,modern,rowReport,report,diagnostics,improve,notWorse,assignmentCost,offCost,objective,finalise,checked,independent,preservesRequests,requiredLimitSafe,recoverDrafts};
})();
