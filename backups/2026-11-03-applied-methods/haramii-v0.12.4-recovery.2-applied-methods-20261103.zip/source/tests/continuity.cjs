const assert=require('node:assert/strict'),{domains,fixture,result,json}=require('./helpers.cjs'),a=domains();let passed=0;
const input=o=>({...fixture(o),weekendPolicy:2,restSpreadPolicy:2,continuityPolicy:1});
const test=async(name,fn)=>{await fn();passed++;console.log('PASS',name);};
(async()=>{
 await test('과거 주말 부족 보정을 당월 횟수 같게 만들기보다 우선하고, 다시 악화시키지 않음',()=>{
  const x=input({start:'2026-08-31',days:7,n:2,seniors:0,quota:{D:0,E:0,N:0}}),past=input({start:'2026-08-03',days:28,n:2,seniors:0,quota:{D:0,E:0,N:0}}),pm=past.staff.map(()=>Array(28).fill('D'));
  const wd=past.dates.flatMap((t,d)=>t.isSat||t.isSun?[d]:[]);wd.slice(0,4).forEach(d=>pm[0][d]='OFF');wd.slice(0,2).forEach(d=>pm[1][d]='OFF');
  x.surplusHistory={version:1,periods:[{status:'actual',start:past.dates[0].iso,end:past.dates.at(-1).iso,input:past,plan:{grants:[]},actualGrants:[],actual:pm}]};
  const balanced=[Array(7).fill('D'),['D','D','D','D','D','OFF','OFF']],equal=json(balanced);equal[0][5]='OFF';equal[1][5]='D';
  assert.equal(a.Weekend.report(x,balanced).rollingGap,0);assert.equal(a.Weekend.report(x,equal).currentGap,0);assert.equal(a.Weekend.report(x,equal).rollingGap,2);
  assert.equal(a.Continuity.weekendSafe(x,balanced,equal),false);assert.equal(a.Continuity.weekendSafe(x,equal,balanced),true);
  const bp=a.Weekend.evaluate(balanced,a.Weekend.prepare(x,balanced)),ep=a.Weekend.evaluate(equal,a.Weekend.prepare(x,equal));assert(bp.score[2]<ep.score[2]);
 });
 await test('N 집중 비용은 직전·다음 알려진 근무를 연결하고 일반 D/E 추가에서는 N 횟수를 바꾸지 않음',()=>{
  const x=input({days:14,n:1,seniors:0,quota:{D:0,E:0,N:0}}),s=x.staff[0];s.previousShifts=['N','N','OFF','OFF','N','OFF'];
  const row=Array(14).fill('OFF');assert(a.Continuity.nightDelta(x,s,row,0,'N')>0);assert.equal(a.Continuity.nightDelta(x,s,row,8,'N'),0);assert.equal(a.Continuity.nightDelta(x,s,row,0,'D'),0);
  for(let d=0;d<14;d++)for(const sh of ['D','E','N','OFF']){const next=row.slice();next[d]=sh;assert.equal(a.Continuity.nightDelta(x,s,row,d,sh),a.Continuity.nightScore(x,s,next)-a.Continuity.nightScore(x,s,row));}
  s.previousShifts=[];s.nextShifts=['OFF','N','N','OFF','OFF','N'];assert(a.Continuity.nightDelta(x,s,row,13,'N')>0);assert.equal(a.Continuity.nightDelta(x,s,row,5,'N'),0);
  for(let d=0;d<14;d++){const next=row.slice();next[d]='N';assert.equal(a.Continuity.nightDelta(x,s,row,d,'N'),a.Continuity.nightScore(x,s,next)-a.Continuity.nightScore(x,s,row));assert.equal(a.Continuity.nightScore(x,s,next),a.B.rowReport(x,s,next).score[0]);}
  s.isNightOnly=true;assert.equal(a.Continuity.nightDelta(x,s,row,0,'N'),0);
 });
 await test('N·회복 묶음을 함께 옮겨 7일 N 4회를 없애며 개인 근무·휴무 총량 보존',async()=>{
  const x=input({days:14,n:1,seniors:0,quota:{D:0,E:0,N:0}}),m=['N N OFF OFF N N OFF OFF D D D OFF OFF D'.split(' ')];
  const r=await a.Continuity.improve(x,result(a,x,m),{maxMs:3000});assert(a.B.report(x,m).score[0]>0);assert.equal(a.B.report(x,r.matrix).score[0],0);assert.equal(r.issues.filter(e=>e.level==='error').length,0);
  for(const sh of ['D','E','N','OFF'])assert.equal(r.matrix[0].filter(v=>v===sh).length,m[0].filter(v=>v===sh).length);assert(r.continuity.stages.some(s=>s.startsWith('own-bundle')));assert(a.Weekend.report(x,r.matrix,r.weekend).run);
 });
 await test('확정 신청·실제 근무·관리자 유지 결정은 재조정하지 않음',async()=>{
  const x=input({days:14,n:1,seniors:0,quota:{D:0,E:0,N:0}}),m=['N N OFF OFF N N OFF OFF D D D OFF OFF D'.split(' ')];
  for(const [d,t] of x.dates.entries())x.staff[0].reqShiftsMap[t.date]=m[0][d];
  const r=await a.Continuity.improve(x,result(a,x,m),{maxMs:1000});assert.deepEqual(json(r.matrix),m);assert(a.B.diagnostics(x,m).some(v=>v.code==='NIGHT_DENSITY'&&v.level==='warning'));
  for(const status of ['actual','KEEP']){const y=json(x);if(status==='actual')y.actualRecording=true;else y.surplusPlan={decision:'KEEP'};const r=await a.Continuity.improve(y,result(a,y,m));assert.deepEqual(json(r.matrix),m);}
 });
 await test('N 집중을 다른 직원에게 넘기는 변경과 누적 주말 보정을 되돌리는 변경은 거절',()=>{
  const x=input({days:8,n:2,seniors:0,quota:{D:0,E:0,N:0}}),before=[['N','N','OFF','OFF','N','N','OFF','OFF'],Array(8).fill('OFF')],after=json(before);[after[0],after[1]]=[after[1],after[0]];
  assert.equal(a.Continuity.nightSafe(x,before,after,[0,1]),false);
 });
 await test('실제 실패 초안의 근무횟수 조정에서도 N 집중을 새로 만들지 않고 공평성 한도 충족',()=>{
  const v=require('./fixtures/continuity-balance.json'),x=json(v.input),m=json(v.matrix);assert.equal(a.B.report(x,m).score[0],0);assert.equal(a.F.analyse(x,m).breaches.length,3);
  const r=a.E.balance(x,result(a,x,m),a.F.prepare(x));assert.equal(r.issues.filter(e=>e.level==='error').length,0);assert.equal(r.fairness.breaches.length,0);assert.equal(a.B.report(x,r.matrix).score[0],0);
 });
 await test('날짜 미지정 보건휴가도 개인 일수 유지, 지정 보건휴가 날짜는 보호',async()=>{
  for(const [requested,d] of [[false,2],[true,2],[false,3]]){const x=input({days:14,n:1,seniors:0,quota:{D:0,E:0,N:0}}),m=['N N OFF OFF N N OFF OFF D D D OFF OFF D'.split(' ')],s=x.staff[0];m[0][d]='M-LEAVE';s.isMLeaveActive=true;s.mLeaveOption='EXTRA';if(requested)s.reqShiftsMap[x.dates[d].date]='M';
   const r=await a.Continuity.improve(x,result(a,x,m),{maxMs:3000});assert.equal(r.matrix[0].filter(sh=>sh==='M-LEAVE').length,1);if(requested||a.Weekend.weekend(x.dates[d]))assert.equal(r.matrix[0][d],'M-LEAVE');assert.equal(r.issues.filter(e=>e.level==='error').length,0);
  }
 });
 await test('겹치는 밀집 창의 개수가 주말 부족 보정을 막지 않으며 독립 반복·N 집중은 보호',async()=>{
  const v=require('./fixtures/continuity-weekend.json'),x=json(v.input),m=json(v.matrix),before=a.B.report(x,m);assert.equal(a.Weekend.report(x,m).rollingGap,4);
  const r=await a.Continuity.improve(x,result(a,x,m),{maxMs:16000}),after=a.B.report(x,r.matrix);assert(a.Weekend.report(x,r.matrix).rollingGap<=3);assert.equal(after.score[0],0);assert(after.repeatedStaff<=before.repeatedStaff);
  after.rows.forEach((row,i)=>{assert(row.episodes.length<=Math.max(1,before.rows[i].episodes.length));assert(row.peakWork<=Math.max(6,before.rows[i].peakWork));});assert.equal(r.issues.filter(e=>e.level==='error').length,0);assert.equal(r.fairness.breaches.length,0);
 });
 await test('새 정책 저장·복원 및 잘못된 입력 거절',async()=>{
  const x=input({days:14,n:1,seniors:0,quota:{D:0,E:0,N:0}}),m=[Array(14).fill('OFF')],r=result(a,x,m),ui=require('./ui-harness.cjs')();
  ui.ctx.inputFixture=json(x);ui.ctx.resultFixture=json(r);ui.run('lastInput=inputFixture;lastResult=resultFixture;globalStaffData=lastInput.staff;dirty=false;generating=false;renderAll()');
  let download;ui.ctx.URL={createObjectURL:b=>{download=b;return 'blob:continuity'},revokeObjectURL(){}};ui.run('saveFile()');const text=await download.text(),data=JSON.parse(text);assert.equal(data.input.continuityPolicy,1);
  ui.ctx.file={size:text.length,text:async()=>text};await ui.run('loadFile(file)');assert.equal(ui.run('lastInput.continuityPolicy'),1);
  data.input.continuityPolicy=999;const invalid=JSON.stringify(data);ui.ctx.bad={size:invalid.length,text:async()=>invalid};await ui.run('loadFile(bad)');assert.equal(ui.run('lastInput.continuityPolicy'),1);assert(ui.notices.some(s=>s.includes('누적 주말·야간 분산 기준')));
  data.input.continuityPolicy=1;delete data.input.weekendPolicy;const mixed=JSON.stringify(data);ui.ctx.bad={size:mixed.length,text:async()=>mixed};await ui.run('loadFile(bad)');assert.equal(ui.run('lastInput.weekendPolicy'),2);
 });
 console.log(JSON.stringify({passed}));
})().catch(e=>{console.error(e.stack);process.exit(1)});
