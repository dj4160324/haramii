const assert=require('node:assert/strict');
const {domains,fixture,result,json,html}=require('./helpers.cjs');
const a=domains(),{E,S,C,B}=a;let passed=0;
const fresh=options=>fixture({days:3,n:1,seniors:0,quota:{D:0,E:0,N:0},...options});
const codes=(x,row)=>E.patternIssuesForSurplus(x,x.staff[0],row).map(p=>p.code);
async function test(name,fn){await fn();console.log('PASS '+name);passed++;}
(async()=>{
 await test('D/E 금지 두 선택은 독립적이고 구버전의 미지정 값은 허용',()=>{
  for(const d of [false,true])for(const e of [false,true]){
   const x=fresh();x.rules.noNOD=d;x.rules.noNOE=e;
   assert.equal(codes(x,['N','OFF','D']).includes('NOD'),d);
   assert.equal(codes(x,['N','OFF','E']).includes('NOE'),e);
   assert(!codes(x,['N','OFF','D']).includes('NOE'));
  }
  const old=fresh();assert(!codes(old,['N','OFF','E']).includes('NOE'));
 });
 await test('OFF 1일만 새 제한에 포함하고 연속 N 회복·즉시 전환은 별도 유지',()=>{
  const x=fresh({days:4});x.rules.noNOE=true;
  assert(codes(x,['N','OFF','E','OFF']).includes('NOE'));
  assert(!codes(x,['N','OFF','OFF','E']).includes('NOE'));
  for(const leave of ['LEAVE','M-LEAVE','SICK','MATERNITY','PARENTAL'])assert(!codes(x,['N',leave,'E','OFF']).includes('NOE'));
  for(const enabled of [false,true]){x.rules.noNOE=enabled;assert(codes(x,['N','N','OFF','E']).includes('N_RECOVERY'));assert(codes(x,['N','E','OFF','OFF']).includes('TRANSITION'));}
 });
 await test('월 경계의 직전·다음 근무 연결, 미입력과 기간 밖 단독 패턴 제외',()=>{
  const x=fresh({start:'2026-10-01',days:2});x.rules.noNOE=true;const s=x.staff[0];
  s.previousShifts=['N','OFF'];assert(codes(x,['E','OFF']).includes('NOE'));
  s.previousShifts=['N'];assert(codes(x,['OFF','E']).includes('NOE'));
  s.previousShifts=['N',null];assert(!codes(x,['E','OFF']).includes('NOE'));
  s.previousShifts=['N','OFF','E'];assert(!codes(x,['OFF','OFF']).includes('NOE'));
  s.nextShifts=['E'];assert(codes(x,['N','OFF']).includes('NOE'));
  s.nextShifts=['OFF','E'];assert(codes(x,['OFF','N']).includes('NOE'));
  s.nextShifts=[null,'E'];assert(!codes(x,['OFF','N']).includes('NOE'));
  s.nextShifts=['N','OFF','E'];assert(!codes(x,['OFF','OFF']).includes('NOE'));
  const cycle=fresh({start:'2026-10-19',days:28});cycle.rules.noNOE=true;const row=Array(28).fill('OFF');row[12]='N';row[14]='E';assert.equal(cycle.dates[14].iso,'2026-11-02');assert(codes(cycle,row).includes('NOE'));
 });
 await test('N·OFF·E 어느 칸을 채워도 금지 패턴 후보를 거절',()=>{
  const x=fresh();x.rules.noNOE=true;
  for(const [row,d,sh] of [[['N','OFF',null],2,'E'],[[null,'OFF','E'],0,'N'],[['N',null,'E'],1,'OFF']])assert.equal(E.canAssign(x,[row],0,d,sh),false);
  x.rules.noNOE=false;assert(E.canAssign(x,[['N','OFF',null]],0,2,'E'));
 });
 await test('사전 검사는 알려진 확정 충돌만 증명하고 새 설정으로 안내',()=>{
  const x=fresh({days:1});x.rules.noNOE=true;x.staff[0].previousShifts=['N','OFF'];
  x.rules.weekday={D:0,E:1,N:0};x.rules.weekend=x.rules.weekday;
  const check=E.preflightDetails(x);assert(check.issues.some(p=>p.code==='QUOTA'||p.code==='DAILY_CAPACITY'||p.message.includes('E')));
  const y=fresh({days:1});y.rules.noNOE=true;y.staff[0].previousShifts=['N'];y.staff[0].nextShifts=['E'];y.staff[0].offDayIndicesArray=[y.dates[0].dayIndex];
  assert(E.preflightDetails(y).issues.some(p=>p.code==='NOE'&&p.target==='ruleNoNOE'));
  y.staff[0].offDayIndicesArray=[];assert(!E.preflightDetails(y).issues.some(p=>p.code==='NOE'&&p.category==='proof'));
  const z=fresh();z.rules.noNOE=true;const m=[['N','OFF','E']],items=E.explainIssues(z,m,E.validate(z,m));assert(items.some(p=>p.code==='NOE'&&p.target==='ruleNoNOE'));
 });
 await test('첫 페이지 위치·기본 OFF·선택 저장·구버전 복원·수동 수정 검사',async()=>{
  const ui=require('./ui-harness.cjs')();assert.equal(ui.el('ruleNoNOE').checked,false);
  ui.ctx.staffFixture=json(fresh().staff);ui.run('globalStaffData=staffFixture');
  assert(html.indexOf('id="ruleNoNOE"')>html.indexOf('id="ruleNoNOD"'));assert.match(html,/<label for="ruleNoNOD">[^<]+<\/label><\/div><\/div>\s*<div class="rule-checkbox-item"><input[^>]*id="ruleNoNOE"/);
  for(const d of [false,true])for(const e of [false,true]){ui.el('ruleNoNOD').checked=d;ui.el('ruleNoNOE').checked=e;assert.equal(ui.run('collectInput().rules.noNOD'),d);assert.equal(ui.run('collectInput().rules.noNOE'),e);}
  const x=fresh();x.rules.noNOE=true;ui.ctx.x=json(x);ui.ctx.r=json(result(a,x,[['N','OFF','OFF']]));ui.run('lastInput=x;lastResult=r;globalStaffData=x.staff;dirty=false;renderAll()');
  let downloaded;ui.ctx.URL={createObjectURL:blob=>{downloaded=blob;return 'blob:night'},revokeObjectURL(){}};ui.run('saveFile()');const text=await downloaded.text(),saved=JSON.parse(text);
  assert.equal(saved.controls.ruleNoNOE,true);assert.equal(saved.input.rules.noNOE,true);
  ui.el('ruleNoNOE').checked=false;ui.ctx.testFile={size:text.length,text:async()=>text};await ui.run('loadFile(testFile)');assert(ui.el('ruleNoNOE').checked);assert(ui.run('lastInput.rules.noNOE'));
  ui.run('openCell(0,2)');ui.el('editShift').value='E';ui.run('applyCell();audit()');assert(ui.run("lastResult.issues.some(x=>x.code==='NOE')"));assert(ui.el('confirmScheduleBtn').disabled);assert.match(ui.el('diagnosticList').innerHTML,/N → OFF → E/);
  delete saved.controls.ruleNoNOE;delete saved.input.rules.noNOE;const old=JSON.stringify(saved);ui.ctx.testFile={size:old.length,text:async()=>old};await ui.run('loadFile(testFile)');assert.equal(ui.el('ruleNoNOE').checked,false);assert.equal(ui.run('lastInput.rules.noNOE'),undefined);
  assert(!ui.notices.some(s=>/실패/.test(s)),ui.notices.join('\n'));
 });
 await test('실제 근무는 위반을 표시하면서 사실대로 보존',async()=>{
  const x=fresh({n:2});x.rules.noNOE=true;const m=[['N','OFF','OFF'],['D','OFF','OFF']],r=await S.apply(x,result(a,x,m));
  let h=S.savePlan(null,x,r);const actual=r.matrix.map(row=>row.slice());actual[0]=['N','OFF','E'];h=S.confirmActual(h,h.periods[0].key,actual,{today:'2026-10-30'});
  assert(h.periods[0].actualIssues.some(p=>p.code==='NOE'));assert.deepEqual(json(h.periods[0].actual[0]),actual[0]);S.validateHistory(json(h));
 });
 await test('네 배분 모드의 보강·선임 균형·N/OFF 분산에서 금지 조건 유지',async()=>{
  for(const mode of ['MINIMUM','OFF','DE','DEN']){
   const x=fixture({days:8,n:12,seniors:8,quota:{D:1,E:1,N:1},mode:mode==='MINIMUM'?'OFF':mode,enabled:mode!=='MINIMUM'});x.rules.noNOE=true;x.rules.noNOD=true;
   const m=['N N OFF OFF D D OFF OFF','OFF OFF N N OFF OFF D D','D D OFF OFF N N OFF OFF','OFF OFF D D OFF OFF N N','E E OFF OFF D D OFF OFF','OFF OFF E E OFF OFF D D','D D OFF OFF E E OFF OFF','OFF OFF D D OFF OFF E E','E E OFF OFF D D OFF OFF','OFF OFF E E OFF OFF D D','D D OFF OFF E E OFF OFF','OFF OFF D D OFF OFF E E'].map(s=>s.split(' '));
   assert(!E.validate(x,m).some(p=>p.level==='error'));
   let r=await S.apply(x,result(a,x,m));r=await C.improve(x,r);r=await B.improve(x,r);
   assert(!r.issues.some(p=>p.level==='error'));assert(r.spread);assert.equal(r.fairness.breaches.length,0);
  }
 });
 console.log(JSON.stringify({passed}));
})().catch(e=>{console.error(e);process.exit(1)});
