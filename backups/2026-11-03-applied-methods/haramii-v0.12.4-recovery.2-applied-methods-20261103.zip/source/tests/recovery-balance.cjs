const assert = require('node:assert/strict');
const {domains, fixture, result, json} = require('./helpers.cjs');
const a = domains(); let passed = 0;
const input = o => ({...fixture(o), weekendPolicy:2, restSpreadPolicy:2, continuityPolicy:1, futureBalancePolicy:1, restRebuildPolicy:1});
async function test(name, fn) { await fn(); passed++; console.log('PASS', name); }
function weekendCase() {
  const x = input({start:'2026-11-02',days:7,n:2,seniors:0,quota:{D:0,E:0,N:0}});
  const history = [];
  for (const [start, who] of [['2026-09-07',1],['2026-10-05',0]]) {
    const p = input({start,days:7,n:2,seniors:0,quota:{D:0,E:0,N:0}}), m = p.staff.map(() => Array(7).fill('D'));
    m[who][5] = 'OFF'; history.push({status:'actual',start:p.dates[0].iso,end:p.dates.at(-1).iso,input:p,plan:{grants:[]},actualGrants:[],actual:m});
  }
  x.surplusHistory = {version:1,periods:history};
  const m = ['D D OFF D OFF OFF OFF'.split(' '),'D OFF D OFF D OFF D'.split(' ')];
  return {x,m};
}
(async () => {
  await test('달력 만료 후 남는 실제 공통 날짜만 계산하고 미확정 미래는 추가하지 않음', () => {
    const {x,m} = weekendCase(), before = JSON.stringify(x), p = a.Future.prepare(x,m), q = a.Future.evaluate(m,p);
    const december = q.pairs.find(v => v.metric === 'weekend' && v.offset === 1);
    const january = q.pairs.find(v => v.metric === 'weekend' && v.offset === 2);
    assert.equal(december.start,'2026-10-01'); assert.equal(december.own,3); assert.equal(december.other,1);
    assert.equal(january.start,'2026-11-01'); assert.equal(january.own,2); assert.equal(january.other,1);
    assert.equal(december.observedDays,4); assert.equal(january.observedDays,2);
    assert.equal(JSON.stringify(x),before); assert(q.pairs.every(v => v.days.every(d => d < m[0].length)));
  });
  await test('현재 균형 동률에서 잔존 기록의 주말 편차를 실제 교환으로 줄임', async () => {
    const {x,m} = weekendCase(), frozen = JSON.stringify(x), original = a.Recovery.current(x,m);
    const r = await a.Future.improve(x,result(a,x,m),{maxMs:2000});
    assert(r.futureBalance.moves > 0); assert(a.Recovery.cmp(r.futureBalance.after,r.futureBalance.before) < 0);
    assert(a.Recovery.noWorse(original.metrics,a.Recovery.current(x,r.matrix).metrics));
    assert.equal(a.E.validate(x,r.matrix).filter(e=>e.level==='error').length,0);
    assert.equal(JSON.stringify(x),frozen); assert.deepEqual(m,['D D OFF D OFF OFF OFF'.split(' '),'D OFF D OFF D OFF D'.split(' ')]);
  });
  await test('미래 점수가 좋아져도 현재 주말 균형이 악화되면 거절', () => {
    const {x,m} = weekendCase(); m[1][5]='D';
    const candidate=json(m); [candidate[0][6],candidate[1][6]]=[candidate[1][6],candidate[0][6]];
    // Reverse direction from a currently balanced candidate to its worse predecessor.
    assert(a.Weekend.report(x,candidate).currentGap < a.Weekend.report(x,m).currentGap);
    assert.equal(a.Recovery.safe(x,candidate,m,a.Recovery.current(x,candidate)),null);
  });
  await test('확정 OFF·반영된 신청과 실제 기록·KEEP 결정을 보호', async () => {
    const {x,m}=weekendCase(), candidate=json(m); [candidate[0][6],candidate[1][6]]=[candidate[1][6],candidate[0][6]];
    x.staff[0].reqShiftsMap[x.dates[6].date]='OFF';
    assert.equal(a.Recovery.safe(x,m,candidate,a.Recovery.current(x,m)),null);
    delete x.staff[0].reqShiftsMap[x.dates[6].date]; x.staff[0].offDayIndicesArray=[0];
    assert.equal(a.Recovery.safe(x,m,candidate,a.Recovery.current(x,m)),null);
    for(const policy of ['actual','KEEP','legacy']) {
      const y=json(x); if(policy==='actual')y.actualRecording=true;
      if(policy==='KEEP')y.surplusPlan={decision:'KEEP'};
      if(policy==='legacy'){delete y.futureBalancePolicy;delete y.restRebuildPolicy;}
      const r=result(a,y,m); assert.strictEqual(await a.Future.improve(y,r),r); assert.strictEqual(await a.Rebuild.improve(y,r),r);
    }
  });
  await test('기록이 없는 직원과 특수 비교군을 미래 주말 비교에 끼워 넣지 않음', () => {
    const {x,m}=weekendCase(); x.staff[1].isNightOnly=true;
    const q=a.Future.evaluate(m,a.Future.prepare(x,m)); assert(!q.pairs.some(p=>p.metric==='weekend'));
    x.staff[1].isNightOnly=false; x.surplusHistory.periods[1].input.staff[1].personId='different-person';
    const p=a.Future.evaluate(m,a.Future.prepare(x,m)).pairs.find(p=>p.metric==='weekend'&&p.offset===1);
    assert.equal(p.observedDays,2); assert.equal(p.pastA,0); assert.equal(p.pastB,0);
  });
  await test('새로운 7일 7근무와 N 4회 집중을 거절', () => {
    const x=input({days:7,n:2,seniors:0,quota:{D:0,E:0,N:0}}), m=[['D','D','OFF','D','D','OFF','D'],Array(7).fill('OFF')];
    const bad=json(m); bad[0]=Array(7).fill('D'); assert.equal(a.Recovery.safe(x,m,bad,a.Recovery.current(x,m)),null);
    bad[0]=['N','N','OFF','OFF','N','N','OFF']; assert.equal(a.Recovery.safe(x,m,bad,a.Recovery.current(x,m)),null);
  });
  await test('달 경계를 넘는 기본 OFF 보호 가산은 날짜를 추정하지 않고 비교 제외', () => {
    const x=input({start:'2026-10-26',days:28,n:2,seniors:0,quota:{D:0,E:0,N:0}});
    x.rules.sleep=true;x.rules.sleepThreshold=2;x.rules.sleepReward=1;
    const m=x.staff.map(()=>Array(28).fill('OFF')); m[0][0]='N';m[0][1]='N';m[1][0]='N';m[1][1]='N';
    const p=a.Future.prepare(x,m);
    assert(p.excluded.some(v=>v.metric==='OFF'&&v.offset===2));
    assert(!p.pairs.some(v=>v.metric==='OFF'&&v.offset===2));
  });
  await test('휴식 반복의 기존 비중첩 집계와 월별 개인 횟수 보호', () => {
    const x=input({days:14,n:2,seniors:0,quota:{D:0,E:0,N:0}});
    const m=['D D D D D OFF D D D D OFF D D D'.split(' '),Array(14).fill('OFF')];
    const q=a.B.report(x,m); assert.equal(q.rows[0].episodes.length,2);
    assert.deepEqual(json(a.Rebuild.rank(q)).slice(0,2),[2,0]);
    const next=json(m);next[0][0]='OFF';next[1][0]='D';
    assert.equal(a.Recovery.safe(x,m,next,a.Recovery.current(x,m),{exactCounts:true}),null);
  });
  await test('N·OFF 잔존 집계는 실제 이력의 날짜와 비교군을 유지하고 D/E는 추가 집계하지 않음', () => {
    const x=input({start:'2026-11-01',days:28,n:2,seniors:0,quota:{D:0,E:0,N:0}});
    let history={version:1,periods:[]};
    for(const [start,days,who] of [['2026-09-01',30,0],['2026-10-01',31,1]]) {
      const p=input({start,days,n:2,seniors:0,quota:{D:0,E:0,N:0}}), m=p.staff.map(()=>Array(days).fill('OFF'));
      for(let d=0;d<5;d++)m[who][d]='N';
      history=json(a.F.confirmPeriod(history,p,m,'fixture'));
    }
    history.periods.forEach(p=>p.basis='actual');x.workloadHistory=history;
    const m=x.staff.map(()=>Array(28).fill('OFF'));m.forEach(r=>{r[0]='N';r[1]='N';});
    const p=a.Future.evaluate(m,a.Future.prepare(x,m));
    const dec=p.pairs.find(p=>p.metric==='N'&&p.offset===1),jan=p.pairs.find(p=>p.metric==='N'&&p.offset===2);
    assert(dec);assert.equal(dec.own,2);assert.equal(dec.other,7);assert.equal(jan.own,2);assert.equal(jan.other,2);
    assert(!p.pairs.some(p=>['D','E'].includes(p.metric)));
  });
  await test('자동연차는 동의한 공통 날짜의 실제 사용만 집계하고 만료·비동의를 반영', () => {
    const {x,m}=weekendCase();x.rules.surplus.annual=1;
    x.staff.forEach(s=>s.annualConsent={period:a.Annual.period(x),status:'YES'});
    for(const p of x.surplusHistory.periods) {
      p.input.rules.surplus.annual=1;p.input.staff.forEach(s=>s.annualConsent={period:a.Annual.period(p.input),status:'YES'});
      const who=p.start.startsWith('2026-09')?1:0,date=p.input.dates[5].iso;
      p.actual[who][5]='LEAVE';p.actualGrants=[{key:a.S.identity(p.input.staff[who]),date}];
    }
    const p=a.Future.evaluate(m,a.Future.prepare(x,m)),dec=p.pairs.find(p=>p.metric==='annual'&&p.offset===1);
    assert.equal(dec.own,1);assert.equal(dec.other,0);
    assert.equal(p.pairs.find(p=>p.metric==='annual'&&p.offset===2).gap,0);
    x.staff[1].annualConsent.status='NO';assert(!a.Future.prepare(x,m).pairs.some(p=>p.metric==='annual'));
  });
  await test('희망반영은 만료 기록을 빼되 신청 건수·유형·관리자 반려를 보존', () => {
    const {x,m}=weekendCase();x.staff[0].reqShiftsMap[x.dates[0].date]='OFF';
    let h={version:1,periods:[]};
    for(const [start,days,shift] of [['2026-09-01',30,'D'],['2026-10-01',31,'OFF']]) {
      const p=input({start,days,n:2,seniors:0,quota:{D:0,E:0,N:0}}),pm=p.staff.map(()=>Array(days).fill(shift));
      p.staff[0].reqShiftsMap[15]='OFF';h=json(a.P.confirmPeriod(h,p,pm));
    }
    h.periods.forEach(p=>p.basis='actual');x.preferenceHistory=h;
    let p=a.Future.evaluate(m,a.Future.prepare(x,m)).preferences.find(p=>p.type==='OFF'&&p.offset===1).rows[0];
    assert.equal(p.submitted,2);assert.equal(p.unmet,1);assert.equal(p.rate,0.5);
    x.staff[0].requestDecisions[x.dates[0].date]={date:x.dates[0].iso,code:'OFF',status:'rejected'};m[0][0]='OFF';
    p=a.Future.evaluate(m,a.Future.prepare(x,m)).preferences.find(p=>p.type==='OFF'&&p.offset===1).rows[0];
    assert.equal(p.unmet,1,'rejection is not silently converted into applied');
  });
  await test('복구 정책 저장·불러오기, 잘못된 버전의 비파괴적 거절', async () => {
    const x=input({days:7,n:1,seniors:0,quota:{D:0,E:0,N:0}}),m=[Array(7).fill('OFF')],ui=require('./ui-harness.cjs')();
    ui.ctx.inputFixture=json(x);ui.ctx.resultFixture=json(result(a,x,m));
    ui.run('lastInput=inputFixture;lastResult=resultFixture;globalStaffData=lastInput.staff;dirty=false;generating=false;renderAll()');
    let download;ui.ctx.URL={createObjectURL:b=>{download=b;return 'blob:recovery'},revokeObjectURL(){}};
    ui.run('saveFile()');const text=await download.text(),data=JSON.parse(text);
    ui.ctx.file={size:text.length,text:async()=>text};await ui.run('loadFile(file)');
    assert.equal(ui.run('lastInput.futureBalancePolicy'),1);assert.equal(ui.run('lastInput.restRebuildPolicy'),1);
    data.input.futureBalancePolicy=999;const bad=JSON.stringify(data);ui.ctx.bad={size:bad.length,text:async()=>bad};await ui.run('loadFile(bad)');
    assert.equal(ui.run('lastInput.futureBalancePolicy'),1);assert(ui.notices.some(s=>s.includes('복구판 균형 기준')));
  });
  await test('자동연차의 현재 동률 후보에서만 만료 후 부족 직원을 선택', async () => {
    const {x}=weekendCase(),m=x.staff.map(()=>['D','D','OFF','D','D','OFF','OFF']);
    x.rules.surplus.annual=1;x.staff.forEach(s=>s.annualConsent={period:a.Annual.period(x),status:'YES'});
    x.surplusPlan={kind:'annual',version:1,grants:[],floors:[],initialised:true};
    for(const p of x.surplusHistory.periods) {
      p.input.rules.surplus.annual=1;p.input.staff.forEach(s=>s.annualConsent={period:a.Annual.period(p.input),status:'YES'});
      const who=p.start.startsWith('2026-09')?1:0,date=p.input.dates[0].iso;
      p.actual[who][0]='LEAVE';p.actualGrants=[{key:a.S.identity(p.input.staff[who]),date}];
    }
    const people=x.staff.map((s,i)=>({s,i,n:0,history:0})),chosen=json(m);chosen[0][0]='LEAVE';
    const before=JSON.stringify(x);
    const best=await a.Future.chooseAnnual(x,m,{chosen,owner:people[0],date:0},people,{stop:()=>false,trial:changes=>{
      const next=json(m);for(const [i,d,sh] of changes)next[i][d]=sh;return next;
    }});
    assert.equal(best.owner.i,1);assert.equal(JSON.stringify(x),before);assert.equal(x.surplusPlan.grants.length,0);
    people[1].n=1;
    const protectedChoice=await a.Future.chooseAnnual(x,m,{chosen,owner:people[0],date:0},people,{stop:()=>false,trial:changes=>{
      const next=json(m);for(const [i,d,sh] of changes)next[i][d]=sh;return next;
    }});
    assert.equal(protectedChoice.owner.i,0,'second-round candidate cannot bypass first round');
  });
  console.log(JSON.stringify({passed}));
})().catch(e=>{console.error(e.stack);process.exit(1)});
