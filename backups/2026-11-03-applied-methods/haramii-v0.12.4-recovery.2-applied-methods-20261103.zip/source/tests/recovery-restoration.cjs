const assert=require('node:assert/strict');
const {domains,fixture,result,json}=require('./helpers.cjs'),a=domains();let passed=0;
const input=o=>({...fixture(o),weekendPolicy:2,restSpreadPolicy:2,continuityPolicy:1,futureBalancePolicy:1,restRebuildPolicy:1});
async function test(name,fn){await fn();passed++;console.log('PASS',name);}
function example(){
 const x=input({start:'2026-11-02',days:14,n:2,seniors:0,quota:{D:1,E:0,N:0},realistic:true});
 x.rules.weekend={D:0,E:0,N:0};
 const m=['D D D D D OFF D OFF OFF OFF D OFF OFF D'.split(' '),
  'OFF D D OFF D OFF D D D D OFF D D OFF'.split(' ')];
 const next=json(m);[next[0][2],next[0][9]]=[next[0][9],next[0][2]];
 return {x,m,next};
}
(async()=>{
 await test('공동 최댓값이 남아 있어도 큰 부담의 일부 개선을 채택하는 순위',()=>{
  const q=counts=>({rows:counts.map(n=>({episodes:Array(n).fill({}),restWindows:Array(n*2).fill({})}))});
  assert(a.Recovery.cmp(a.Rebuild.rank(q([3,2,0])),a.Rebuild.rank(q([3,3,0])))<0);
  assert(a.Recovery.cmp(a.Rebuild.rank(q([2,2,2])),a.Rebuild.rank(q([3,1,1])))<0);
  assert(a.Recovery.cmp(a.Rebuild.rank(q([0,0,0])),a.Rebuild.rank(q([1,0,0])))<0);
 });
 await test('직전 근무를 이용해 시작 구간의 휴식 우선도를 높이며 모르는 이력은 추정하지 않음',()=>{
  const x=input({days:14,n:1,seniors:0}),s=x.staff[0],row=Array(14).fill(null);
  s.previousShifts=['D','D','OFF','D','D','D'];
  assert(a.Rebuild.boundaryPlan(x,s).some(w=>w.end===0&&w.minRest===1));
  assert(a.Rebuild.boundaryCost(x,s,row,0,'D')>0);assert.equal(a.Rebuild.boundaryCost(x,s,row,0,'OFF'),0);
  assert.equal(a.Rebuild.boundaryCost(x,s,row,0,'N'),0,'N placement policy remains unchanged');
  const old=json(x);delete old.restRebuildPolicy;
  assert(a.B.assignmentCost(x,s,row,0,'D')>a.B.assignmentCost(old,old.staff[0],row,0,'D'));
  s.previousShifts=[];assert.equal(a.Rebuild.boundaryPlan(x,s).length,0);assert.equal(a.Rebuild.boundaryCost(x,s,row,0,'D'),0);
  s.previousShifts=['D','D',null,'D','D','D'];assert(!a.Rebuild.boundaryPlan(x,s).some(w=>w.end===0));
 });
 await test('D/E/OFF 재배치는 개인 월별 횟수와 최소인원을 보존하며 불필요한 날짜별 총량 고정에서 벗어남',()=>{
  const {x,m,next}=example(),q=a.Recovery.current(x,m);
  assert.equal(q.issues.filter(e=>e.level==='error').length,0);
  assert(a.B.report(x,next).independentWindows<a.B.report(x,m).independentWindows);
  assert.equal(a.Recovery.safe(x,m,next,q,{exactCounts:true}),null,'old exact daily totals block the move');
  assert(a.Recovery.safe(x,m,next,q,{exactCounts:true,preserveDailyTotals:false}));
  x.staff.forEach((s,i)=>['D','E','N','OFF'].forEach(sh=>assert.equal(m[i].filter(v=>v===sh).length,next[i].filter(v=>v===sh).length)));
 });
 await test('보강 하한만 막는 후보를 진단하되 보강을 임의로 낮춰 채택하지 않음',()=>{
  const {x,m,next}=example();x.surplusPlan={version:1,floors:[{d:2,shift:'D',floor:2,goal:2}],grants:[]};
  const q=a.Recovery.current(x,m),frozen=JSON.stringify(x);
  assert.equal(a.Recovery.safe(x,m,next,q,{exactCounts:true,preserveDailyTotals:false}),null);
  const d=a.Rebuild.diagnoseBoost(x,m,next,q);assert(d);assert.equal(d.episodeReduction,1);
  assert.equal(d.blocked[0].minimum,1);assert.equal(d.blocked[0].floor,2);assert.equal(d.blocked[0].shortage,1);
  assert.equal(JSON.stringify(x),frozen);assert.equal(a.Rebuild.diagnoseBoost(x,m,m,q),null);
  const bad=json(next);bad[1][2]='OFF';assert.equal(a.Rebuild.diagnoseBoost(x,m,bad,q),null,'hard minimum never relaxed');
 });
 await test('3명과 2개 날짜의 D/E/OFF 순환으로 개인별 및 날짜별 횟수를 보존',()=>{
  const x=input({days:7,n:3,seniors:0,quota:{D:0,E:0,N:0}});
  const m=[['D','OFF','D','D','D','D','D'],['OFF','E','OFF','OFF','OFF','OFF','OFF'],['E','D','OFF','OFF','OFF','OFF','OFF']];
  const rows=a.B.report(x,m).rows;
  const c=[...a.Rebuild.restCandidates(x,m,rows)].find(c=>c.stage==='three-person-DE-OFF');assert(c);
  for(let i=0;i<3;i++)for(const sh of ['D','E','OFF'])assert.equal(c.matrix[i].filter(v=>v===sh).length,m[i].filter(v=>v===sh).length);
  for(let d=0;d<7;d++)for(const sh of ['D','E','OFF'])assert.equal(c.matrix.filter(r=>r[d]===sh).length,m.filter(r=>r[d]===sh).length);
 });
 await test('직원당 1회만 남은 경우도 0회를 향해 탐색하고 고정 조건·현재 균형을 유지',async()=>{
  const {x,m}=example(),before=a.Recovery.current(x,m),frozen=JSON.stringify(x);
  assert.equal(Math.max(...before.spread.rows.map(r=>r.episodes.length)),1);
  const r=await a.Rebuild.improve(x,result(a,x,m),{maxMs:2500,maxChecks:300});
  assert(r.restRebuild.moves>0);assert(a.Recovery.cmp(r.restRebuild.after,r.restRebuild.before)<0);
  assert.equal(a.E.validate(x,r.matrix).filter(e=>e.level==='error').length,0);
  assert(a.Recovery.noWorse(before.metrics,a.Recovery.current(x,r.matrix).metrics));
  assert.equal(JSON.stringify(x),frozen);assert(r.restRebuild.stages.some(s=>s.includes('DE-OFF')));
 });
 console.log(JSON.stringify({passed}));
})().catch(e=>{console.error(e.stack);process.exit(1)});
