const assert=require('node:assert/strict');
const {domains,fixture,result,json}=require('./helpers.cjs');
const {E,R,S,Q,F,P}=domains();
const fresh=(cap=1,options={})=>{const x={...fixture({days:7,seniors:0,...options}),restPolicy:1};x.rules.leaveOffLimit=cap;x.rules.includeLeave=true;x.staff.forEach(s=>s.previousShifts=['D']);return x;};
const codes=(x,row)=>E.patternIssuesForSurplus(x,x.staff[0],row).map(p=>p.code);
const linked=(x,row)=>E.patternIssuesForSurplus(x,x.staff[0],row).filter(p=>p.code==='LEAVE_OFF_LIMIT');
let passed=0;
function test(name,fn){fn();passed++;console.log('PASS '+name);}
test('일반 OFF만 연속 상한: 긴 연차·보건·병가 제외, 기존 저장표 기준 유지',()=>{
 const x=fresh();x.rules.maxOff=3;
 for(const sh of ['LEAVE','M-LEAVE','SICK','MATERNITY','PARENTAL'])assert(!codes(x,Array(7).fill(sh)).includes('OFF_STREAK'));
 assert(codes(x,['D','OFF','OFF','OFF','OFF','D','D']).includes('OFF_STREAK'));
 delete x.restPolicy;assert(codes(x,Array(7).fill('LEAVE')).includes('OFF_STREAK'));assert.equal(linked(x,['D','OFF','LEAVE','LEAVE','OFF','OFF','D']).length,0);
});
test('ON 0일 / OFF 앞뒤 합계 1일, 여러 연차 사이의 OFF도 같은 구간',()=>{
 const x=fresh();assert.equal(linked(x,['D','LEAVE','LEAVE','LEAVE','OFF','D','D']).length,0);
 assert.equal(linked(x,['D','OFF','LEAVE','LEAVE','OFF','D','D']).length,2);
 assert.equal(linked(x,['D','LEAVE','LEAVE','LEAVE','OFF','OFF','OFF']).length,3);
 assert.equal(linked(x,['D','LEAVE','OFF','LEAVE','OFF','D','D']).length,2);
 x.rules.leaveOffLimit=0;assert.equal(linked(x,['D','LEAVE','LEAVE','LEAVE','OFF','D','D']).length,1);
 assert.equal(linked(x,['D','OFF','LEAVE','LEAVE','D','D','D']).length,1);
 assert.equal(linked(x,['D','OFF','OFF','SICK','LEAVE','LEAVE','D']).length,0);
 assert.equal(linked(x,['D','OFF','OFF',null,'LEAVE','LEAVE','D']).length,0);
 x.rules.maxOff=null;assert.equal(linked(x,['D','LEAVE','OFF','D','D','D','D']).length,1,'independent of ordinary OFF cap');
});
test('전후 기간의 알려진 근무 연결, 이미 끝난 OFF만으로 승인 연차 차단하지 않음',()=>{
 const x=fresh();x.staff[0].previousShifts=['D','LEAVE','OFF'];
 assert.equal(linked(x,['OFF','LEAVE','D','D','D','D','D']).length,1);
 x.staff[0].previousShifts=['D','OFF','OFF','OFF'];assert.equal(linked(x,['LEAVE','LEAVE','D','D','D','D','D']).length,0);
 x.staff[0].previousShifts=['D'];x.staff[0].nextShifts=['LEAVE','LEAVE','OFF'];
 assert.equal(linked(x,['D','D','D','D','D','D','OFF']).length,1);
 delete x.staff[0].nextShifts;assert.equal(linked(x,['D','D','D','D','D','D','OFF']).length,0);
});
test('4주 편성의 월 경계도 한 연차 구간으로 합산',()=>{
 const x=fresh(1,{start:'2026-10-16',days:28});x.dates.forEach((t,d)=>t.date=d+1);x.staff[0].leaveDates=[15,16,17];
 const row=Array(28).fill('D');for(let d=14;d<=16;d++){row[d]='LEAVE';assert.deepEqual(json(E.fixed(x,x.staff[0],d)),['LEAVE']);}row[13]=row[17]='OFF';
 assert.equal(x.dates[16].iso,'2026-11-01');assert.equal(linked(x,row).length,2);
});
test('후보 배정·고정 휴무 충돌·한 직원 문제 묶음·야간 회복 조건 보존',()=>{
 const x=fresh(1),s=x.staff[0];s.leaveDates=[3,4,5];
 const m=x.staff.map(()=>Array(7).fill('D'));m[0]=['D','OFF','LEAVE','LEAVE','LEAVE',null,'D'];assert(!E.canAssign(x,m,0,5,'OFF'));
 m[0][1]='D';assert(E.canAssign(x,m,0,5,'OFF'));x.rules.leaveOffLimit=0;assert(!E.canAssign(x,m,0,5,'OFF'));
 s.offDayIndicesArray=[x.dates[5].dayIndex];const check=E.preflightDetails(x);assert(check.issues.some(p=>p.code==='LEAVE_OFF_LIMIT'&&p.target==='ruleLeaveOffBlock'));
 m[0]=['D','OFF','LEAVE','LEAVE','LEAVE','OFF','OFF'];const errors=E.validate(x,m),explain=E.explainIssues(x,m,errors),g=Q.groups(x,explain).filter(p=>p.code==='LEAVE_OFF_LIMIT');assert.equal(g.length,1);assert.equal(g[0].items.length,3);
 assert(linked(x,['N','N','OFF','LEAVE','D','D','D']).length);assert(codes(x,['N','N','D','LEAVE','D','D','D']).includes('N_RECOVERY'));
});
(async()=>{
 for(const cap of [0,1])for(const mode of ['DISABLED','OFF','DE','DEN']){
   const x=fresh(cap,{n:6,quota:{D:2,E:0,N:0},mode:mode==='DISABLED'?'OFF':mode,enabled:mode!=='DISABLED'});x.rules.includeLeave=false;x.staff[0].leaveDates=[3,4,5];
   const matrix=x.staff.map(()=>Array(7).fill('D'));matrix[0]=['D','D','LEAVE','LEAVE','LEAVE','D','D'];
   const r=await S.apply(x,result({E,F,P},x,matrix));
   assert(!r.issues.some(p=>p.code==='LEAVE_OFF_LIMIT'));assert.deepEqual(json(r.matrix[0].slice(2,5)),['LEAVE','LEAVE','LEAVE']);
 }
 console.log('PASS 0/1일 × 추가 OFF 토글·3개 배분 방식: 뒤 단계에서도 연차 연결 한도 유지');
 const x=fresh(0,{n:2,days:7,quota:{D:0,E:0,N:0}});x.staff[0].leaveDates=[3,4,5];const m=x.staff.map(()=>Array(7).fill('D'));m[0]=['D','D','LEAVE','LEAVE','LEAVE','D','D'];
 const planned=await S.apply(x,result({E,F,P},x,m));let history=S.savePlan(null,x,planned);const actual=planned.matrix.map(r=>r.slice());actual[0][5]='OFF';history=S.confirmActual(history,history.periods[0].key,actual,{today:'2026-10-19'});assert.equal(history.periods[0].actual[0][5],'OFF');S.validateHistory(json(history));
 console.log('PASS 실제 근무는 위반을 숨기지 않고 기록·복원 가능');console.log(JSON.stringify({passed:passed+2}));
})().catch(e=>{console.error(e);process.exit(1)});
