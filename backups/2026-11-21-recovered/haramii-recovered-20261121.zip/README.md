# 병동 근무표 — v0.12.4-recovery.2

2026-11-10 필수조건 보완: 연속근무 상한 선택과 무관하게 7일 연속 근무를 금지한다.
알려진 직전·다음 근무를 포함해 검사하며, 후보 배정·수동 수정·계획 확정에 적용한다.
실제 근무 기록은 사실대로 보존하면서 위반을 표시한다. 7일 중 6일 근무는 개선 목표로 유지한다.
조건 목록과 변경 범위는 [조건 점검 기록](validation/constraints-20261110.md)에 정리했다.

유실된 원본 v0.12.4가 아니라, 검증된 v0.12.2와 보존된 대화의 결정사항을 바탕으로 재구현한 복구판이다. 정확한 범위와 불확실성은 [대화 복구 기록](CONVERSATION-RECOVERY.md)을 참고한다.

`index.html`은 브라우저에서 실행하는 단일 파일이다. 빌드 원본은 `source/src/`에 있고, 직접 생성 HTML을 수정하지 않는다.

```bash
bash build.sh
cd source
node tests/recovery-balance.cjs
node tests/recovery-restoration.cjs
node tests/rest-policy.cjs
node tests/night-transition.cjs
node tests/continuity.cjs
```

빌드/핵심 검사에는 Python 표준 라이브러리와 Node.js만 필요하다. 이 환경에서 Python 3.12.14, Node v24.19.0으로 확인했다. HTML 실행에는 설치 스크립트나 서버가 필요하지 않다. Excel 보고서 생성에만 `openpyxl`이 필요하다.

## 연속 시험

```bash
cd source
node tests/recovery-chain.cjs ../fixtures/templates ../validation/new-chain 4week
node tests/recovery-chain-audit.cjs ../validation/new-chain
```

새 시험은 새 출력 폴더로 실행한다. 같은 폴더를 사용하면 체크포인트 다음 기간부터 재개한다. 48개 초안 탐색, 같은 기간 최대 3개 seed 시도, 고정 요일 순환, 입력의 교육/휴직/동의 조건을 유지한다. 채택한 표를 변경하지 않고 시험용 실제 이력으로 연결한다.

`validation/recovery-chain/`은 이전 recovery.1의 연속 생성 자료이고, `validation/recovery-v2/`는 이번 recovery.2의 기능·재조정·단기 생성 검사다. 다른 실험은 다른 출력 폴더에 저장하고 이력을 섞지 않는다. 아직 확정되지 않았던 ‘4주당 1회 부담 분산’이나 유실된 CP-SAT 최적화 실험을 이 프로그램의 기본 정책에 통합했다고 해석하면 안 된다.

## 백업

프로그램, 소스, 입력, 실패/채택 결과, 실행 환경과 해시를 함께 보관한다. 클라우드 안에만 남긴 파일은 환경 유실에 대비한 외부 백업이 아니다. `output/`의 백업 ZIP을 별도로 내려받거나 원격 저장소에 보관해야 한다.
