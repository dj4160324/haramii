const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const {a,prepare,score,cmp,json}=require('../combinations-20261104/common.cjs');
const {bandScore,run}=require('./run.cjs');
const core=require('../../source/src/whole-optimizer-core.js')(a);
function q(counts,weekend,night=0){return {spread:{score:[night],rows:counts.map(n=>({episodes:Array(n),restWindows:Array(n)}))},weekend:{currentGap:2,rollingGap:2,pairs:[{gap:weekend}]}};}
assert(cmp(bandScore(q([1,1],1)),bandScore(q([2,0],0)))<0,'split repetition before weekends');
assert(cmp(bandScore(q([1,1],0)),bandScore(q([1,0],1)))<0,'within 0-1 band, weekend fairness precedes total');
assert(cmp(score(q([1,1],0),{C:true}),score(q([1,0],1),{C:true}))>0,'old mixed policy differs');
assert(cmp(bandScore(q([1,0],0)),bandScore(q([1,1],0)))<0,'do not create first episodes without a better higher objective');
assert(cmp(bandScore(q([0,0],0,1)),bandScore(q([2,1],2,0)))>0,'N concentration first');
console.log('PASS five ordering checks');
(async()=>{
 const dir=path.resolve(__dirname,'../../validation/band-priority-20261110/calibration');
 for(const n of [5,2,6]){
  const v=require(`../../validation/recovery-v2/cases/case-${n}.json`),x=json(v.input);delete x.surplusPlan.decision;delete x.surplusPlan.accepted;
  assert.deepEqual(json(core.prepare(x,v.result.matrix)),json(prepare(x,v.result.matrix)),'portable core unchanged');
  assert(core.audit(x,v.result.matrix,v.result.matrix,{P:false,C:false}).ok);
  const r=await run(x,v.result.matrix,'band',{out:dir,name:'fixed-'+n,seconds:5,seed:20261110,fixed:true});
  assert.equal(r.status,'OPTIMAL');assert.deepEqual(r.before,r.after);assert(r.after.repeated>0,'unresolved 2+ must not block output');
  console.log('PASS fixed model, same core, independent counts, nonblocking fallback: case '+n);
 }
})().catch(e=>{console.error(e.stack);process.exit(1)});
