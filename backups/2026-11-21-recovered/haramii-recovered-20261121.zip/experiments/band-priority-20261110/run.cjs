// Compare only policy objectives. Keep domains, input, guards and budgets equal.
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),{spawnSync}=require('child_process'),crypto=require('crypto');
const old=require('../combinations-20261104/common.cjs');
const {a,json,brief,prepare,audit,score,cmp,sum}=old;
const root=path.resolve(__dirname,'../..');
const python=process.env.EXPERIMENT_PYTHON||'/workspace/haramii-experiment-venv/bin/python';
function bandScore(q){const c=q.spread.rows.map(r=>r.episodes.length),excess=c.map(n=>Math.max(0,n-1));
 return [q.spread.score[0],Math.max(...excess),sum(excess),c.filter(n=>n>=2).length,
 q.weekend.currentGap,q.weekend.rollingGap||0,sum(q.weekend.pairs.map(p=>p.gap*p.gap)),sum(c),sum(q.spread.rows.map(r=>r.restWindows.length))];}
const policies={B:{P:false,C:false},priority:{P:true,C:false},mixed:{P:true,C:true},band:{P:true,C:true}};
function target(q,p){return p==='band'?bandScore(q):score(q,policies[p]);}
const write=(p,v)=>{fs.writeFileSync(p+'.tmp',JSON.stringify(v,null,2));fs.renameSync(p+'.tmp',p);};
async function run(x,m,policy,{out,name,seconds=20,seed=20261110,fixed=false}={}){
 const flags=policies[policy],spec=prepare(x,m),base=a.Recovery.current(x,m),frozen=JSON.stringify(x);
 fs.mkdirSync(out,{recursive:true});const input=path.join(out,name+'-model.json'),output=path.join(out,name+'-solver.json');write(input,spec);
 const args=[path.join(__dirname,'solve.py'),input,output,Number(flags.P)+'',Number(flags.C)+'',seconds+'',seed+''];
 if(policy==='band')args.push('--band-priority');if(fixed)args.push('--fix-baseline');
 const started=Date.now(),r=spawnSync(python,args,{encoding:'utf8',timeout:(seconds+90)*1000,maxBuffer:1024*1024});assert.equal(r.status,0,r.stderr||r.error?.message);
 const solved=JSON.parse(fs.readFileSync(output));let best=m,bestScore=target(base,policy),accepted=0;const rejected={};
 for(const sol of solved.solutions){
  const check=audit(x,m,sol.matrix,flags,base);
  assert.equal(sol.episodes,check.brief.episodes);assert.equal(sol.repeated,check.brief.repeated);
  if(!check.ok){for(const k of check.errors)rejected[k]=(rejected[k]||0)+1;continue;}
  accepted++;const rank=target(check.q,policy);if(cmp(rank,bestScore)<0){best=sol.matrix;bestScore=rank;}
 }
 assert.equal(JSON.stringify(x),frozen);const final=audit(x,m,best,flags,base);assert(final.ok);
 const report={name,policy,budgetSeconds:seconds,seed,ms:Date.now()-started,before:brief(x,m,base),after:final.brief,
  beforeBandScore:bandScore(base),afterBandScore:bandScore(final.q),status:solved.status,candidates:solved.solutions.length,accepted,rejected,
  inputSHA256:crypto.createHash('sha256').update(frozen).digest('hex')};
 write(path.join(out,name+'.json'),{input:x,matrix:best,report});return report;
}
module.exports={bandScore,run,policies};
if(require.main===module)(async()=>{
 const [out,cases='5,2,6',list='B,priority,mixed,band',seconds='20',seed='20261110']=process.argv.slice(2);fs.mkdirSync(out,{recursive:true});const summary=[];
 for(const n of cases.split(',').map(Number)){
  const v=JSON.parse(fs.readFileSync(path.join(root,`validation/recovery-v2/cases/case-${n}.json`))),x=json(v.input);delete x.surplusPlan.decision;delete x.surplusPlan.accepted;
  for(const policy of list.split(',')){
   const name=`case-${n}-${policy}-seed-${seed}`,file=path.join(out,name+'.json');
   if(fs.existsSync(file)){summary.push(JSON.parse(fs.readFileSync(file)).report);continue;}
   console.log(JSON.stringify({stage:'start',name}));
   const report=await run(x,v.result.matrix,policy,{out,name,seconds:+seconds,seed:+seed});summary.push(report);write(path.join(out,'summary.json'),summary);
   console.log(JSON.stringify(report));
  }
 }write(path.join(out,'summary.json'),summary);
})().catch(e=>{console.error(e.stack);process.exit(1)});
