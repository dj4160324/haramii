"""Audit and package completed experiments; never changes the application build."""
from pathlib import Path
import json,hashlib,csv,zipfile,subprocess
root=Path(__file__).resolve().parents[2]
exp=root/'experiments/combinations-20261104';results=root/'validation/combination-screen-20261104';chain=results/'long-110'
r=json.loads((chain/'4week-report.json').read_text());assert len(r['reports'])==7 and r['status']=='complete'
for script,args in [('chain-audit.cjs',[str(chain)]),('long-verification.cjs',[str(chain)])]:
 subprocess.run(['node',str(exp/script),*args],cwd=root,check=True)
subprocess.run(['python3',str(exp/'report.py')],cwd=root,check=True,stdout=subprocess.DEVNULL)
audit=json.loads((chain/'quality-audit.json').read_text());protection=json.loads((chain/'experimental-protection-audit.json').read_text())
assert len(audit['periods'])==len(protection['periods'])==7
assert audit['totals']['checkedBoundaries']==6
assert all(p['hardErrors']==p['fairnessBreaches']==p['nightConcentration']==0 for p in audit['periods'])
assert audit['totals']['maxWorkInSeven']<7
assert all(p['weekend']<=2 for p in audit['periods'])
digest=hashlib.sha256((root/'index.html').read_bytes()).hexdigest()
assert digest=='f82cc6a01ac9102f6097237ac1841e5f2a5f6d6aef23671dd22238a464e9145b'
for name in ['screen-v2','confirmation']:
 verified=json.loads((results/name/'independent-verification.json').read_text());assert verified['fullAuditPassed']
with (results/'long-staff.csv').open('w',newline='',encoding='utf-8-sig') as f:
 writer=csv.writer(f);writer.writerow(['직원','1회차','2회차','3회차','4회차','5회차','6회차','7회차','회차별 합계','전체 비중첩 합계','반복 회차 수','연속 28일 최대'])
 for s in audit['staff']:writer.writerow([s['name'],*s['periods'],s['sumPeriodCounts'],s['total'],s['repeatedPeriods'],s['rolling28Max']])
before={k:sum(p['initial'][k] for p in r['reports']) for k in ['episodes','repeated']}
after={k:sum(p['final'][k] for p in r['reports']) for k in ['episodes','repeated']}
summary={'selected':'110','shortComparisons':30,'longPeriods':7,'days':196,'beforeOptimizer':before,'afterOptimizer':after,
         'longAudit':audit['totals'],'maxCurrentWeekendGap':max(p['weekend'] for p in audit['periods']),
         'maxRollingWeekendGap':max(p['rollingWeekend'] or 0 for p in audit['periods']),
         'lastPeriodPendingRecoveryWarnings':len(audit['periods'][-1]['boundary']['pending']),
         'frozenRowEpisodes':protection['totals']['fixedRowEpisodes'],'frozenRowRepeatedStaffPeriods':protection['totals']['fixedRowRepeated'],
         'applicationUnchanged':True,'htmlSHA256':digest,
         'caveats':['No simultaneous long-term control. Before/after is the optimizer stage within the same new chain.',
                    'P preserves maximum weekend gaps but allows squared disparity to worsen.',
                    'Model conservatively freezes isNewbie/precId rows even after training ends.',
                    'Python CP-SAT experiment; not integrated into the standalone HTML.']}
(results/'final-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
report=results/'REPORT.md'
report.write_text(report.read_text()+'\n## 완료 요약\n\n```json\n'+json.dumps(summary,ensure_ascii=False,indent=2)+'\n```\n')
out=root/'output';out.mkdir(exist_ok=True)
files={}
for base in [exp,results,root/'fixtures/templates']:
 for p in base.rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.tmp':continue
  if base==results and any(part in {'pilot','screen','model-checks'} for part in p.relative_to(base).parts):continue
  files[str(p.relative_to(root))]=p.read_bytes()
for name in ['index.html','source/dist/index.html','source/tests/helpers.cjs',*[f'validation/recovery-v2/cases/case-{n}.json' for n in [2,3,5,6]]]:
 files[name]=(root/name).read_bytes()
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in files.items()}
archive=out/'haramii-combination-tests-20261104.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in files.items():z.writestr(name,data)
 z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,entry in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==entry['sha256']
(out/'COMBINATION-TEST-REPORT-20261104.md').write_text(report.read_text())
(out/'COMBINATION-TEST-SHA256-20261104.txt').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(json.dumps({'summary':summary,'archiveBytes':archive.stat().st_size,'files':len(manifest)},ensure_ascii=False))
