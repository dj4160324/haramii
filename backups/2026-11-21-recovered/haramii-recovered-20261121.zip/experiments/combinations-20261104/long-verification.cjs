const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {a,audit,WORK}=require('./common.cjs');
const dir=process.argv[2],periods=[],staff=new Map();let solutions=0;
for(let n=1;n<=7;n++){
 const file=path.join(dir,`4week-period-${n}-final.json`);if(!fs.existsSync(file))break;
 const v=JSON.parse(fs.readFileSync(file)),attempt=v.report.attempt,prefix=`period-${n}-attempt-${attempt}`;
 const before=JSON.parse(fs.readFileSync(path.join(dir,`4week-${prefix}-generated.json`)));
 const checked=audit(before.input,before.result.matrix,v.result.matrix,{P:true,C:false});assert(checked.ok,checked.errors.join(','));
 const model=JSON.parse(fs.readFileSync(path.join(dir,'optimization',prefix+'-model.json')));
 const solved=JSON.parse(fs.readFileSync(path.join(dir,'optimization',prefix+'-solver.json')));
 for(const sol of solved.solutions){const q=a.B.report(v.input,sol.matrix);assert.equal(sol.episodes,q.independentWindows);assert.equal(sol.repeated,q.repeatedStaff);solutions++;}
 const q=a.B.report(v.input,v.result.matrix);let fixedRowEpisodes=0,fixedRowRepeated=0;
 q.rows.forEach((r,i)=>{
  const s=v.input.staff[i],mutableCells=model.domains[i].filter(d=>d.length>1).length;
  if(!mutableCells){fixedRowEpisodes+=r.episodes.length;fixedRowRepeated+=Number(r.episodes.length>=2);}
  const key=a.S.identity(s);if(!staff.has(key))staff.set(key,{key,name:s.name,episodes:[],mutableCells:[],repeatedPeriods:0});
  const entry=staff.get(key);entry.episodes.push(r.episodes.length);entry.mutableCells.push(mutableCells);entry.repeatedPeriods+=Number(r.episodes.length>=2);
 });
 periods.push({period:n,episodes:q.independentWindows,repeated:q.repeatedStaff,fixedRowEpisodes,fixedRowRepeated,
  protectedOffPreserved:true,allGuardsPassed:true});
}
const result={periods,staff:[...staff.values()],solverCandidatesRecounted:solutions,
 totals:{episodes:periods.reduce((n,p)=>n+p.episodes,0),repeated:periods.reduce((n,p)=>n+p.repeated,0),
 fixedRowEpisodes:periods.reduce((n,p)=>n+p.fixedRowEpisodes,0),fixedRowRepeated:periods.reduce((n,p)=>n+p.fixedRowRepeated,0)},
 limitation:'Whole-row freezing uses isNewbie/precId markers even after training ends. Model-frozen burden is not proof of operational impossibility.'};
fs.writeFileSync(path.join(dir,'experimental-protection-audit.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({periods:periods.length,solverCandidatesRecounted:solutions,...result.totals}));
