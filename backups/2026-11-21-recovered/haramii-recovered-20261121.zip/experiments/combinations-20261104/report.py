from pathlib import Path
import json,hashlib,csv,sys
root=Path(__file__).resolve().parents[2]
folder=root/'validation/combination-screen-20261104'
screen=json.loads((folder/'screen-v2/summary.json').read_text())
groups={}
for r in screen:
 flags=r['flags'];code=''.join(str(int(flags[k])) for k in ['P','B','C'])
 groups.setdefault(code,[]).append(r)
names={'000':'공통 교환 탐색(대조군)','100':'① 우선순위','001':'③ 반복 분산','101':'①+③',
       '010':'② 전체 최적화','110':'①+②','011':'②+③','111':'①+②+③'}
baseline={r['name'].split('-')[1]:r for r in groups.get('000',[])}
rows=[];eligible=[]
for code in ['000','100','001','101','010','110','011','111']:
 rr=groups.get(code,[])
 if not rr:continue
 total=lambda key:sum(r['after'][key] for r in rr)
 improved=0;noharm=True
 for r in rr:
  b=baseline[r['name'].split('-')[1]]['after'];v=r['after']
  noharm &= v['episodes']<=b['episodes'] and v['repeated']<=b['repeated'] and v['hard']==v['fair']==v['night']==v['seven']==0
  improved += v['episodes']<b['episodes'] or v['repeated']<b['repeated']
 btotal={k:sum(baseline[r['name'].split('-')[1]]['after'][k] for r in rr) for k in ['episodes','repeated']}
 gain=max((btotal[k]-total(k))/max(1,btotal[k]) for k in btotal)
 qualified=len(rr)==3 and noharm and improved>=2 and gain>=.10
 if qualified:eligible.append(code)
 rows.append({'code':code,'name':names[code],'cases':len(rr),'episodes':total('episodes'),'repeated':total('repeated'),
              'windows':total('windows'),'maxWeekend':max(r['after']['weekend'] for r in rr),
              'maxRollingWeekend':max(r['after']['rollingWeekend'] or 0 for r in rr),'seconds':sum(r['ms'] for r in rr)/1000,
              'eligibleForConfirmation':qualified})
result={'screenComplete':len(screen)==24,'rows':rows,'eligibleForConfirmation':eligible}
(folder/'selection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with (folder/'screen-summary.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
lines=['# 세 가지 방법의 조합 비교 — 2026-11-04','','① 우선순위, ② 전체 CP-SAT 최적화, ③ 반복 부담 분산.',
       '정식 HTML 및 GitHub 백업에는 통합하지 않은 별도 실험이다.','',
       '## 1차 선별: 같은 기존 28일 표 3개를 각각 재조정','',
       '반복 직원 수는 세 사례의 직원·기간 합계다. 같은 사람의 장기 누적 횟수가 아니다.',
       '대조군도 원표에 같은 보호조건으로 교환 탐색을 추가한 결과다. 백업 프로그램의 새 생성 결과는 아니다.',
       '각 조합·사례당 탐색 20초. CP-SAT 4 worker, 교환 탐색 단일 스레드. 아래 시간은 모델 작성·감사를 포함한다.','',
       '| 조합 | 사례 수 | 6일 근무 독립 구간 합계 | 2회 이상 직원·기간 | 겹치는 창 | 현재/누적 주말 최대차 | 시간(초) |',
       '|---|---:|---:|---:|---:|---:|---:|']
for r in rows:lines.append(f"| {r['name']} | {r['cases']} | {r['episodes']} | {r['repeated']} | {r['windows']} | {r['maxWeekend']}/{r['maxRollingWeekend']} | {r['seconds']:.1f} |")
lines+=['','확인 시험 진입 후보: '+(', '.join(names[c] for c in eligible) or '현재 없음'),'',
        '## 해석 범위','',
        '- 필수조건·공평성·N 집중·7일 모두 근무 및 개인 월별 횟수·날짜별 가동/선임 인원·확정 입력을 독립 검증했다.',
        '- 세 선별 사례는 모두 기준 N 집중이 0이므로 N 개선 효과가 아니라 재발 방지를 확인한 것이다.',
        '- ①은 기존 주말 최대차와 필수조건을 유지하면서 편차 제곱합 비악화만 보조 목표로 내린 구현이다.',
        '- ②도 개인 월별 총량과 날짜별 인원 구성을 보존하는 범위의 28일 동시 재편성이다. 모든 제약 없는 자유 최적화가 아니다.',
        '- 짧은 탐색으로 얻은 실행 결과이며 최적성·불가능성 또는 조합 간 보편적 우열을 증명하지 않는다.',
        '- 초기 pilot 및 중단한 screen 폴더는 모델 준비 자료다. 비교 결과에는 screen-v2만 사용한다.',
        '- 모델은 고정 기준표 3개를 모두 표현했고, CP-SAT의 독립 구간/반복 직원 집계가 기존 검증기와 일치했다.',
        '', 'HTML SHA-256: `'+hashlib.sha256((root/'index.html').read_bytes()).hexdigest()+'`']
confirm=folder/'confirmation-summary.json'
if confirm.exists():
 lines+=['','## 다른 seed·추가 사례 확인','',
         '기존 5회차와 선별에 없던 3회차, seed 20261105, 조합당 30초.','',
         '| 조합 | 독립 구간 | 반복 직원·기간 | 주말 편차 제곱합 |','|---|---:|---:|---:|']
 for r in json.loads(confirm.read_text()):lines.append(f"| {names[r['code']]} | {r['episodes']} | {r['repeated']} | {r['weekendSquares']} |")
 lines+=['','장기 시험에는 휴식 개선이 큰 ①+②만 선택했다. 주말 최대차는 유지하지만 세부 분포 악화라는 손익이 있다.',
         '1차 세 사례에서 현재 주말 OFF가 2일 차이인 비교 가능한 직원 쌍은 19→72쌍으로 늘었다.',
         '②+③은 주말 편차 제곱합도 보호하는 대안이다. 이번 장기 시험의 대상은 아니다.']
chainfile=folder/'long-110/4week-report.json'
auditfile=folder/'long-110/quality-audit.json'
if chainfile.exists():
 chain=json.loads(chainfile.read_text());periods=chain['reports']
 lines+=['','## ①+② 새 연속 생성','',f"현재 상태: {len(periods)}/7회. 각 표를 해당 실험의 실제 이력으로 연결했다.",
         '12→24→48회로 초안 탐색을 확대하며, 기준을 통과한 초안에 40초 최적화를 적용한다.',
         '아래 전/후는 같은 회차에서 최적화 직전 초안과 최적화 후 결과의 비교다. 별도 장기 대조군은 아니다.','',
         '| 회차 | 기간 | 독립 구간 전→후 | 반복 직원 전→후 | 주말 현재/누적 차이 |',
         '|---|---|---:|---:|---:|']
 for p in periods:
  b,v=p['initial'],p['final']
  lines.append(f"| {p['index']} | {p['start']}~{p['end']} | {b['episodes']}→{v['episodes']} | {b['repeated']}→{v['repeated']} | {v['weekendGap']}/{v['weekendRollingGap']} |")
 if auditfile.exists():
  audit=json.loads(auditfile.read_text())
  lines+=['','독립 장기 감사 상태: '+audit['status']+' ('+str(len(audit['periods']))+'회).','',
          '```json',json.dumps(audit['totals'],ensure_ascii=False,indent=2),'```','',
          '기간별 비중첩 구간 합계와 전체 날짜를 연결한 비중첩 구간 합계는 경계 중복 때문에 다를 수 있다.',
          '최종 회차 이후의 미입력 미래 근무는 추정하지 않는다. 알려진 다음 회차가 있는 경계만 검증한다.',
          '마지막 회차의 다음 기간 회복휴무 확인 알림: '+str(len(audit['periods'][-1]['boundary']['pending']))+'건. 이는 확인된 규칙 위반이 아니라 아직 입력되지 않은 다음 근무표에서 확인할 항목이다.']
 lines+=['','이전 recovery.1 연속 시험과는 생성 예산과 이력이 달라 직접적인 효과 대조로 사용하지 않는다.',
         '교육 이력 행·임신 보호 행 등은 이번 모델에서 보수적으로 고정했다. isNewbie/precId 표시를 기준으로 교육 종료 후에도 해당 행을 고정한 제한이 있다. 이는 프로그램의 필수조건이 아니며, 남은 구간이 구조적으로 불가능하다는 뜻은 아니다.']
(folder/'REPORT.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(result,ensure_ascii=False))
