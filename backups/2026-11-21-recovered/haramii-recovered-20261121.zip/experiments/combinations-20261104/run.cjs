const fs=require('fs'),path=require('path'),crypto=require('crypto'),{spawnSync}=require('child_process');
const {a,json,html,cmp,sum,brief,score,mutable,prepare,audit}=require('./common.cjs');
const root=path.resolve(__dirname,'../..'),python=process.env.EXPERIMENT_PYTHON||'/workspace/haramii-experiment-venv/bin/python';
const hash=v=>crypto.createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
const write=(p,v)=>{fs.writeFileSync(p+'.tmp',JSON.stringify(v,null,2));fs.renameSync(p+'.tmp',p);};
async function local(x,m,flags,seconds,seed){
 const began=Date.now(),base=a.Recovery.current(x,m);let current=json(m),q=base,moves=0,checked=0,proposals=0;
 let bestScore=score(q,flags),rejections={};
 while(Date.now()-began<seconds*1000){let found=false;
  const candidates=function*(){yield* a.Rebuild.restCandidates(x,current,q.spread.rows);for(const matrix of a.Recovery.candidates(x,current,{blocks:true}))yield {matrix};};
  for(const {matrix} of candidates()){
   if(Date.now()-began>=seconds*1000)break;proposals++;
   const ids=matrix.flatMap((r,i)=>r===current[i]?[]:[i]);
   if(ids.some(i=>matrix[i].some((v,d)=>v!==current[i][d]&&!mutable(x,m,i,d))))continue;
   const dates=[...new Set(ids.flatMap(i=>matrix[i].flatMap((v,d)=>v!==current[i][d]?[d]:[])))];
   if(dates.some(d=>['D','E','N'].some(sh=>[false,true].some(senior=>{
    const delta=ids.reduce((n,i)=>n+(Number(matrix[i][d]===sh)-Number(current[i][d]===sh))*Number((senior?x.staff[i].isSenior&&!x.staff[i].isDispatch:a.E.eligible(x.staff[i],x.rules,x,d))&&a.E.covers(x,x.staff[i],d,sh)),0);return delta!==0;
   }))))continue;
   if(ids.some(i=>a.E.patternIssuesForSurplus(x,x.staff[i],matrix[i]).some(e=>e.level!=='warning')))continue;
   const rows=q.spread.rows.map((r,i)=>matrix[i]===current[i]?r:a.B.rowReport(x,x.staff[i],matrix[i]));
   if(rows.some((r,i)=>r.score[0]>base.spread.rows[i].score[0]||r.episodes.length>(flags.C?Math.max(1,base.spread.rows[i].episodes.length):base.spread.rows[i].episodes.length)))continue;
   if(sum(rows.map(r=>r.episodes.length))>base.spread.independentWindows)continue;
   const partial={...q,spread:{...q.spread,rows}};
   if(cmp(score(partial,flags),bestScore)>=0)continue;
   checked++;const check=audit(x,m,matrix,flags,base);
   if(!check.ok){for(const e of check.errors)rejections[e]=(rejections[e]||0)+1;continue;}
   const nextScore=score(check.q,flags);if(cmp(nextScore,bestScore)>=0)continue;
   current=matrix;q=check.q;bestScore=nextScore;moves++;found=true;break;
  }if(!found)break;
 }
 return {matrix:current,solver:{kind:'bounded-local',seconds:(Date.now()-began)/1000,moves,checked,proposals,rejections,seed}};
}
async function experiment(x,m,flags,{seconds=15,seed=20261104,out,name='run'}={}){
 fs.mkdirSync(out,{recursive:true});const frozen=hash(x),started=Date.now(),before=brief(x,m),base=a.Recovery.current(x,m);
 let r;
 if(flags.B){
  const spec=prepare(x,m),input=path.join(out,name+'-model.json'),output=path.join(out,name+'-solver.json');write(input,spec);
  const child=spawnSync(python,[path.join(__dirname,'solve.py'),input,output,Number(flags.P)+'',Number(flags.C)+'',seconds+'',seed+''],{encoding:'utf8',timeout:(seconds+90)*1000,maxBuffer:1024*1024});
  if(child.status!==0)throw Error(child.stderr||child.error||child.stdout);
  const result=JSON.parse(fs.readFileSync(output));let current=m,bestScore=score(base,flags),accepted=0;const rejections={};
  for(const solution of result.solutions){const check=audit(x,m,solution.matrix,flags,base);if(!check.ok){for(const e of check.errors)rejections[e]=(rejections[e]||0)+1;continue;}
   accepted++;if(cmp(score(check.q,flags),bestScore)<0){current=solution.matrix;bestScore=score(check.q,flags);}}
  r={matrix:current,solver:{kind:'CP-SAT',status:result.status,seconds:result.seconds,candidates:result.solutions.length,accepted,rejections,seed,bound:result.bound}};
 }else r=await local(x,m,flags,seconds,seed);
 if(hash(x)!==frozen)throw Error('Input or history mutated');
 const final=audit(x,m,r.matrix,flags,base);if(!final.ok)throw Error('Final audit '+final.errors.join(','));
 const report={name,flags,budgetSeconds:seconds,ms:Date.now()-started,before,after:final.brief,solver:r.solver,
   improved:cmp(score(final.q,flags),score(base,flags))<0,inputSHA256:frozen,htmlSHA256:hash(html)};
 write(path.join(out,name+'.json'),{input:x,matrix:r.matrix,report});
 return {matrix:r.matrix,report};
}
module.exports={experiment,brief,hash,write};
if(require.main===module)(async()=>{
 const [out,caseText='5,2,6',flagText='000,100,001,101,010,110,011,111',time='15',seedText='20261104']=process.argv.slice(2);
 fs.mkdirSync(out,{recursive:true});const reports=[];
 for(const n of caseText.split(',').map(Number)){
  const v=JSON.parse(fs.readFileSync(path.join(root,`validation/recovery-v2/cases/case-${n}.json`))),x=json(v.input);delete x.surplusPlan.decision;delete x.surplusPlan.accepted;
  for(const f of flagText.split(',')){const name=`case-${n}-${f}-seed-${seedText}`,file=path.join(out,name+'.json');
   if(fs.existsSync(file)){reports.push(JSON.parse(fs.readFileSync(file)).report);continue;}
   const flags={P:f[0]==='1',B:f[1]==='1',C:f[2]==='1'};console.log(JSON.stringify({stage:'start',name}));
   const r=await experiment(x,v.result.matrix,flags,{out,name,seconds:+time,seed:+seedText});reports.push(r.report);write(path.join(out,'summary.json'),reports);
   console.log(JSON.stringify({name,before:r.report.before,after:r.report.after,solver:r.report.solver,ms:r.report.ms}));
  }
 }write(path.join(out,'summary.json'),reports);
})().catch(e=>{console.error(e.stack);process.exit(1)});
