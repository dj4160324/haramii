"""Bounded simultaneous 28-day CP-SAT experiment; output still needs JS audit."""
import sys,json,time
from ortools.sat.python import cp_model

data=json.load(open(sys.argv[1])); out=sys.argv[2]
P=bool(int(sys.argv[3])); C=bool(int(sys.argv[4])); seconds=float(sys.argv[5]); seed=int(sys.argv[6])
model=cp_model.CpModel(); n=data['n']; D=data['days']; base=data['matrix']; rules=data['rules']
work={'D','E','N','MID'}; rest={'OFF','LEAVE','M-LEAVE','SICK','MATERNITY','PARENTAL'}
vs={}; all_vars=[]
for i in range(n):
 for d in range(D):
  for sh in data['domains'][i][d]:
   v=model.new_bool_var(f'x_{i}_{d}_{sh}');vs[i,d,sh]=v;all_vars.append(v)
   model.add_hint(v,int(base[i][d]==sh))
  model.add_exactly_one(vs[i,d,sh] for sh in data['domains'][i][d])
def at(i,d,sh):
 if 0<=d<D:return vs.get((i,d,sh),0)
 row=data['rows'][i];seq=row['previous'] if d<0 else row['next'];k=len(seq)+d if d<0 else d-D
 return int(0<=k<len(seq) and seq[k]==sh)
def known(i,d):
 r=data['rows'][i]
 if 0<=d<D:return True
 seq=r['previous'] if d<0 else r['next'];k=len(seq)+d if d<0 else d-D
 return 0<=k<len(seq) and seq[k] is not None and seq[k]!='DISPATCH'
def ww(i,d):return sum(at(i,d,s) for s in work)
def rr(i,d):return sum(at(i,d,s) for s in rest)
def off(i,d):
 if 0<=d<D:
  return at(i,d,'OFF')+int(base[i][d]=='LEAVE' and data['rows'][i]['offlike'][len(data['rows'][i]['previous'])+d])
 k=len(data['rows'][i]['previous'])+d
 return int(0<=k<len(data['rows'][i]['offlike']) and data['rows'][i]['offlike'][k])
def leq_bool(expr,k,name):
 v=model.new_bool_var(name);model.add(expr>=k).only_enforce_if(v);model.add(expr<k).only_enforce_if(v.Not());return v
for i in range(n):
 for month in set(data['months']):
  days=[d for d in range(D) if data['months'][d]==month]
  for sh in ['D','E','N','OFF']:model.add(sum(at(i,d,sh) for d in days)==sum(base[i][d]==sh for d in days))
for d in range(D):
 for f in data['daily'][d]:
  model.add(sum(at(i,d,f['shift']) for i in f['ids'])==f['count'])
  model.add(sum(at(i,d,f['shift']) for i in f['senior'])==f['seniorCount'])
episodes=[];windows=[];repeated=[];night_penalties=[]
for i in range(n):
 row=data['rows'][i];h=len(row['previous']);future=len(row['next'])
 for d in range(D+future):
  model.add(at(i,d-1,'E')+at(i,d,'D')<=1)
  for sh in ['D','E','MID']:model.add(at(i,d-1,'N')+at(i,d,sh)<=1)
  for flag,sh in [('noNOD','D'),('noNOE','E')]:
   if rules.get(flag):model.add(at(i,d-2,'N')+off(i,d-1)+at(i,d,sh)<=2)
  for cap,fn in [(rules.get('maxWork'),ww),(rules.get('maxNightStreak'),lambda i,d:at(i,d,'N')),
                 (None if row['nightOnly'] else rules.get('maxOff'),off)]:
   if cap and d>=-h+cap:model.add(sum(fn(i,k) for k in range(d-cap,d+1))<=cap)
  cap=max(2,row.get('nightRun',3))
  if d>=-h+cap:model.add(sum(at(i,k,'N') for k in range(d-cap,d+1))<=cap)
 # Two consecutive N ending require two known rest days, including boundaries.
 for d in range(max(-h+1,-3),D):
  for delta in [1,2]:
   if known(i,d+delta):model.add(at(i,d-1,'N')+at(i,d,'N')-at(i,d+1,'N')<=1+rr(i,d+delta))
 # Existing schedules use 06/14/22 starts and 8-hour shifts; two rest days
 # give the required 48h. JS audits actual shift times and every other rule.
 singles=[]
 for d in range(D):
  b=model.new_bool_var(f'single_{i}_{d}')
  expr=at(i,d,'N')-at(i,d-1,'N')-at(i,d+1,'N')
  model.add(expr>=1).only_enforce_if(b);model.add(expr<=0).only_enforce_if(b.Not());singles.append(b)
 model.add(sum(singles)<=row['singles'])
 dp=[]
 for d in range(D):
  if all(known(i,k) for k in range(d-6,d+1)):
   worked=sum(ww(i,k) for k in range(d-6,d+1));model.add(worked<=6)
   flag=0 if row['excluded'][d] else leq_bool(worked,6,f'bad_{i}_{d}')
  else:flag=0
  windows.append(flag)
  e=model.new_int_var(0,5,f'episodes_{i}_{d}')
  model.add_max_equality(e,[dp[d-1] if d else 0,(dp[d-7] if d>=7 else 0)+flag]);dp.append(e)
 if not row['nightOnly'] and not row['dispatch']:
  for start in range(-6,D):
   ds=list(range(start,start+7))
   old=sum((row['previous'][h+k] if -h<=k<0 else base[i][k] if 0<=k<D else row['next'][k-D] if D<=k<D+future else None)=='N' for k in ds)
   model.add(sum(at(i,k,'N') for k in ds)<=max(3,old))
   if old>3:
    excess=model.new_int_var(0,4,f'night_excess_{i}_{start}')
    square=model.new_int_var(0,16,f'night_square_{i}_{start}')
    model.add_max_equality(excess,[0,sum(at(i,k,'N') for k in ds)-3])
    model.add_multiplication_equality(square,[excess,excess]);night_penalties.append(square)
 model.add(dp[-1]<=max(1,row['episodes']) if C else dp[-1]<=row['episodes'])
 episodes.append(dp[-1]);repeated.append(leq_bool(dp[-1],2,f'repeat_{i}'))
 # Connected manual leave/OFF cap, preserving automatic leave provenance.
 cap=0 if rules.get('leaveOffLimit')==0 else 1
 if any(row['manualLeave']):
  states=[(o,m,c) for o in range(cap+2) for m in [0,1] for c in [0,1] if not(o>cap and m and c)]
  ids={s:k for k,s in enumerate(states)};trans=[]
  for state,sid in ids.items():
   for symbol in range(4):
    o,ma,cu=state
    new=(0,0,0) if symbol==0 else (o,1,cu) if symbol==1 else (min(cap+1,o+1),ma,cu or symbol==3)
    if new in ids:trans.append((sid,symbol,ids[new]))
  symbols=[]
  for d in range(-h,D+future):
   k=h+d
   if row['manualLeave'][k]:symbols.append(model.new_constant(1))
   elif 0<=d<D:
    symbol=model.new_int_var(0,3,f'leavecode_{i}_{d}');model.add(symbol==3*off(i,d));symbols.append(symbol)
   else:symbols.append(model.new_constant(2 if row['offlike'][k] else 0))
  model.add_automaton(symbols,ids[0,0,0],list(ids.values()),trans)
model.add(sum(episodes)<=data['baseline']['episodes'])
max_ep=model.new_int_var(0,5,'max_episode');model.add_max_equality(max_ep,episodes)
all_squares=[];scopes={}
for pidx,p in enumerate(data['pairs']):
 k=p['scope']+'|'+p.get('month','');limit=data['scopeLimits'][k]
 gap=model.new_int_var(-100,100,f'gap_{pidx}')
 model.add(gap==p['pastA']-p['pastB']+sum(at(p['a'],d,'OFF')+at(p['a'],d,'LEAVE')-at(p['b'],d,'OFF')-at(p['b'],d,'LEAVE') for d in p['days']))
 bound=min(2,limit['peak']) if p['scope']=='current' else limit['peak']
 model.add(gap<=bound);model.add(gap>=-bound)
 square=model.new_int_var(0,bound*bound,f'square_{pidx}');model.add_multiplication_equality(square,[gap,gap]);all_squares.append(square);scopes.setdefault(k,[]).append(square)
if not P:
 for k,squares in scopes.items():model.add(sum(squares)<=data['scopeLimits'][k]['squares'])
for g in data['groups']:
 expr=g['constant']+sum(t['c']*(at(t['i'],t['d'],'OFF')+at(t['i'],t['d'],'LEAVE')) for t in g['terms'])
 model.add(expr<=g['limit']);model.add(expr>=-g['limit'])
weekend_bound=sum(data['scopeLimits'][p['scope']+'|'+p.get('month','')]['peak']**2 for p in data['pairs'])+1
window_bound=n*D+1
if C:
 burden=(sum(repeated)*6+max_ep)*(n*5+1)+sum(episodes)
else:
 # Counts above each burden threshold are equivalent to a sorted descending
 # personal-burden profile; use base n+1 for exact lexicographic ordering.
 burden=0
 for level in range(5,0,-1):
  indicators=[leq_bool(e,level,f'ge_{level}_{i}') for i,e in enumerate(episodes)]
  burden=burden*(n+1)+sum(indicators)
objective=(burden*window_bound+sum(windows))*weekend_bound+sum(all_squares)
if night_penalties:
 lower_bound=((n+1)**6*window_bound+n*D)*weekend_bound+weekend_bound
 objective+=sum(night_penalties)*lower_bound
model.minimize(objective)
if '--fix-baseline' in sys.argv:
 for i in range(n):
  for d in range(D):model.add(at(i,d,base[i][d])==1)

class Collector(cp_model.CpSolverSolutionCallback):
 def __init__(self):super().__init__();self.solutions=[]
 def on_solution_callback(self):
  matrix=[[next(sh for sh in data['domains'][i][d] if self.value(vs[i,d,sh])) for d in range(D)] for i in range(n)]
  self.solutions.append({'matrix':matrix,'objective':self.objective_value,'seconds':self.wall_time,
                         'episodes':sum(self.value(v) for v in episodes),'repeated':sum(self.value(v) for v in repeated)})
  if len(self.solutions)>80:self.solutions=self.solutions[-80:]
solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=seconds
solver.parameters.num_search_workers=4;solver.parameters.random_seed=seed
solver.parameters.log_search_progress=False
collector=Collector();began=time.monotonic();status=solver.solve(model,collector)
result={'status':solver.status_name(status),'seconds':time.monotonic()-began,'workers':4,'bound':solver.best_objective_bound,
        'objective':solver.objective_value,'solutions':collector.solutions,'P':P,'C':C,'seed':seed,
        'response':solver.response_stats()}
json.dump(result,open(out,'w'));print(json.dumps({k:v for k,v in result.items() if k not in ['solutions','response']}))
