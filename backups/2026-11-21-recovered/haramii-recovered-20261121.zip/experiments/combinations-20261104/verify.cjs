const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {a,audit,WORK}=require('./common.cjs');
const dir=process.argv[2];let runs=0,solutions=0;
for(const name of fs.readdirSync(dir).filter(n=>/^case-\d+-[01]{3}-seed-\d+\.json$/.test(n))){
 const v=JSON.parse(fs.readFileSync(path.join(dir,name))),r=v.report;
 const original=JSON.parse(fs.readFileSync(path.join(__dirname,'../../validation/recovery-v2/cases/case-'+name.split('-')[1]+'.json'))).result.matrix;
 assert(audit(v.input,original,v.matrix,r.flags).ok,name);
 const counts=[];
 v.input.staff.forEach((s,i)=>{
  const prev=s.previousShifts||[],seq=[...prev,...v.matrix[i]],h=prev.length,dp=[0];
  for(let d=0;d<v.matrix[i].length;d++){
   const block=seq.slice(Math.max(0,h+d-6),h+d+1),known=block.length===7&&!block.some(sh=>sh==null||sh==='DISPATCH');
   const excluded=s.isDispatch||Array.from({length:Math.min(7,d+1)},(_,k)=>d-k).every(k=>a.T.trainee(v.input,s,k)||['MATERNITY','PARENTAL'].includes(v.matrix[i][k]));
   const work=block.filter(sh=>WORK.includes(sh)).length;
   assert(!(known&&work===7),name+' seven workdays');
   dp.push(Math.max(dp[d],dp[Math.max(0,d-6)]+Number(known&&!excluded&&work>=6)));
  }
  counts.push(dp.at(-1));
 });
 assert.deepEqual(counts,r.after.counts,name+' independent recount');
 if(r.flags.B){
  const cp=JSON.parse(fs.readFileSync(path.join(dir,name.replace('.json','-solver.json'))));
  for(const sol of cp.solutions){const q=a.B.report(v.input,sol.matrix);assert.equal(sol.episodes,q.independentWindows);assert.equal(sol.repeated,q.repeatedStaff);solutions++;}
 }
 runs++;
}
const result={runs,solverCandidatesRecounted:solutions,independentRecount:true,fullAuditPassed:true};
fs.writeFileSync(path.join(dir,'independent-verification.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
