import json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=root/'validation/cpsat-toggle-20261112'
rows=json.loads((out/'summary.json').read_text())
assert len(rows)==6
audit=json.loads((out/'independent-audit.json').read_text())
assert len(audit['reports'])==6 and audit['allCountsMatch']
pairs=[]
for n in [5,2,6]:
    off=next(r for r in rows if r['case']==n and r['arm']=='off')
    on=next(r for r in rows if r['case']==n and r['arm']=='on')
    assert off['inputHash']==on['inputHash'] and off['baselineMatrixHash']==on['baselineMatrixHash']
    assert off['changedCells']==0
    if on['status']=='skipped':assert on['changedCells']==0 and on['final']==off['final']
    assert off['final']['hard']==on['final']['hard']==0
    assert off['final']['fair']==on['final']['fair']==0
    pairs.append({'case':n,'off':off,'on':on})
def agg(rs):
    q=[r['final'] for r in rs]
    return dict(episodes=sum(v['episodes'] for v in q),repeated=sum(v['repeated'] for v in q),
        distribution=[sum(v['distribution'][i] for v in q) for i in range(5)],
        night=sum(v['night'] for v in q),seven=sum(v['seven'] for v in q),
        currentWeekend=[v['weekend'] for v in q],rollingWeekend=[v['rollingWeekend'] for v in q],
        weekendSquares=sum(v['weekendSquares'] for v in q),
        requestsUnmet=sum(t['unmet'] for v in q for t in v['unmetRequests'].values()),
        extraSeconds=round(sum(r['ms'] for r in rs)/1000,2))
executed=[p for p in pairs if p['on']['status']=='executed']
result={'all':{arm:agg([p[arm] for p in pairs]) for arm in ['off','on']},
        'executedOnly':{arm:agg([p[arm] for p in executed]) for arm in ['off','on']},
        'executedCases':[p['case'] for p in executed],'skippedCases':[p['case'] for p in pairs if p not in executed],
        'pairs':pairs}
(out/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
lines=['# 테스트 1 CP-SAT ON/OFF 비교 — 2026-11-12','',
'동일하게 저장된 생성 직후 표를 양쪽에 사용했다. OFF는 그대로 반환하고 ON은 이번에 동일한 설정으로 CP-SAT을 다시 실행했다. 세 목표 자체를 끈 대조군과 다른 비교다. 운영 HTML은 변경하지 않았다.','',
'| 사례 | CP-SAT | 상태 | 6일 근무 총 구간 | 정확히 1회 직원 | 2회 이상 직원 | 개인 최대 | 당회 주말 최대차 | 누적 주말 최대차 | 추가 실행시간 |',
'|---|---|---|---:|---:|---:|---:|---:|---:|---:|']
for p in pairs:
    for arm in ['off','on']:
        r=p[arm];q=r['final'];status={'disabled':'OFF','executed':'실행','skipped':'진입 조건으로 미실행'}[r['status']]
        lines.append(f"| {p['case']} | {arm.upper()} | {status} | {q['episodes']} | {q['distribution'][1]} | {q['repeated']} | {q['max']} | {q['weekend']} | {q['rollingWeekend']} | {r['ms']/1000:.2f}초 |")
lines+=['','22명×3개 독립 입력이며 회차별 인원은 중복될 수 있다. 6일 근무 반복은 중첩 없는 7일 구간 기준이다. 주말 차이는 기존 공통 비교 날짜/OFF+자동연차 기준이다.','',
'## 합계와 실제 실행 효과','',
'| 범위 | CP | 6일 근무 구간 | 2회 이상 직원·회차 | 0회 / 1회 / 2회 이상 |','|---|---|---:|---:|---|']
for scope,label in [('all','전체 3개 입력'),('executedOnly','실제 실행된 입력만')]:
    for arm in ['off','on']:
        v=result[scope][arm];d=v['distribution'];lines.append(f"| {label} | {arm.upper()} | {v['episodes']} | {v['repeated']} | {d[0]} / {d[1]} / {sum(d[2:])} |")
lines+=['','## 검증과 제한','',
'- 입력·과거 이력·확정 조건·자동연차/보강 계획 및 시작표 셀의 해시가 ON/OFF 사이에서 동일하다.',
'- ON은 기존 test1의 P=1/C=1/--band-priority와 같은 seed, 20초 예산, 4 worker를 사용했다. 목표나 보호조건을 완화하지 않았다.',
'- 사례 6은 당회 주말 차이 3일로 기존 진입 조건을 충족하지 않아 ON에서도 미실행이다. 이를 CP-SAT이 풀지 못한 결과로 해석하지 않는다. 이번 비교에서는 진입 조건도 바꾸지 않았다.',
'- OFF에서는 CP에 속한 추가 탐색을 수행하지 않는다. 같은 우선순위의 별도 대체 탐색을 OFF에 새로 추가하는 비교는 아니다.',
'- 모든 결과를 원래 검사기로 감사하고 raw-cell 계산으로 N 집중·7일 연속근무·6일 반복 횟수를 재집계했다. 기존 횟수 공평성 위반은 양쪽 모두 0이다. 사례 6의 주말 한도 미달은 그대로 남아 있다.',
f"- N 집중 점수 OFF/ON = {result['all']['off']['night']}/{result['all']['on']['night']}, 7일 연속근무 OFF/ON = {result['all']['off']['seven']}/{result['all']['on']['seven']}.",
f"- 주말 편차 제곱합 OFF/ON = {result['all']['off']['weekendSquares']}/{result['all']['on']['weekendSquares']}. 최대차 외의 세부 분포가 나빠질 수 있는 기존 우선순위는 유지했다.",
f"- 희망 미반영 합계 OFF/ON = {result['all']['off']['requestsUnmet']}/{result['all']['on']['requestsUnmet']}.",
'- 생성은 재실행하지 않았다. 공통 생성 비용은 양쪽에서 동일하고 표의 시간은 CP 처리·후보 검증의 추가 시간만 나타낸다.',
'- 시간 제한 다중 worker 검색은 같은 seed여도 과거의 ON 결과와 다를 수 있다. 이번 ON 결과를 이전 결과 중 더 좋은 것으로 교체하지 않았다.',
'- 새 6개월 연속시험이나 최적성 증명이 아니다. 결과는 현재 초안과 제한된 탐색 예산에 대한 효과다.','']
(out/'REPORT.md').write_text('\n'.join(lines))
files=[root/'index.html',root/'experiments/test2-20261112/solve.py',root/'experiments/test2-20261112/run.cjs',root/'source/src/whole-optimizer-core.js',*sorted((root/'experiments/cpsat-toggle-20261112').glob('*'))]
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='pairs'},ensure_ascii=False,indent=2))
