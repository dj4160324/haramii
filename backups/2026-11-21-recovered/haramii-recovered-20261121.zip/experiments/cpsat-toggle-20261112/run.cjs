// Matched test-1 ablation: one frozen generated roster, CP-SAT OFF versus ON.
// All scoring, constraints, eligibility, seed and solver budget stay unchanged.
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto'),{spawnSync}=require('child_process');
const {domains,json}=require('../../source/tests/helpers.cjs');
const {metrics,rank,check}=require('../test2-20261112/run.cjs');
const a=domains(),core=require('../../source/src/whole-optimizer-core.js')(a);
const root=path.resolve(__dirname,'../..'),source=path.join(root,'validation/test2-20261112/screen'),out=path.join(root,'validation/cpsat-toggle-20261112');
const hash=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p));
const write=(p,v)=>{fs.writeFileSync(p+'.tmp',JSON.stringify(v,null,2));fs.renameSync(p+'.tmp',p);};
function refine(x,m,{enabled,seconds,seed,prefix}){
 if(!enabled)return {matrix:json(m),solver:null,status:'disabled',ms:0};
 const base=a.Recovery.current(x,m),b=metrics(x,m);
 // Preserve the preceding test's eligibility gate, including its limitation.
 if(b.hard||b.fair||b.weekend>2)return {matrix:json(m),solver:null,status:'skipped',reason:b.hard?'existing-hard-error':b.fair?'existing-fairness-error':'current-weekend-gap-over-2',ms:0};
 const t=Date.now(),model=core.prepare(x,m);write(prefix+'-model.json',model);
 const args=[path.join(root,'experiments/test2-20261112/solve.py'),prefix+'-model.json',prefix+'-solver.json','1','1',String(seconds),String(seed),'--band-priority'];
 const proc=spawnSync('/workspace/haramii-experiment-venv/bin/python',args,{encoding:'utf8',timeout:(seconds+45)*1000});assert.equal(proc.status,0,proc.stderr||proc.error?.message);
 const solved=read(prefix+'-solver.json');let best=m,score=rank(base,'test1'),accepted=0;const rejected={};
 for(const sol of solved.solutions){const c=check(x,m,sol.matrix,'test1',base);
  assert.equal(c.brief.episodes,sol.episodes);assert.equal(c.brief.repeated,sol.repeated);
  if(!c.ok){for(const e of c.errors)rejected[e]=(rejected[e]||0)+1;continue;}
  accepted++;const next=rank(c.q,'test1');if(a.Recovery.cmp(next,score)<0){best=sol.matrix;score=next;}
 }
 assert(check(x,m,best,'test1',base).ok);
 return {matrix:best,status:'executed',ms:Date.now()-t,solver:{status:solved.status,candidates:solved.solutions.length,accepted,rejected,seconds:solved.seconds}};
}
module.exports={refine};
if(require.main===module){
 fs.mkdirSync(out,{recursive:true});const reports=[];
 for(const n of [5,2,6]){
  const p=path.join(source,`case-${n}-test1-generated.json`),v=read(p),prior=read(path.join(source,`case-${n}-test1.json`));
  assert.deepEqual(v.input,prior.input,'prior CP stage did not change input');
  const seed=prior.report.seed,seconds=prior.report.solverBudget,baseHash=hash(v.result.matrix),inputHash=hash(v.input);
  for(const [arm,enabled] of [['off',false],['on',true]]){
   const prefix=path.join(out,`case-${n}-${arm}`),x=json(v.input),before=json(v.result.matrix),frozen=hash([x,before]);
   console.log(JSON.stringify({stage:'start',case:n,arm,seed,seconds}));
   const opt=refine(x,before,{enabled,seconds,seed,prefix});assert.equal(hash([x,before]),frozen,'input and baseline immutable');
   if(!enabled||opt.status==='skipped')assert.deepEqual(opt.matrix,before);
   const generated=metrics(x,before),final=metrics(x,opt.matrix);
   assert.deepEqual(json(generated),prior.report.generated,'same recorded baseline metrics');
   const changedCells=before.reduce((sum,row,i)=>sum+row.filter((sh,d)=>sh!==opt.matrix[i][d]).length,0);
   const report={case:n,arm,seed,solverBudget:seconds,inputHash,baselineMatrixHash:baseHash,source:p,ms:opt.ms,status:opt.status,reason:opt.reason||null,generated,final,solver:opt.solver,changedCells};
   write(prefix+'.json',{input:x,matrix:opt.matrix,report});reports.push(report);write(path.join(out,'summary.json'),reports);
   console.log(JSON.stringify({stage:'done',case:n,arm,status:opt.status,changedCells,episodes:final.episodes,repeated:final.repeated,weekend:final.weekend,rolling:final.rollingWeekend,solver:opt.solver}));
  }
 }
}
