// Test 1 baseline: admit weekend-invalid drafts, retain every output guard.
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),{spawnSync}=require('child_process');
const {domains,json}=require('../../source/tests/helpers.cjs');
const {metrics,rank,check}=require('../test2-20261112/run.cjs');
const a=domains(),core=require('../../source/src/whole-optimizer-core.js')(a);
const solverPath=path.resolve(__dirname,'../test2-20261112/solve.py');
function eligibility(x,m,repairWeekend=true){
 if(x.actualRecording||x.surplusPlan?.decision==='KEEP')return 'protected-result';
 if((x.surplusHistory?.periods||[]).some(p=>p.status==='actual'&&p.start===x.dates[0].iso&&p.end===x.dates.at(-1).iso))return 'actual-period';
 const b=metrics(x,m);
 return b.hard?'existing-hard-error':b.fair?'existing-fairness-error':!repairWeekend&&b.weekend>2?'current-weekend-gap-over-2':null;
}
function adopt(x,before,solved){
 const base=a.Recovery.current(x,before),baselineValid=check(x,before,before,'test1',base).ok;
 let best=baselineValid?before:null,score=baselineValid?rank(base,'test1'):null,accepted=0;const rejected={};
 for(const sol of solved.solutions||[]){
  const m=sol.matrix;
  if(!Array.isArray(m)||m.length!==before.length||m.some(r=>!Array.isArray(r)||r.length!==before[0].length)){rejected.shape=(rejected.shape||0)+1;continue;}
  const c=check(x,before,m,'test1',base);
  if(sol.episodes!==undefined)assert.equal(c.brief.episodes,sol.episodes);
  if(sol.repeated!==undefined)assert.equal(c.brief.repeated,sol.repeated);
  if(!c.ok){for(const e of c.errors)rejected[e]=(rejected[e]||0)+1;continue;}
  accepted++;const next=rank(c.q,'test1');
  // An invalid starting draft is never a competitor to a valid repair.
  if(best===null||a.Recovery.cmp(next,score)<0){best=m;score=next;}
 }
 if(best===null)return {matrix:json(before),status:'unresolved',accepted,rejected,confirmationReady:false};
 assert(check(x,before,best,'test1',base).ok);
 return {matrix:best,status:baselineValid?(best===before?'unchanged':'improved'):'repaired',accepted,rejected,confirmationReady:true};
}
function refine(x,m,{prefix,seed,seconds=20,repairWeekend=true}={}){
 const reason=eligibility(x,m,repairWeekend);if(reason)return {matrix:json(m),status:'skipped',reason,confirmationReady:false,solver:null,ms:0};
 const frozen=JSON.stringify([x,m]),start=Date.now();fs.writeFileSync(prefix+'-model.json',JSON.stringify(core.prepare(x,m)));
 const proc=spawnSync('/workspace/haramii-experiment-venv/bin/python',[solverPath,prefix+'-model.json',prefix+'-solver.json','1','1',String(seconds),String(seed),'--band-priority'],{encoding:'utf8',timeout:(seconds+45)*1000});
 assert.equal(JSON.stringify([x,m]),frozen);
 if(proc.status!==0)return {matrix:json(m),status:'solver-error',confirmationReady:false,solver:null,ms:Date.now()-start,reason:proc.error?.message||proc.stderr};
 const solved=JSON.parse(fs.readFileSync(prefix+'-solver.json')),picked=adopt(x,m,solved);
 return {...picked,solver:{status:solved.status,seconds:solved.seconds,candidates:solved.solutions.length},ms:Date.now()-start};
}
module.exports={eligibility,adopt,refine};
