const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('node:assert/strict');
const {refine,adopt,eligibility}=require('./optimizer.cjs');
const {metrics}=require('../test2-20261112/run.cjs');
const {domains,json}=require('../../source/tests/helpers.cjs'),a=domains();
const root=path.resolve(__dirname,'../..'),out=path.join(root,'validation/test1-gate-20261114');
const read=p=>JSON.parse(fs.readFileSync(path.join(root,p))),hash=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const write=(p,v)=>fs.writeFileSync(path.join(out,p),JSON.stringify(v,null,2));fs.mkdirSync(out,{recursive:true});
const reports=[];
// Regression: valid drafts select exactly the same historical candidates.
for(const n of [5,2]){
 const v=read(`validation/test2-20261112/screen/case-${n}-test1-generated.json`),solved=read(`validation/cpsat-toggle-20261112/case-${n}-on-solver.json`),old=read(`validation/cpsat-toggle-20261112/case-${n}-on.json`);
 const r=adopt(v.input,v.result.matrix,solved);assert.deepEqual(json(r.matrix),old.matrix);
 console.log('PASS unchanged selection on valid draft:',n);
}
const v=read('validation/test2-20261112/screen/case-6-test1-generated.json'),prior=read('validation/test2-20261112/screen/case-6-test1.json'),x=v.input,m=v.result.matrix;
assert.equal(eligibility(x,m,false),'current-weekend-gap-over-2');assert.equal(eligibility(x,m,true),null);
const bad=adopt(x,m,{solutions:[{matrix:m}]});assert.equal(bad.status,'unresolved');assert.equal(bad.confirmationReady,false);assert.deepEqual(bad.matrix,m);
const empty=adopt(x,m,{solutions:[]});assert.equal(empty.status,'unresolved');assert.equal(empty.confirmationReady,false);
const keep=json(x);keep.surplusPlan.decision='KEEP';assert.equal(eligibility(keep,m,true),'protected-result');
const actual=json(x);actual.actualRecording=true;assert.equal(eligibility(actual,m,true),'protected-result');
console.log('PASS gate, invalid/no-solution fallback, KEEP and actual history guards');
const inputHash=hash(x),frozen=hash([x,m]),before=metrics(x,m);
for(const [arm,repairWeekend] of [['old',false],['repair',true]]){
 const opt=refine(x,m,{prefix:path.join(out,`case-6-${arm}`),seed:prior.report.seed,seconds:20,repairWeekend});
 assert.equal(hash([x,m]),frozen);const final=metrics(x,opt.matrix);
 const report={case:6,arm,inputHash,ms:opt.ms,status:opt.status,confirmationReady:opt.confirmationReady,reason:opt.reason||null,generated:before,final,solver:opt.solver};
 write(`case-6-${arm}.json`,{input:x,matrix:opt.matrix,report});reports.push(report);write('summary.json',reports);console.log(JSON.stringify({arm,status:opt.status,ready:opt.confirmationReady,before:{episodes:before.episodes,repeated:before.repeated,weekend:before.weekend,rolling:before.rollingWeekend},after:{hard:final.hard,fair:final.fair,night:final.night,seven:final.seven,episodes:final.episodes,repeated:final.repeated,weekend:final.weekend,rolling:final.rollingWeekend},solver:opt.solver}));
}
const education=x.staff.flatMap((s,i)=>{const students=x.staff.filter(t=>t.precId===s.id);if(!s.isNewbie&&!students.length)return [];
 return [{id:s.id,isNewbie:s.isNewbie,independenceDate:s.independenceDate||null,students:students.map(t=>({id:t.id,independenceDate:t.independenceDate||null})),trainingDays:x.dates.filter((_,d)=>a.T.trainee(x,s,d)).length,otherwiseMutableDays:x.dates.flatMap((t,d)=>a.Recovery.mutable(x,m,i,d)?[t.iso]:[])}];});
write('education-locks.json',{start:x.dates[0].iso,end:x.dates.at(-1).iso,education});
