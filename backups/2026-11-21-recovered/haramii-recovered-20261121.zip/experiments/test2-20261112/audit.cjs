// Recount from raw cells using the unchanged program, not experimental scores.
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {domains}=require('../../source/tests/helpers.cjs'),a=domains();
const work=new Set(['D','E','N','MID']);
const dir=process.argv[2]||path.resolve(__dirname,'../../validation/test2-20261112/screen');
const summary=JSON.parse(fs.readFileSync(path.join(dir,'summary.json'))),reports=[];
for(const r of summary){
 const v=JSON.parse(fs.readFileSync(path.join(dir,`case-${r.case}-${r.arm}.json`))),x=v.input,m=v.matrix,counts=[];let seven=0,nightScore=0,windows=0;
 x.staff.forEach((s,i)=>{
  const prev=s.previousShifts||[],next=a.T.nextShifts(x,s)||[],get=d=>d<0?prev[prev.length+d]:d>=m[i].length?next[d-m[i].length]:m[i][d],dp=Array(m[i].length+1).fill(0);
  for(let end=0;end<m[i].length+6;end++){
   const ds=Array.from({length:7},(_,k)=>end-6+k),values=ds.map(get);
   if(values.every(sh=>work.has(sh)))seven++;
   if(end>=m[i].length)continue;
   dp[end+1]=dp[end];if(s.isDispatch||values.some(sh=>sh==null||sh==='DISPATCH'))continue;
   if(ds.filter(d=>d>=0).every(d=>a.T.trainee(x,s,d)||['MATERNITY','PARENTAL'].includes(get(d))))continue;
   if(values.filter(sh=>work.has(sh)).length>=6){windows++;dp[end+1]=Math.max(dp[end+1],dp[Math.max(0,end-6)]+1);}
  }
  counts.push(dp.at(-1));
  if(!s.isDispatch&&!s.isNightOnly)for(let start=-6;start<m[i].length;start++){
   const ds=Array.from({length:7},(_,k)=>start+k),active=ds.filter(d=>d>=0&&d<m[i].length);
   if(active.every(d=>a.T.trainee(x,s,d)||['MATERNITY','PARENTAL','DISPATCH'].includes(get(d))))continue;
   nightScore+=Math.max(0,ds.filter(d=>get(d)==='N').length-3)**2;
  }
 });
 assert.deepEqual(counts,r.final.counts);assert.equal(seven,r.final.seven);assert.equal(nightScore,r.final.night);assert.equal(windows,r.final.windows);
 const errors=a.E.validate(x,m).filter(e=>e.level==='error'),fair=a.F.analyse(x,m).breaches,additional=[];
 x.dates.forEach((t,d)=>{for(const sh of ['D','E','N']){
  const staff=x.staff.filter((s,i)=>m[i][d]===sh&&a.E.eligible(s,x.rules,x,d)&&a.E.covers(x,s,d,sh));
  if(staff.length<a.E.quota(x,d,sh))additional.push('coverage:'+t.iso+sh);
 }});
 x.staff.forEach((s,i)=>x.dates.forEach((t,d)=>{const fixed=a.E.fixed(x,s,d);if(fixed.length&&!fixed.includes(m[i][d]))additional.push('fixed:'+s.id+':'+t.iso);}));
 for(const g of x.surplusPlan?.grants||[]){const i=x.staff.findIndex(s=>a.S.identity(s)===g.key),d=x.dates.findIndex(t=>t.iso===g.date);if(i<0||d<0||m[i][d]!=='LEAVE'||!a.Annual.consent(x,x.staff[i]))additional.push('annual:'+g.key+g.date);}
 additional.push(...a.Recovery.floorBlockers(x,m).map(f=>'floor:'+f.d+f.shift));
 assert.equal(errors.length,r.final.hard);assert.equal(fair.length,r.final.fair);assert.equal(additional.length,0,additional.join(','));
 reports.push({case:r.case,arm:r.arm,rawCounts:counts,seven,nightScore,windows,hard:errors.length,fair:fair.length,additional});
}
for(const n of [...new Set(summary.map(r=>r.case))])assert.equal(new Set(summary.filter(r=>r.case===n).map(r=>r.inputHash)).size,1,'equal initial inputs');
fs.writeFileSync(path.join(dir,'independent-audit.json'),JSON.stringify({reports,allCountsMatch:true,equalInputHashes:true},null,2));
console.log('PASS independent raw counts, staffing/fixed/annual/floors and equal initial inputs:',reports.length,'outputs');
