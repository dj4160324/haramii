const assert=require('node:assert/strict');
const {runtime}=require('./runtime.cjs'),{fixture}=require('../../source/tests/helpers.cjs');
const x=fixture({days:14,n:2,seniors:0,quota:{D:0,E:0,N:0},enabled:false});
Object.assign(x,{restSpreadPolicy:2,weekendPolicy:2,continuityPolicy:1,futureBalancePolicy:1,restRebuildPolicy:1});
const m=[['N','N','OFF','OFF','N','N','OFF','OFF','D','D','D','OFF','D','D'],Array(14).fill('OFF')];
for(const arm of ['control','test1','test2']){
 const a=runtime(arm),q=a.Recovery.current(x,m);
 assert(a.E.validate(x,[Array(14).fill('D'),m[1]]).some(e=>e.code==='WORK_SEVEN'));
 if(arm==='control'){
  assert.equal(q.spread.score[0],0);assert(q.spread.rows.every(r=>!r.episodes.length));
  assert(a.Weekend.evaluate(m,a.Weekend.prepare(x,m)).score.every(v=>v===0));
  assert.equal(a.B.assignmentCost(x,x.staff[0],m[0],4,'N'),0);
  assert(!Object.keys(q.metrics).some(k=>k.startsWith('weekend')));
 }else assert(q.spread.score[0]>0);
 console.log('PASS mandatory guard and mode:',arm);
}
const a=runtime('test2'),p={version:2,pairs:[{scope:'current',pastA:2,pastB:0,days:[],a:0,b:1},{scope:'rolling',pastA:2,pastB:0,days:[],a:0,b:1}]};
assert(a.Weekend.evaluate(m,p).score.every(v=>v===0));p.pairs[1].pastA=3;assert(a.Weekend.evaluate(m,p).score.some(v=>v>0));
console.log('PASS two-day weekend band accepts 2 and penalizes 3');
