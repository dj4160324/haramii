import json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2]
folder=root/'validation/test2-20261112/screen'
rs=json.loads((folder/'summary.json').read_text())
assert len(rs)==9
aud=json.loads((folder/'independent-audit.json').read_text())
assert len(aud['reports'])==9 and aud['allCountsMatch']
labels={'control':'대조군: 세 목표 제외','test1':'테스트 1: 직전 혼합안','test2':'테스트 2: N·휴식 선배치 + 주말 2일 목표'}
agg=[]
for arm,label in labels.items():
 items=[r for r in rs if r['arm']==arm];q=[r['final'] for r in items]
 agg.append(dict(arm=arm,label=label,mandatoryPass=sum(r['passesMandatory'] for r in items),
  targetPass=sum(r['passesThreeTargets'] for r in items),currentWeekendPass=sum(x['weekend']<=2 for x in q),
  episodes=sum(x['episodes'] for x in q),repeated=sum(x['repeated'] for x in q),
  distribution=[sum(x['distribution'][i] for x in q) for i in range(5)],
  nightScore=sum(x['night'] for x in q),nightStaffPeriods=sum(x['nightStaff'] for x in q),
  seven=sum(x['seven'] for x in q),weekend=[x['weekend'] for x in q],rolling=[x['rollingWeekend'] for x in q],
  weekendLowBy2=sum(len(x['weekendLowBy2']) for x in q),weekendLowOver2=sum(len(x['weekendLowOver2']) for x in q),
  rollingLowOver2=sum(len(x['rollingLowOver2']) for x in q),
  totalSeconds=round(sum(r['ms'] for r in items)/1000,1),
  nightGaps12to16=sum(x['nightGaps12to16'] for x in q),nightGapComparisons=sum(x['nightGapComparisons'] for x in q),
  annual=sum(x['annual'] for x in q),
  requestsSubmitted=sum(v['submitted'] for x in q for v in x['unmetRequests'].values()),
  requestsApplied=sum(v['applied'] for x in q for v in x['unmetRequests'].values()),
  requestsUnmet=sum(v['unmet'] for x in q for v in x['unmetRequests'].values())))
result={'caseOrder':[5,2,6],'aggregates':agg,'cases':rs}
(folder.parent/'comparison-summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
lines=['# 테스트 2 단기 비교 — 2026-11-12','',
'이번 제한된 시험에서는 세 목표를 폐기하는 것보다 유지하는 편이 유리했고, 테스트 2를 테스트 1 대신 채택할 근거는 얻지 못했다. 테스트 1을 다음 개선의 기준으로 유지하는 것을 권한다. 어느 안도 세 목표를 모두 달성한 완성본은 아니다. 운영 버전 채택은 하지 않았다.','',
'같은 28일 입력 3개(각각 22명, 사례 5·2·6)에서 각 버전이 새로 생성했다. 과거 실제 이력은 같은 자료로 고정했고 결과를 다음 사례에 이어 붙이지 않았다. 6개월 연속시험은 아니다.','',
'| 버전 | 필수/기존 공평성 통과 | N 집중 직원·회차 | 6일 근무 총 구간 | 2회 이상 직원·회차 | 0회 / 1회 / 2회 이상 | 당회 주말 최대차 | 누적 주말 최대차 | 합계 시간(초) |',
'|---|---:|---:|---:|---:|---|---|---|---:|']
for r in agg:
 d=r['distribution'];lines.append(f"| {r['label']} | {r['mandatoryPass']}/3 | {r['nightStaffPeriods']} | {r['episodes']} | {r['repeated']} | {d[0]} / {d[1]} / {sum(d[2:])} | {' / '.join(map(str,r['weekend']))} | {' / '.join(map(str,r['rolling']))} | {r['totalSeconds']} |")
lines+=['','인원은 22명×3표=66개 직원·회차이며, 같은 사람이 중복 집계될 수 있다. 6일 근무는 서로 겹치지 않는 7일 구간을 센다. 주말 최대차는 공통 비교 날짜 및 OFF+자동연차 기준이다. 전체 직원 순수 OFF의 최대−최소가 아니다.','',
'**실패 초안도 위 합계에 포함했다.** 사례 6에서 테스트 1은 당회 주말 차이 3일이 남았고, 테스트 2는 당회 주말 3일에 더해 기존 누적 N/OFF 공평성 한도 위반 3개가 남았다. 따라서 두 실험의 전체 72구간/17직원·회차가 같다는 이유로 동등한 성공으로 해석하면 안 된다.','',
'공통으로 기존 한도와 당회 주말 한도를 충족한 사례 5·2만 비교하면 테스트 1은 6일 근무 총 39구간·반복 직원 5명, 테스트 2는 총 40구간·반복 직원 7명이다(인원 중복 가능). 테스트 2의 추가 미충족은 선임 일반교대 비교군의 2026년 12월 누적 N 차이 3회, 12월/2027년 1월 누적 기본 OFF 차이 각각 3일이다. 해당 한도는 각각 2다. 이는 직원 3명이라는 뜻이 아니다.','',
'N 간격 12~16일의 비율은 테스트 1 약 18.2%, 테스트 2 약 42.9%로 초기 배치 의도는 일부 구현됐다. 그러나 이번 계산 예산에서는 휴식 반복·주말 균형·기존 공평성까지 함께 개선하는 효과는 확인되지 않았다. 개별 원인의 인과관계나 구조적 불가능성을 증명하는 시험은 아니다.','',
'## 사례별 세부 결과','',
'| 사례 | 버전 | 생성 직후 구간/반복 직원 | 최종 구간/반복 직원 | 최종 0회/1회/2회/3회/4회 | 당회/누적 주말 차이 | 당회 2일 적은 직원 ID | 당회 2일 초과 적은 직원 ID | 누적 2일 초과 적은 직원 ID |',
'|---|---|---|---|---|---|---|---|---|']
for r in rs:
 q=r['final'];b=r['generated'];lines.append(f"| {r['case']} | {r['arm']} | {b['episodes']}/{b['repeated']} | {q['episodes']}/{q['repeated']} | {'/'.join(map(str,q['distribution']))} | {q['weekend']}/{q['rollingWeekend']} | {q['weekendLowBy2']} | {q['weekendLowOver2']} | {q['rollingLowOver2']} |")
lines+=['','각 저수혜 직원 목록은 적어도 한 비교 상대보다 해당 차이만큼 적게 받은 직원의 중복 제거 목록이다. 서로 다른 상대와의 차이로 두 목록에 동시에 포함될 수 있다.','',
'## N 간격과 다른 수혜','',
'| 버전 | N 묶음 시작 간격 12~16일 / 비교 가능한 간격 | 자동연차 배분 합계 | 희망 반영/신청 |','|---|---|---:|---|']
for r in agg:lines.append(f"| {r['label']} | {r['nightGaps12to16']} / {r['nightGapComparisons']} | {r['annual']} | {r['requestsApplied']}/{r['requestsSubmitted']} |")
lines+=['','간격은 알려진 직전 근무까지 연결하며 N 전담·파견·임신은 제외했다. 이전 이력의 시작이 잘려 있으면 첫 묶음의 실제 시작이 다를 수 있다. N 묶음 수가 달라질 수 있으므로 분모도 같이 본다. 간격만 좋아졌다고 근무표 전체가 좋아졌다고 판단하지 않는다.','',
'## 검증·해석 범위','',
'- 필수 위반, 기존 횟수 공평성, 확정 입력, 자동연차 동의/배정, 보강 하한을 원래 검사기로 확인했다. 별도 raw-cell 계산으로 N 집중, 7일 연속근무, 6일 반복 횟수를 대조했다.',
f"- 7일 연속근무는 전체 {sum(r['seven'] for r in agg)}건이었다.",
'- 두 실험의 기본 초안은 각각 6회, 후속 CP-SAT은 각각 최대 20초다. 대조군에는 세 목표용 CP 후처리를 붙이지 않아 전체 계산량은 같지 않다. 실제 시간은 표에 공개했다.',
'- 유효한 초안이 없으면 CP 재조정을 건너뛰며 해당 실패도 포함한다. 불리한 결과를 다른 seed로 교체하지 않았다.',
'- 표의 필수/기존 공평성 통과는 최소인원·자격·확정신청·근무 패턴·N/OFF/D/E 횟수 한도의 검사다. 테스트 1/2는 당회 주말 차이 2일 초과 시 기존 주말 확정 한도도 미충족이다. 이것을 필수 검사 통과 수에 숨기지 않고 주말 열과 사례별 결과에서 따로 평가한다.',
'- 테스트 1은 직전 0~1회 혼합안이며 과거 모든 실험 중 최선의 결과를 임의로 고른 것이 아니다.',
'- 테스트 2의 14일 간격은 초기 배치 선호다. N 묶음과 휴식은 후속 단계에서 다시 움직일 수 있다. 누적 주말 2일은 목표이며 새 차단 기준이 아니다.',
'- 후속 CP 모델의 보수적인 직원 행/개인 월 횟수/날짜별 인원 고정은 유지했다. 남은 부담이 실제 운영상 불가능하다는 증거가 아니다.',
'- 표본은 입력 3개·seed 각 1개다. 장기 누적 부담 분산이나 모든 입력에서의 우수성을 입증하지 않는다.',
'- 운영 HTML과 GitHub 백업을 수정하지 않았다. 채택은 결과 검토 후 결정한다.','']
(folder.parent/'REPORT.md').write_text('\n'.join(lines))
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'index.html',*sorted((root/'experiments/test2-20261112').glob('*'))] if p.is_file()}
(folder.parent/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(agg,ensure_ascii=False,indent=2))
