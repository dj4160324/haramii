const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto'),{spawnSync}=require('child_process');
const {runtime}=require('./runtime.cjs'),{domains,json}=require('../../source/tests/helpers.cjs');
const a=domains(),core=require('../../source/src/whole-optimizer-core.js')(a),{bandScore}=require('../band-priority-20261110/run.cjs');
const root=path.resolve(__dirname,'../..'),out=path.join(root,'validation/test2-20261112');
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const write=(file,x)=>{fs.writeFileSync(file+'.tmp',JSON.stringify(x,null,2));fs.renameSync(file+'.tmp',file);};
function rank(q,arm){if(arm==='test1')return bandScore(q);const c=q.spread.rows.map(r=>r.episodes.length),ex=c.map(v=>Math.max(0,v-1));return [q.spread.score[0],Math.max(...ex),ex.reduce((s,v)=>s+v,0),c.filter(v=>v>=2).length,Math.max(0,(q.weekend.rollingGap||0)-2),c.reduce((s,v)=>s+v,0),q.spread.rows.reduce((s,r)=>s+r.restWindows.length,0)];}
function check(x,before,m,arm,base){const c=core.audit(x,before,m,{P:true,C:true},base);
 if(arm==='test2')c.errors=c.errors.filter(k=>{if(!k.startsWith('metric:weekend|')||!k.endsWith('|peak'))return true;const key=k.slice(7);return c.q.metrics[key]>Math.max(2,base.metrics[key])+1e-8;});
 c.ok=!c.errors.length;return c;}
function metrics(x,m){const q=a.Recovery.current(x,m),b=core.brief(x,m,q),pairs=q.weekend.pairs;
 const ids=ps=>[...new Set(ps.map(p=>x.staff[p.gap>0?p.b:p.a].id))];
 const starts=[],gaps=[];x.staff.forEach((s,i)=>{if(s.isNightOnly||s.isDispatch||s.isPregnant)return;const prev=s.previousShifts||[],seq=[...prev,...m[i]],h=prev.length,st=[];for(let d=0;d<seq.length;d++)if(seq[d]==='N'&&(d===0||seq[d-1]!=='N'))st.push(d-h);for(let k=1;k<st.length;k++)if(st[k]>=0)gaps.push(st[k]-st[k-1]);starts.push({id:s.id,starts:st});});
 const actual=x.staff.map((s,i)=>({id:s.id,count:x.dates.filter((t,d)=>(t.isSat||t.isSun)&&m[i][d]==='OFF').length}));
 return {...b,nightStaff:q.spread.rows.filter(r=>r.score[0]>0).length,weekendLowBy2:ids(pairs.filter(p=>p.scope==='current'&&Math.abs(p.gap)===2)),weekendLowOver2:ids(pairs.filter(p=>p.scope==='current'&&Math.abs(p.gap)>2)),rollingLowOver2:ids(pairs.filter(p=>p.scope==='rolling'&&Math.abs(p.gap)>2)),actualWeekendOff:actual,nightStartGaps:gaps,nightGaps12to16:gaps.filter(d=>d>=12&&d<=16).length,nightGapComparisons:gaps.length,nightStarts:starts,unmetRequests:q.preferences.totals,annual:x.surplusPlan?.grants?.length||0,hardIssues:q.issues.filter(e=>e.level==='error'),fairBreaches:q.fair.breaches};}
function optimize(x,m,arm,prefix,seconds,seed){const base=a.Recovery.current(x,m),model=core.prepare(x,m);write(prefix+'-model.json',model);
 const args=[path.join(__dirname,'solve.py'),prefix+'-model.json',prefix+'-solver.json','1','1',String(seconds),String(seed),'--band-priority'];if(arm==='test2')args.push('--two-day-band');
 const r=spawnSync('/workspace/haramii-experiment-venv/bin/python',args,{encoding:'utf8',timeout:(seconds+45)*1000});assert.equal(r.status,0,r.stderr||r.error?.message);
 const solved=JSON.parse(fs.readFileSync(prefix+'-solver.json'));let best=m,score=rank(base,arm),accepted=0,rejected={};
 for(const sol of solved.solutions){const c=check(x,m,sol.matrix,arm,base);assert.equal(c.brief.episodes,sol.episodes);assert.equal(c.brief.repeated,sol.repeated);if(!c.ok){for(const e of c.errors)rejected[e]=(rejected[e]||0)+1;continue;}accepted++;const next=rank(c.q,arm);if(a.Recovery.cmp(next,score)<0){best=sol.matrix;score=next;}}
 assert(check(x,m,best,arm,base).ok);return {matrix:best,solver:{status:solved.status,candidates:solved.solutions.length,accepted,rejected,seconds:solved.seconds}};
}
module.exports={metrics,rank,check};
if(require.main===module)(async()=>{
 const cases=(process.argv[2]||'5,2,6').split(',').map(Number),arms=(process.argv[3]||'control,test1,test2').split(','),attempts=+(process.env.DRAFT_ATTEMPTS||6),seconds=+(process.env.SOLVER_SECONDS||20),dir=path.join(out,process.env.RUN_NAME||'screen');fs.mkdirSync(dir,{recursive:true});
 const reports=[];
 for(const n of cases)for(const arm of arms){const prefix=path.join(dir,`case-${n}-${arm}`);if(fs.existsSync(prefix+'.json')){reports.push(JSON.parse(fs.readFileSync(prefix+'.json')).report);continue;}
  const fixture=JSON.parse(fs.readFileSync(path.join(root,`validation/recovery-v2/cases/case-${n}.json`))),x=json(fixture.input);delete x.surplusPlan;delete x.weekendPlan;delete x.actualRecording;
  const frozen=hash([x.staff,x.surplusHistory,x.preferenceHistory,x.workloadHistory]),inputHash=hash(x),seed=20261112+n*1337,api=runtime(arm),start=Date.now();let last=start;
  write(prefix+'-input.json',x);console.log(JSON.stringify({stage:'start',case:n,arm,seed}));
  const r=await api.E.generate(x,{attempts,seed,maxBlockMs:2000,onProgress:(i,t,s)=>{if(Date.now()-last>20000){console.log(JSON.stringify({stage:'generating',case:n,arm,ms:Date.now()-start,phase:s?.phase}));last=Date.now();}}});
  const generated=metrics(x,r.matrix);write(prefix+'-generated.json',{input:x,result:r,metrics:generated});
  let m=r.matrix,solver=null;
  if(arm!=='control'&&!generated.hard&&!generated.fair&&generated.weekend<=2){const opt=optimize(x,m,arm,prefix,seconds,seed);m=opt.matrix;solver=opt.solver;}
  const final=metrics(x,m);assert.equal(hash([x.staff,x.surplusHistory,x.preferenceHistory,x.workloadHistory]),frozen,'staff/history immutable');
  const report={case:n,arm,seed,attempts,solverBudget:arm==='control'?0:seconds,inputHash,ms:Date.now()-start,generated,final,solver,passesMandatory:final.hard===0&&final.fair===0&&final.seven===0,passesThreeTargets:final.night===0&&final.repeated===0&&final.weekend<=2&&(final.rollingWeekend??0)<=2};
  write(prefix+'.json',{input:x,matrix:m,report});reports.push(report);write(path.join(dir,'summary.json'),reports);console.log(JSON.stringify({stage:'done',case:n,arm,ms:report.ms,hard:final.hard,fair:final.fair,night:final.night,episodes:final.episodes,distribution:final.distribution,weekend:final.weekend,rolling:final.rollingWeekend,solver}));
 }
 write(path.join(dir,'summary.json'),reports);
})().catch(e=>{console.error(e.stack);process.exit(1)});
