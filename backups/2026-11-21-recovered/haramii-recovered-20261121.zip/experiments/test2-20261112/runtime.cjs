// Isolated experimental VM: the downloadable HTML is never modified.
const fs=require('fs'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../index.html'),'utf8');
function runtime(arm){
 let script=html.match(/<script>([\s\S]*?)<\/script>/)[1];script=script.slice(0,script.indexOf('    window.koreanHolidays'));
 function replace(from,to,count=1){if(script.split(from).length-1!==count)throw Error('anchor '+from.slice(0,100));script=script.split(from).join(to);}
 if(arm==='control'){
  // Keep N/OFF/annual/request expiry guidance; remove only weekend expiry.
  replace("for (const p of w.pairs.filter(p => p.scope === 'current')) {","for (const p of w.pairs.filter(p => p.scope === 'current')) { continue;");
  replace('    return {fair, weekend, spread, preferences, composition, issues, metrics};',"    for(const k of Object.keys(metrics))if(k.startsWith('weekend|')||k.startsWith('weekendGroup|'))delete metrics[k];\n    return {fair, weekend, spread, preferences, composition, issues, metrics};");
  script+=`
  const neutralRow=r=>({...r,score:[0,0,0],episodes:[],restWindows:[],monthlyEpisodes:{},peakWork:0});
  const actualRow=RosterSpread.rowReport,actualReport=RosterSpread.report;
  RosterSpread.rowReport=(...args)=>neutralRow(actualRow(...args));
  RosterSpread.report=(...args)=>{const r=actualReport(...args);return {...r,score:[0,0,0],objective:[0,0,0,0,0],rows:r.rows.map(neutralRow),restStaff:0,repeatedStaff:0,independentWindows:0};};
  for(const obj of [RosterSpread,RosterSpreadLegacy]){
   for(const key of ['assignmentCost','nightCost','offCost'])obj[key]=()=>0;
   for(const key of ['notWorse','requiredLimitSafe'])obj[key]=()=>true;
   obj.objective=()=>[0,0,0,0,0];obj.improve=async(x,r)=>r;
  }
  RosterSpread.finalise=async(x,r)=>r;RosterSpread.recoverDrafts=async(x,r)=>r;
  for(const key of ['nightDelta','nightScore','workCost'])RosterContinuity[key]=()=>0;
  for(const key of ['nightSafe','weekendSafe'])RosterContinuity[key]=()=>true;
  RosterContinuity.improve=async(x,r)=>r;RosterRebuild.improve=async(x,r)=>r;RosterRebuild.boundaryCost=()=>0;
  for(const obj of [RosterWeekend,RosterWeekendLegacy]){
   const evaluate=obj.evaluate;obj.evaluate=(...args)=>({...evaluate(...args),score:[0,0,0,0,0,0]});
   obj.workCost=()=>0;obj.restCost=()=>0;obj.notWorseLimit=()=>true;obj.improve=async(x,r)=>r;
  }
  const wr=RosterWeekend.report;RosterWeekend.report=(...args)=>({...wr(...args),score:[0,0,0,0,0,0],limitExceeded:false});
  `;
 }
 if(arm==='test2'){
  // Prefer N vacancies first, then reserve known recovery / between-block rest.
  replace("(sh==='N'?-0.4:0)","(sh==='N'?-1000:0)");
  replace('    const nightGuide=RosterNightBalance.prepare(input),weekendGuide=RosterWeekend.context(input,m);',
   '    let reservedNightRest=false;\n    const nightGuide=RosterNightBalance.prepare(input),weekendGuide=RosterWeekend.context(input,m);');
  replace('      const {d,sh,candidates,seniorNeed}=chosen;',`      if(chosen.sh!=='N'&&!reservedNightRest){
        reservedNightRest=true;
        input.staff.forEach((s,i)=>{
          if(s.isDispatch||s.isNightOnly||s.isPregnant||TrainingRules.any(input,s))return;
          const starts=[],ends=[];for(let d=0;d<days;d++)if(m[i][d]==='N'){if(m[i][d-1]!=='N')starts.push(d);if(m[i][d+1]!=='N')ends.push(d);}
          const rest=d=>{if(d<0||d>=days||m[i][d]!==null||!mutable(i,d)||fixed(input,s,d).length||s.reqShiftsMap?.[input.dates[d].date]||!canAssign(input,m,i,d,'OFF'))return false;m[i][d]='OFF';rowVersion[i]++;colVersion[d]++;return true;};
          for(const end of ends)if(m[i][end-1]==='N'){rest(end+1);rest(end+2);}
          for(let b=0;b+1<starts.length;b++)if(starts[b+1]-ends[b]>6){
            const center=Math.round((ends[b]+starts[b+1])/2),ds=Array.from({length:starts[b+1]-ends[b]-1},(_,k)=>ends[b]+k+1).sort((a,b)=>Math.abs(a-center)-Math.abs(b-center));
            if(count(m[i],'OFF')<restTarget(input,s,m[i]).pure)for(const d of ds)if(rest(d))break;
          }
        });continue;
      }
      const {d,sh,candidates,seniorNeed}=chosen;`);
  replace('cost:count(a,sh)*2+a.filter(isWork).length*0.4',"cost:count(a,sh)*2+a.filter(isWork).length*0.4+(sh==='N'?experimentalNightCost(input,s,a,d,seed):0)");
  script+=`
  function experimentalNightCost(x,s,row,d,seed){
   if(s.isNightOnly||s.isDispatch||s.isPregnant)return 0;
   if(row[d-1]==='N'||row[d+1]==='N')return -2;
   const prev=s.previousShifts||[],h=prev.length,starts=[];
   for(let k=0;k<h;k++)if(prev[k]==='N'&&prev[k-1]!=='N')starts.push(k-h);
   row.forEach((sh,k)=>{if(sh==='N'&&row[k-1]!=='N')starts.push(k);});
   const phase=starts.length?starts.at(-1):((x.staff.indexOf(s)*5+seed)%14+14)%14;
   const circular=t=>Math.min(((t%14)+14)%14,14-((t%14)+14)%14);
   const near=starts.length?Math.min(...starts.map(k=>Math.abs(Math.abs(d-k)-14))):circular(d-phase);
   return Math.min(near,14)*1.5;
  }
  `;
  // Same target band in initial generation and subsequent optimization.
  replace('score[4]+=Math.max(0,a-1)**2;score[5]+=gap*gap;', 'score[4]+=Math.max(0,a-2)**2;score[5]+=Math.max(0,a-2)**2;');
  replace('else {score[2]+=Math.max(0,a-1)**2;score[3]+=gap*gap;}', 'else {score[2]+=Math.max(0,a-2)**2;score[3]+=Math.max(0,a-2)**2;}');
  replace('rolling.map(p=>Math.abs(p.gap)-1)', 'rolling.map(p=>Math.abs(p.gap)-2)');
  replace('rolling.reduce((n,p)=>n+Math.max(0,Math.abs(p.gap)-1)**2,0)','rolling.reduce((n,p)=>n+Math.max(0,Math.abs(p.gap)-2)**2,0)');
  replace('rolling.reduce((n,p)=>n+p.gap*p.gap,0)','rolling.reduce((n,p)=>n+Math.max(0,Math.abs(p.gap)-2)**2,0)');
  replace('current+=next*next-gap*gap;', 'current+=Math.max(0,Math.abs(next)-2)**2-Math.max(0,Math.abs(gap)-2)**2;');
  replace('else past+=Math.max(0,Math.abs(next)-1)**2-Math.max(0,Math.abs(gap)-1)**2;', 'else past+=Math.max(0,Math.abs(next)-2)**2-Math.max(0,Math.abs(gap)-2)**2;');
  replace("metrics['weekend|' + scope + '|peak'] = Math.max(0, ...gaps.map(Math.abs));", "metrics['weekend|' + scope + '|peak'] = Math.max(0, ...gaps.map(v=>Math.abs(v)-2));");
  replace("metrics['weekend|' + scope + '|squares'] = gaps.reduce((n, v) => n + v * v, 0);", "metrics['weekend|' + scope + '|squares'] = gaps.reduce((n, v) => n + Math.max(0,Math.abs(v)-2)**2, 0);");
  replace('Math.abs(p.gap) - 1)),','Math.abs(p.gap) - (p.metric===\'weekend\'?2:1))),');
  replace('Math.max(0, Math.abs(p.gap) - 1) ** 2','Math.max(0, Math.abs(p.gap) - (p.metric===\'weekend\'?2:1)) ** 2');
  replace('pairs.reduce((n, p) => n + p.gap ** 2, 0)',"pairs.reduce((n, p) => n + (p.metric==='weekend'?Math.max(0,Math.abs(p.gap)-2)**2:p.gap**2), 0)");
 }
 const ctx={console,setTimeout,clearTimeout,Date,performance,structuredClone};vm.createContext(ctx);
 vm.runInContext(script+'\nglobalThis.api={E:RosterEngine,S:RosterSurplus,F:RosterFairness,P:RosterPreferences,W:RosterWorkload,T:RosterTraining,C:RosterComposition,A:RosterDetails,R:RosterRest,B:RosterSpread,Annual:RosterAnnual,Weekend:RosterWeekend,Search:RosterSearch,Night:RosterNightBalance,Recovery:RosterRecovery,Future:RosterFuture,Rebuild:RosterRebuild,Continuity:RosterContinuity};',ctx);
 return ctx.api;
}
module.exports={runtime};
