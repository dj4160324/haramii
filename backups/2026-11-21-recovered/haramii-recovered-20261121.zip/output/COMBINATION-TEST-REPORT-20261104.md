# 세 가지 방법의 조합 비교 — 2026-11-04

① 우선순위, ② 전체 CP-SAT 최적화, ③ 반복 부담 분산.
정식 HTML 및 GitHub 백업에는 통합하지 않은 별도 실험이다.

## 1차 선별: 같은 기존 28일 표 3개를 각각 재조정

반복 직원 수는 세 사례의 직원·기간 합계다. 같은 사람의 장기 누적 횟수가 아니다.
대조군도 원표에 같은 보호조건으로 교환 탐색을 추가한 결과다. 백업 프로그램의 새 생성 결과는 아니다.
각 조합·사례당 탐색 20초. CP-SAT 4 worker, 교환 탐색 단일 스레드. 아래 시간은 모델 작성·감사를 포함한다.

| 조합 | 사례 수 | 6일 근무 독립 구간 합계 | 2회 이상 직원·기간 | 겹치는 창 | 현재/누적 주말 최대차 | 시간(초) |
|---|---:|---:|---:|---:|---:|---:|
| 공통 교환 탐색(대조군) | 3 | 92 | 33 | 216 | 2/3 | 51.4 |
| ① 우선순위 | 3 | 89 | 33 | 214 | 2/3 | 46.9 |
| ③ 반복 분산 | 3 | 92 | 32 | 216 | 2/3 | 51.2 |
| ①+③ | 3 | 89 | 32 | 214 | 2/3 | 51.6 |
| ② 전체 최적화 | 3 | 69 | 18 | 165 | 2/3 | 65.3 |
| ①+② | 3 | 49 | 8 | 137 | 2/3 | 67.1 |
| ②+③ | 3 | 64 | 14 | 163 | 2/3 | 64.3 |
| ①+②+③ | 3 | 51 | 10 | 158 | 2/3 | 66.6 |

확인 시험 진입 후보: ② 전체 최적화, ①+②, ②+③, ①+②+③

## 해석 범위

- 필수조건·공평성·N 집중·7일 모두 근무 및 개인 월별 횟수·날짜별 가동/선임 인원·확정 입력을 독립 검증했다.
- 세 선별 사례는 모두 기준 N 집중이 0이므로 N 개선 효과가 아니라 재발 방지를 확인한 것이다.
- ①은 기존 주말 최대차와 필수조건을 유지하면서 편차 제곱합 비악화만 보조 목표로 내린 구현이다.
- ②도 개인 월별 총량과 날짜별 인원 구성을 보존하는 범위의 28일 동시 재편성이다. 모든 제약 없는 자유 최적화가 아니다.
- 짧은 탐색으로 얻은 실행 결과이며 최적성·불가능성 또는 조합 간 보편적 우열을 증명하지 않는다.
- 초기 pilot 및 중단한 screen 폴더는 모델 준비 자료다. 비교 결과에는 screen-v2만 사용한다.
- 모델은 고정 기준표 3개를 모두 표현했고, CP-SAT의 독립 구간/반복 직원 집계가 기존 검증기와 일치했다.

HTML SHA-256: `f82cc6a01ac9102f6097237ac1841e5f2a5f6d6aef23671dd22238a464e9145b`

## 다른 seed·추가 사례 확인

기존 5회차와 선별에 없던 3회차, seed 20261105, 조합당 30초.

| 조합 | 독립 구간 | 반복 직원·기간 | 주말 편차 제곱합 |
|---|---:|---:|---:|
| 공통 교환 탐색(대조군) | 61 | 23 | 598 |
| ①+② | 32 | 2 | 974 |
| ②+③ | 47 | 12 | 590 |

장기 시험에는 휴식 개선이 큰 ①+②만 선택했다. 주말 최대차는 유지하지만 세부 분포 악화라는 손익이 있다.
1차 세 사례에서 현재 주말 OFF가 2일 차이인 비교 가능한 직원 쌍은 19→72쌍으로 늘었다.
②+③은 주말 편차 제곱합도 보호하는 대안이다. 이번 장기 시험의 대상은 아니다.

## ①+② 새 연속 생성

현재 상태: 7/7회. 각 표를 해당 실험의 실제 이력으로 연결했다.
12→24→48회로 초안 탐색을 확대하며, 기준을 통과한 초안에 40초 최적화를 적용한다.
아래 전/후는 같은 회차에서 최적화 직전 초안과 최적화 후 결과의 비교다. 별도 장기 대조군은 아니다.

| 회차 | 기간 | 독립 구간 전→후 | 반복 직원 전→후 | 주말 현재/누적 차이 |
|---|---|---:|---:|---:|
| 1 | 2026-08-03~2026-08-30 | 4→1 | 0→0 | 2/None |
| 2 | 2026-08-31~2026-09-27 | 24→13 | 7→1 | 2/2 |
| 3 | 2026-09-28~2026-10-25 | 28→16 | 11→3 | 2/1 |
| 4 | 2026-10-26~2026-11-22 | 18→8 | 2→2 | 2/2 |
| 5 | 2026-11-23~2026-12-20 | 32→18 | 11→2 | 2/2 |
| 6 | 2026-12-21~2027-01-17 | 23→11 | 4→0 | 2/3 |
| 7 | 2027-01-18~2027-02-14 | 15→7 | 4→0 | 2/2 |

독립 장기 감사 상태: complete (7회).

```json
{
  "repeatedStaffPeriods": 8,
  "sumPeriodEpisodes": 74,
  "wholeSpanEpisodes": 74,
  "maxPersonalEpisodes": 8,
  "rolling28Max": 3,
  "maxConsecutiveWork": 5,
  "maxWorkInSeven": 6,
  "checkedBoundaries": 6
}
```

기간별 비중첩 구간 합계와 전체 날짜를 연결한 비중첩 구간 합계는 경계 중복 때문에 다를 수 있다.
최종 회차 이후의 미입력 미래 근무는 추정하지 않는다. 알려진 다음 회차가 있는 경계만 검증한다.
마지막 회차의 다음 기간 회복휴무 확인 알림: 2건. 이는 확인된 규칙 위반이 아니라 아직 입력되지 않은 다음 근무표에서 확인할 항목이다.

이전 recovery.1 연속 시험과는 생성 예산과 이력이 달라 직접적인 효과 대조로 사용하지 않는다.
교육 이력 행·임신 보호 행 등은 이번 모델에서 보수적으로 고정했다. isNewbie/precId 표시를 기준으로 교육 종료 후에도 해당 행을 고정한 제한이 있다. 이는 프로그램의 필수조건이 아니며, 남은 구간이 구조적으로 불가능하다는 뜻은 아니다.

## 완료 요약

```json
{
  "selected": "110",
  "shortComparisons": 30,
  "longPeriods": 7,
  "days": 196,
  "beforeOptimizer": {
    "episodes": 144,
    "repeated": 39
  },
  "afterOptimizer": {
    "episodes": 74,
    "repeated": 8
  },
  "longAudit": {
    "repeatedStaffPeriods": 8,
    "sumPeriodEpisodes": 74,
    "wholeSpanEpisodes": 74,
    "maxPersonalEpisodes": 8,
    "rolling28Max": 3,
    "maxConsecutiveWork": 5,
    "maxWorkInSeven": 6,
    "checkedBoundaries": 6
  },
  "maxCurrentWeekendGap": 2,
  "maxRollingWeekendGap": 3,
  "lastPeriodPendingRecoveryWarnings": 2,
  "frozenRowEpisodes": 16,
  "frozenRowRepeatedStaffPeriods": 4,
  "applicationUnchanged": true,
  "htmlSHA256": "f82cc6a01ac9102f6097237ac1841e5f2a5f6d6aef23671dd22238a464e9145b",
  "caveats": [
    "No simultaneous long-term control. Before/after is the optimizer stage within the same new chain.",
    "P preserves maximum weekend gaps but allows squared disparity to worsen.",
    "Model conservatively freezes isNewbie/precId rows even after training ends.",
    "Python CP-SAT experiment; not integrated into the standalone HTML."
  ]
}
```
