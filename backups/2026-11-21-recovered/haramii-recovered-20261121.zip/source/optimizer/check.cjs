const fs=require('fs'),assert=require('node:assert/strict'),path=require('path');
const {adopt,optimize,prepare}=require('./index.cjs');
const root=path.resolve(__dirname,'../..');
const read=p=>JSON.parse(fs.readFileSync(path.join(root,p)));
(async()=>{
 let count=0;
 for(const n of [5,2,6]){
  const input=read(`validation/combination-screen-20261104/screen-v2/case-${n}-010-seed-20261104.json`).input;
  const r=read(`validation/recovery-v2/cases/case-${n}.json`).result;
  const solved=read(`validation/combination-screen-20261104/screen-v2/case-${n}-010-seed-20261104-solver.json`);
  const frozen=JSON.stringify(input),out=adopt(input,r,solved);
  assert.equal(out.wholeOptimization.policy,'method-2-only');assert.equal(out.wholeOptimization.status,'improved');
  assert(out.wholeOptimization.after.episodes<out.wholeOptimization.before.episodes);
  assert(out.wholeOptimization.after.weekendSquares<=out.wholeOptimization.before.weekendSquares);
  assert.equal(JSON.stringify(input),frozen);count++;
  const noAnswer=adopt(input,r,{status:'UNKNOWN',solutions:[]});assert.deepEqual(noAnswer.matrix,r.matrix);count++;
  const malformed=adopt(input,r,{solutions:[{matrix:[]} ]});assert.deepEqual(malformed.matrix,r.matrix);assert.equal(malformed.wholeOptimization.rejected,1);count++;
  const kept=JSON.parse(frozen);kept.surplusPlan.decision='KEEP';assert.equal(adopt(kept,r,solved).wholeOptimization.reason,'protected-result');count++;
  if(n===5){const missing=await optimize(input,r,{python:'/nonexistent/haramii-python',seconds:1});assert.deepEqual(missing.matrix,r.matrix);assert.equal(missing.wholeOptimization.reason,'solver-unavailable');count++;}
 }
 console.log('PASS approved method 2 engine:',count,'checks; historic candidates, weekend protection, KEEP, empty/malformed result and solver failure.');
})().catch(e=>{console.error(e.stack);process.exit(1)});
