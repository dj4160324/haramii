// Approved method 2. Experimental priority/distribution modes are not enabled here.
const fs=require('fs'),os=require('os'),path=require('path'),{spawn}=require('child_process');
const {domains}=require('./runtime.cjs');
const a=domains(),core=require('../src/whole-optimizer-core.js')(a),FLAGS=Object.freeze({P:false,C:false});
function eligible(x,r){
 if(!x||!r?.matrix||x.dates?.length!==28)return 'only-28-day-rosters';
 if(x.actualRecording||x.surplusPlan?.decision==='KEEP')return 'protected-result';
 const own=(x.surplusHistory?.periods||[]).find(p=>p.start===x.dates[0].iso&&p.end===x.dates.at(-1).iso);
 if(own?.status==='actual')return 'actual-period';
 const q=a.Recovery.current(x,r.matrix);
 if(q.issues.some(v=>v.level==='error')||q.fair.breaches.length||q.weekend.currentGap>2)return 'resolve-existing-errors';
 return null;
}
function fallback(r,reason){return {...r,wholeOptimization:{version:1,method:'CP-SAT',policy:'method-2-only',status:'not-applied',reason}};}
function adopt(x,r,solved){
 const reason=eligible(x,r);if(reason)return fallback(r,reason);
 const base=a.Recovery.current(x,r.matrix);let matrix=r.matrix,q=base,rank=core.score(base,FLAGS),accepted=0,rejected=0;
 for(const sol of solved?.solutions||[]){
  const m=sol.matrix;
  if(!Array.isArray(m)||m.length!==x.staff.length||m.some(row=>!Array.isArray(row)||row.length!==x.dates.length||row.some(sh=>typeof sh!=='string'))){rejected++;continue;}
  let check;try{check=core.audit(x,r.matrix,m,FLAGS,base);}catch{rejected++;continue;}
  if(!check.ok){rejected++;continue;}
  accepted++;const next=core.score(check.q,FLAGS);
  if(a.Recovery.cmp(next,rank)<0){matrix=m;q=check.q;rank=next;}
 }
 const result=a.B.checked(x,a.Recovery.result(x,r,matrix,q));
 return {...result,wholeOptimization:{version:1,method:'CP-SAT',policy:'method-2-only',
  status:matrix===r.matrix?'unchanged':'improved',solverStatus:solved?.status||'UNKNOWN',accepted,rejected,
  before:core.brief(x,r.matrix,base),after:core.brief(x,matrix,q),seconds:solved?.seconds??null}};
}
async function optimize(x,r,{python=process.env.ROSTER_OPTIMIZER_PYTHON||'python3',seconds=40,seed=20261110}={}){
 const reason=eligible(x,r);if(reason)return fallback(r,reason);
 if(!Number.isFinite(seconds)||seconds<1||seconds>120||!Number.isInteger(seed))throw Error('Invalid optimization budget or seed');
 const frozen=JSON.stringify(x),tmp=fs.mkdtempSync(path.join(os.tmpdir(),'haramii-opt-'));
 try{
  const input=path.join(tmp,'input.json'),output=path.join(tmp,'output.json');
  fs.writeFileSync(input,JSON.stringify(core.prepare(x,r.matrix)));
  await new Promise((resolve,reject)=>{
   const child=spawn(python,[path.join(__dirname,'solve.py'),input,output,'0','0',String(seconds),String(seed)],{stdio:['ignore','ignore','ignore']});
   const timer=setTimeout(()=>{child.kill('SIGTERM');reject(Error('solver-timeout'));},(seconds+45)*1000);
   child.once('error',()=>{clearTimeout(timer);reject(Error('solver-unavailable'));});
   child.once('close',code=>{clearTimeout(timer);code===0?resolve():reject(Error('solver-failed'));});
  });
  if(JSON.stringify(x)!==frozen)throw Error('input-mutated');
  return adopt(x,r,JSON.parse(fs.readFileSync(output,'utf8')));
 }catch(error){return fallback(r,error.message);}
 finally{fs.rmSync(tmp,{recursive:true,force:true});}
}
module.exports={optimize,adopt,prepare:core.prepare,eligible};
