"""Mandatory seven-day work prohibition, independent of optional streak limits."""
def apply(source, root):
    s = source
    def replace(old, new, count=1):
        nonlocal s
        if s.count(old) != count:
            raise RuntimeError(f'Mandatory work anchor count {s.count(old)}: {old[:100]}')
        s = s.replace(old, new)
    replace('    let wc=0,nc=0,oc=0;', '''    // Mandatory for all saved-input versions; unknown dates break observation.
    let mandatoryRun=0;
    [...hist,...a,...TrainingRules.nextShifts(input,s)].forEach((sh,j)=>{
      mandatoryRun=isWork(sh)?mandatoryRun+1:0;
      const at=j-hist.length;
      if(mandatoryRun>=7&&at>=0&&at-6<a.length)out.push({code:'WORK_SEVEN',d:Math.min(at,a.length-1),message:'7일 연속 근무 금지: 해당 7일 구간에 휴식일이 필요합니다.'});
    });
    let wc=0,nc=0,oc=0;''')
    replace('Math.max(r.maxWork||0,r.maxNightStreak||0,r.maxOff||0,2)',
            'Math.max(r.maxWork||0,r.maxNightStreak||0,r.maxOff||0,6)', 2)
    replace("WORK_STREAK:'연속근무 상한 초과'", "WORK_SEVEN:'7일 연속 근무 금지',WORK_STREAK:'연속근무 상한 초과'")
    replace("['OFF_STREAK','WORK_STREAK','NIGHT_STREAK']", "['OFF_STREAK','WORK_STREAK','WORK_SEVEN','NIGHT_STREAK']", 2)
    replace("      if(x.code==='NOE')out.action=",
            "      if(x.code==='WORK_SEVEN')out.action='직전·다음 기간의 알려진 근무를 포함해 7일 연속 근무를 해소해 주세요. 연속근무 상한 설정과 무관한 필수조건입니다.';\n      if(x.code==='NOE')out.action=")
    replace('  function savePlan(history,input,result,now=new Date().toISOString()){',
            "  function savePlan(history,input,result,now=new Date().toISOString()){\n    if(RosterEngine.validate(input,result.matrix).some(x=>x.code==='WORK_SEVEN'))throw Error('7일 연속 근무를 해소한 뒤 근무표를 확정해 주세요.');")
    replace('id="maxConsecutiveWorkDays" class="inline-input-num" value="5" min="2" max="10">일까지 근무합니다.</span>',
            'id="maxConsecutiveWorkDays" class="inline-input-num" value="5" min="2" max="6">일까지 근무합니다. 이 설정과 무관하게 7일 연속 근무는 항상 금지합니다.</span>')
    return s
