"""Package reproducible local evidence; do not include upload helpers or secrets."""
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
WORK = Path('/workspace/scratch/cdeeeeb13a5e/continuity-v0122')
OUT = Path('/workspace/scratch/cdeeeeb13a5e/output')
BASE = Path('/workspace/scratch/cdeeeeb13a5e/continuous-v0121')
TEMPLATES = Path('/workspace/scratch/cdeeeeb13a5e/rest-upgrade-v0121/archive')
files = {}


def add(path, name):
    if path.is_file():
        files[name] = path


for folder in ['chain-release', 'chain-final', 'chain-v2', 'cases-v1', 'cases-v2', 'cases-v3', 'cases-v4', 'cases-v5', 'cases-v6', 'generated-v3', 'final-frozen', 'release-frozen', 'experimental-priority']:
    for p in (WORK / folder).glob('*.json'):
        add(p, ('final' if folder == 'chain-release' else 'development/' + folder) + '/' + p.name)
for p in WORK.glob('*.log'):
    if 'upload' not in p.name:
        add(p, 'logs/' + p.name)
for name in ['month3-trace.json', 'month3-trace-v7.json', 'balance-guard-case.json', 'experimental-broad.json']:
    add(WORK / name, 'development/traces/' + name)
for name in ['release-build.html', 'final-build.html', 'chain-v2-build.html', 'baseline-v0121.html']:
    add(WORK / name, 'builds/' + name)
for p in WORK.glob('experimental-*.html'):
    add(p, 'development/experimental-builds/' + p.name)
for p in TEMPLATES.glob('*-period-*-input.json'):
    add(p, 'fixtures/templates/' + p.name)
for p in BASE.glob('*-period-*-final.json'):
    if '-attempt-' not in p.name:
        add(p, 'fixtures/v0121-finals/' + p.name)
for p in BASE.glob('*-report.json'):
    add(p, 'fixtures/v0121-finals/' + p.name)
for name in ['base-v0120.html', 'rest-balance.js', 'continuity.js']:
    add(ROOT / 'src' / name, 'source/src/' + name)
for name in ['build.py', 'rest_balance_patch.py', 'continuity_patch.py', 'report_continuity.py', 'package_continuity.py']:
    add(ROOT / 'scripts' / name, 'source/scripts/' + name)
for name in ['helpers.cjs', 'ui-harness.cjs', 'dom-nodes.json', 'continuity.cjs', 'continuity-audit.cjs', 'continuity-cases.cjs', 'continuity-generation.cjs', 'continuity-trace.cjs', 'continuous-v0121.cjs', 'continuous-v0121-audit.cjs', 'policy.cjs', 'rest-policy.cjs', 'night-transition.cjs', 'rest-balance-ui.cjs']:
    add(ROOT / 'tests' / name, 'source/tests/' + name)
add(ROOT / 'tests/fixtures/continuity-balance.json', 'source/tests/fixtures/continuity-balance.json')
add(ROOT / 'tests/fixtures/continuity-weekend.json', 'source/tests/fixtures/continuity-weekend.json')
add(ROOT / 'README.md', 'source/README.md')
add(OUT / '근무표_주말OFF_N집중_개선검증_v0.12.2_20261031.md', 'report.md')
manifest = {
    'release': 'v0.12.2',
    'data': 'synthetic staff; no actual workplace data',
    'baseline': 'v0.12.1 chained validation; source build retained',
    'reproduction': 'cd source && python3 scripts/build.py; CONTINUITY_POLICY=1 node tests/continuous-v0121.cjs ../fixtures/templates <output> month (or 4week); node tests/continuity-audit.cjs <output>',
    'note': 'Time-budgeted search can select different schedules on different runtimes. Development failures and interrupted draft logs are retained; only final adopted periods form final actual history.',
    'files': [{'path': name, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for name, p in sorted(files.items())],
}
target = OUT / '근무표_주말OFF_N집중_검증자료_v0.12.2_20261031.zip'
with ZipFile(target, 'w', ZIP_DEFLATED, compresslevel=8) as z:
    z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    for name, p in sorted(files.items()):
        z.write(p, name)
print(json.dumps({'file': str(target), 'entries': len(files) + 1, 'bytes': target.stat().st_size}, ensure_ascii=False))
