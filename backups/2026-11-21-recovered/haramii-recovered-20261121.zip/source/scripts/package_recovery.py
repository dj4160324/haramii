"""Create a self-contained, checksummed recovery delivery after validation."""
from pathlib import Path
import json, hashlib, shutil, zipfile, platform, subprocess
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

root = Path(__file__).resolve().parents[2]
out = root / 'output'
out.mkdir(exist_ok=True)
chain = root / 'validation/recovery-chain'
q = json.loads((chain / 'quality-audit.json').read_text())
if q['status'] != 'complete':
    raise RuntimeError('Complete the seven-period audit before packaging the final report.')
html = root / 'source/dist/index.html'
digest = hashlib.sha256(html.read_bytes()).hexdigest()
if digest != q['htmlSHA256']:
    raise RuntimeError('The audited build changed.')
shutil.copyfile(html, out / 'haramii-v0.12.4-recovery.1.html')

wb = Workbook()
sheet = wb.active
sheet.title = '기간별 평가'
sheet.append(['회차', '시작', '종료', '배분 모드', '0회 직원', '1회 직원', '2회 이상 직원', '구간 합계', 'N집중', '현재 주말차', '누적 주말차', '필수위반', '공평성위반'])
for p in q['periods']:
    sheet.append([p['period'],p['start'],p['end'],p['mode'],*p['distribution'][:2],p['repeated'],p['episodes'],p['nightConcentration'],p['weekend'],p['rollingWeekend'],p['hardErrors'],p['fairnessBreaches']])
staff = wb.create_sheet('직원별 부담')
staff.append(['직원', *[f'{n}회차' for n in range(1,8)], '회차 합산', '전체 비중첩 횟수', '2회 이상 기간 수', '연속28일 최대', '최대 연속근무', '7일 중 최대근무'])
for r in q['staff']:
    staff.append([r['name'],*r['periods'],r['sumPeriodCounts'],r['total'],r['repeatedPeriods'],r['rolling28Max'],r['maxConsecutiveWork'],r['maxWorkInSeven']])
for p in q['periods']:
    v=json.loads((chain/f"4week-period-{p['period']}-final.json").read_text())
    s=wb.create_sheet(f"근무표{p['period']}")
    s.append(['직원',*[d['iso'] for d in v['input']['dates']]])
    for person,row in zip(v['input']['staff'],v['result']['matrix']): s.append([person['name'],*row])
notes=wb.create_sheet('해석 및 한계')
for line in [
    'v0.12.4-recovery.1: 유실된 원본과 동일한 코드/성능의 복원을 의미하지 않음.',
    '22명 가상 직원, 4주 7회 = 196일. 채택된 표 그대로 시험용 실제 이력에 반영.',
    '6일 근무 반복은 겹치지 않는 7일 구간. 겹치는 창을 각각 반복으로 세지 않음.',
    '기간별 횟수 합계와 전체 기간의 비중첩 횟수는 경계 중복 때문에 다를 수 있음.',
    '연속 28일: 해당 기간 안에 끝나는 7일 창을 대상으로 비중첩 횟수를 계산.',
    '7일 모두 근무 여부와 최대 연속근무는 비교군 제외 없이 전 직원 확인.',
    'N 집중 지표의 N 전담 등 기존 제외 조건은 유지.',
    '최종 기간 뒤 회복은 다음 근무표가 생기면 추가 확인 필요.',
    '월 1회 부담 분산안 및 유실된 전체 표 CP-SAT 최적화 실험은 이 빌드에 포함하지 않음.',
    '소수 고정 입력/탐색 seed의 모의시험으로 모든 현장 조건의 성능을 보장하지 않음.'
]: notes.append([line])
for s in wb:
    s.freeze_panes='B2'
    s.auto_filter.ref=s.dimensions
    for cell in s[1]: cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='24476A')
    for col in s.columns:
        s.column_dimensions[col[0].column_letter].width=min(52,max(12,max(len(str(c.value or '')) for c in col)+2))
    for row in s:
        for c in row: c.alignment=Alignment(vertical='center')
wb.save(out/'recovery-seven-periods.xlsx')

lines=['# 복구판 7회 연속 생성 검증','',
       '**원본 v0.12.4의 재현 결과가 아니라, 재구현한 복구판의 새로운 시험 결과입니다.**','',
       f"기간: {q['start']} ~ {q['end']} ({q['days']}일), 가상 직원 {len(q['staff'])}명.",'',
       '| 회차 | 0회 | 1회 | 2회 이상 | 독립 구간 합계 | 주말 차이 현재/누적 |',
       '|---|---:|---:|---:|---:|---|']
for p in q['periods']:
    lines.append(f"| {p['period']} | {p['distribution'][0]} | {p['distribution'][1]} | {p['repeated']} | {p['episodes']} | {p['weekend']} / {p['rollingWeekend'] if p['rollingWeekend'] is not None else '이력 없음'} |")
lines += ['',f"전 기간 필수조건 위반 {sum(p['hardErrors'] for p in q['periods'])}건, 공평성 한도 위반 {sum(p['fairnessBreaches'] for p in q['periods'])}건, N 집중 지표 {sum(p['nightConcentration'] for p in q['periods'])}.",
          f"모든 직원의 7일 중 최대 근무 {q['totals']['maxWorkInSeven']}일, 최대 연속근무 {q['totals']['maxConsecutiveWork']}일. 확인된 기간 경계 {q['totals']['checkedBoundaries']}개.",
          f"직원별 전체 기간 비중첩 횟수 최대 {q['totals']['maxPersonalEpisodes']}회, 전체 비중첩 구간 {q['totals']['wholeSpanEpisodes']}회. 기간별 구간 합계는 {q['totals']['sumPeriodEpisodes']}회.",
          f"연속 28일의 개인 최대 횟수는 {q['totals']['rolling28Max']}회. 따라서 월 1회 이내 분산 목표의 해결을 주장하지 않습니다.",
          '', '## 직원별 횟수', '', '| 직원 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 전체 비중첩 |', '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for r in q['staff']: lines.append('| '+r['name']+' | '+' | '.join(map(str,r['periods']))+' | '+str(r['total'])+' |')
pending=q['periods'][-1]['boundary']['pending']
attempts=json.loads((chain/'4week-attempts.json').read_text())
rejected=[v for v in attempts if not v['pass']]
lines += ['', f"채택한 7개 표를 얻기까지 총 {len(attempts)}개 시도를 실행했고, {len(rejected)}개 초안은 기준 미충족으로 제외했다."]
for v in rejected:
    lines.append(f"- {v['period']}회차 시도 {v['attempt']}: 현재 주말 OFF 차이 {v['final']['weekendGap']}일, 필수조건 {len(v['final']['errors'])}건, 공평성 한도 {len(v['final']['fairness'])}건, N 집중 직원 {v['final']['nightDensity']}명.")
lines += ['', '## 해석', '',
          '반복 횟수는 서로 겹치지 않는 7일 구간이다. 회차 경계에서 같은 부담을 두 회차가 각각 세는 경우가 있어, 회차별 합산과 전체 기간의 비중첩 집계는 다를 수 있다.',
          '최종 기간 뒤 근무는 미정이다. 마지막 기간의 회복 확인 알림은 다음 표와 연결해 검증해야 한다.',
          f'마지막 기간의 N_RECOVERY_PENDING 알림: {len(pending)}건.',
          '확정되지 않았던 우선순위 완화, CP-SAT 전체 표 실험, 월 1회 분산 실험은 복구판의 기본 규칙에 혼합하지 않았다.',
          '대화의 일부 번호별 제안 원문과 원래 소스가 없어 기능 및 성능의 완전한 동일성은 검증할 수 없다. 상세 범위는 CONVERSATION-RECOVERY.md에 기록했다.',
          '', '## 재실행', '', '```bash', 'cd source', 'python3 scripts/build.py', 'node tests/recovery-balance.cjs',
          'node tests/recovery-chain.cjs ../fixtures/templates ../validation/new-chain 4week',
          'node tests/recovery-chain-audit.cjs ../validation/new-chain', '```', '',
          '중단 후 같은 출력 폴더로 다시 실행하면 마지막 채택 기간 다음부터 이어간다. 새 시험에는 새 출력 폴더를 사용한다.',
          '', 'HTML SHA-256: `'+digest+'`']
(out/'RECOVERY-REPORT.md').write_text('\n'.join(lines)+'\n')

fixtures=root/'fixtures/templates'
fixtures.mkdir(parents=True,exist_ok=True)
if not list(fixtures.glob('*.json')):
    for p in Path('/workspace/recovery/v0.12.2/fixtures/templates').glob('*.json'): shutil.copyfile(p,fixtures/p.name)
if not (fixtures/'4week-period-1-input.json').exists():
    raise RuntimeError('Missing reproduction fixtures.')
environment={'python':platform.python_version(),'node':subprocess.check_output(['node','--version'],text=True).strip(),
             'version':'v0.12.4-recovery.1','htmlSHA256':digest,'date':'2026-11-03',
             'note':'Dependencies: browser for standalone HTML; Node and Python stdlib for build/tests; openpyxl for workbook.'}
(root/'ENVIRONMENT.json').write_text(json.dumps(environment,ensure_ascii=False,indent=2)+'\n')
paths=[p for p in root.rglob('*') if p.is_file() and not set(p.relative_to(root).parts).intersection({'output','__pycache__','.git'})]
paths += [out/'RECOVERY-REPORT.md',out/'recovery-seven-periods.xlsx',out/'haramii-v0.12.4-recovery.1.html']
manifest={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}
zip_path=out/'haramii-v0.12.4-recovery.1-backup.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in paths: z.write(p,p.relative_to(root))
    z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(zip_path) as z:
    for name,record in manifest.items():
        if hashlib.sha256(z.read(name)).hexdigest()!=record['sha256']: raise RuntimeError('Archive mismatch: '+name)
print(json.dumps({'files':len(paths),'zipBytes':zip_path.stat().st_size,'htmlSHA256':digest,'zipSHA256':hashlib.sha256(zip_path.read_bytes()).hexdigest()}))
