"""Package the clarified recovery without relabelling the v1 chain as v2."""
from pathlib import Path
import hashlib, json, platform, shutil, subprocess, zipfile

root = Path(__file__).resolve().parents[2]
out = root / 'output'
data = root / 'validation/recovery-v2'
version = 'v0.12.4-recovery.2'
out.mkdir(exist_ok=True)
html = root / 'source/dist/index.html'
digest = hashlib.sha256(html.read_bytes()).hexdigest()
assert hashlib.sha256((root/'index.html').read_bytes()).hexdigest() == digest
cases = json.loads((data/'cases/summary.json').read_text())
assert len(cases) == 7
generation = json.loads((data/'generation.json').read_text())['report']
assert not generation['hard'] and not generation['fair'] and generation['night'] == 0 and generation['weekend'] <= 2
logs = '\n'.join((data/n).read_text() for n in ['unit.log','regression.log'])
tests = sum(line.startswith('PASS ') for line in logs.splitlines())
assert tests == 43
totals = {k:{t:sum(p[t][k] for p in cases) for t in ['before','after']} for k in ['episodes','repeated','windows']}
assert all(p['after']['hard']==0 and p['after']['fair']==0 and p['after']['night']==0 for p in cases)
summary = {'version':version,'htmlSHA256':digest,'unitAndRegressionChecks':tests,'storedCaseCount':len(cases),
           'storedCaseTotals':totals,'freshGeneration':{'staff':12,'days':14,'attempts':8,'hardErrors':0,'fairnessBreaches':0,
             'nightConcentration':generation['night'],'weekendGap':generation['weekend'],'episodes':generation['episodes']},
           'newSevenPeriodChainRun':False,
           'caseScope':'Independently readjusted v1 adopted rosters; histories were not carried into a newly generated chain.'}
(data/'verification-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
report = ['# 사용자 정리에 따른 복구 보완 — '+version,'',
          '원본 v0.12.4의 동일 복원이 아니라, 사용자가 확인한 적용 방법을 바탕으로 보완한 복구판이다.',
          '', '## 반영한 구분', '',
          '- 목표: N 4회/7일 집중 없애기, 6일 이상/7일 근무 없애기, 주말 OFF 차이 줄이기.',
          '- 적용 방법: 여러 직원·날짜 공동 재배치와 큰 부담부터 점진 개선 → 누적 기록 만료 보조 평가 → D/E/OFF 공동 재배치·경계 휴식 우선·보강 영향 진단.',
          '- 이후 시험: N→휴식→주말 우선순위, 28일 전체 제약 최적화(CP-SAT 등), 같은 직원의 편성당 2회 이상 몰림 방지. 기본 정책에 섞지 않았다.',
          '', '## 이번 코드 보완', '',
          '- 전체 최댓값이 같아도 큰 부담 일부를 줄이는 개선을 허용한다. 1회 남은 구간도 0회를 향해 탐색한다.',
          '- 문제 날짜에 대해 1~3명의 D/E/OFF를 함께 재배치한다. 개인의 월별 횟수·최소인원·기존 선임 기준·확정조건은 유지한다.',
          '- 알려진 직전 근무로부터 시작 구간의 휴식 필요를 계산하고 D/E 배정 우선도에 반영한다. N 배치 정책이나 미입력 이력은 변경하지 않는다.',
          '- 보강 하한만 제외하면 나머지 보호 검사를 통과하는 개선 후보를 진단한다. 실제 채택에서는 보강 하한을 낮추지 않는다.',
          '', '## 확인 결과', '', f'- 기능·회귀 검사 {tests}개 통과.',
          '- 새 12명·14일 생성: 필수조건·공평성 한도·N 집중 위반 0, 주말 OFF 차이 2일, 6일 근무 구간 0.',
          '- 기존 7개 표의 독립 재조정 검사에서는 아래와 같이 변했다. 새 7회 연속 생성 결과가 아니다.',
          '', '| 회차 | 반복 직원 전→후 | 독립 구간 전→후 | 겹치는 창 전→후 |', '|---|---:|---:|---:|']
for c in cases:
    a,b=c['before'],c['after']
    report.append(f"| {c['n']} | {a['repeated']} → {b['repeated']} | {a['episodes']} → {b['episodes']} | {a['windows']} → {b['windows']} |")
report += ['', f"합계: 반복 직원·기간 {totals['repeated']['before']}→{totals['repeated']['after']}, 독립 구간 {totals['episodes']['before']}→{totals['episodes']['after']}, 겹치는 창 {totals['windows']['before']}→{totals['windows']['after']}.",
           '', '개선 폭은 작다. 이전 최적화 성능 회복이나 세 목표의 완전한 해결을 주장하지 않는다. 기존 recovery.1의 연속 시험 원자료와 ZIP은 그대로 보존했다.',
           '경계 휴식은 배정 우선도이며 새 강제 고정 조건이 아니다. 보강 진단은 제한된 후보에 대한 결과이고 전체 해 공간의 최적성·불가능성 증명이 아니다.',
           '', '## 재실행', '', '```bash','bash build.sh','node source/tests/recovery-restoration.cjs',
           'node source/tests/recovery-balance.cjs',
           'node source/tests/recovery-v2-cases.cjs validation/recovery-chain validation/new-v2-cases',
           'node source/tests/recovery-v2-generation.cjs validation/new-v2-generation','```','',
           '전체 복구 기준: CONVERSATION-RECOVERY.md. 후속 시험: NEXT-EXPERIMENT.md.', '', 'HTML SHA-256: `'+digest+'`']
(out/'RECOVERY-REPORT-v2.md').write_text('\n'.join(report)+'\n')
shutil.copyfile(html,out/('haramii-'+version+'.html'))
(root/'ENVIRONMENT.json').write_text(json.dumps({'version':version,'htmlSHA256':digest,'python':platform.python_version(),
 'node':subprocess.check_output(['node','--version'],text=True).strip(),'previousChainVersion':'v0.12.4-recovery.1',
 'previousChainHTMLSHA256':'b8ac112345841e7e2ad9a7aeae9e1874f5d3218cdc550f65dddf68deb5244b04'},indent=2)+'\n')
files=[p for p in root.rglob('*') if p.is_file() and not set(p.relative_to(root).parts).intersection({'.git','output','__pycache__'}) and p.suffix not in {'.pyc','.tmp'}]
files += [out/'RECOVERY-REPORT-v2.md',out/('haramii-'+version+'.html')]
manifest={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
backup=out/('haramii-'+version+'-backup.zip')
with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(root))
    z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(backup) as z:
    assert all(hashlib.sha256(z.read(n)).hexdigest()==r['sha256'] for n,r in manifest.items())
oldzip=out/'haramii-v0.12.4-recovery.1-backup.zip'
with zipfile.ZipFile(oldzip) as z:
    old=json.loads(z.read('MANIFEST.json'))
    for name,record in old.items():
        if name.startswith('validation/recovery-chain/'):
            assert hashlib.sha256((root/name).read_bytes()).hexdigest()==record['sha256'],'v1 chain altered: '+name
checks=[hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt']
(out/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n')
print(json.dumps({'version':version,'tests':tests,'totals':totals,'zipBytes':backup.stat().st_size,'htmlSHA256':digest,'previousChainUnchanged':True}))
