"""Build the human-readable report from completed, chained test evidence."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORK = Path('/workspace/scratch/cdeeeeb13a5e/continuity-v0122')
OUT = Path('/workspace/scratch/cdeeeeb13a5e/output')
CHAIN = WORK / 'chain-release'
BASE = Path('/workspace/scratch/cdeeeeb13a5e/continuous-v0121')


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def peak(rows, field):
    return max((r['final'][field] or 0) for r in rows)


def total(rows, field):
    return sum(r['final'][field] for r in rows)


def main():
    reports = {k: read(CHAIN / (k + '-report.json')) for k in ['month', '4week']}
    assert all(v['status'] == 'complete' for v in reports.values())
    assert [len(reports[k]['reports']) for k in ['month', '4week']] == [6, 7]
    baseline = {k: read(BASE / (k + '-report.json')) for k in reports}
    audit = read(CHAIN / 'independent-audit.json')
    continuity = read(CHAIN / 'continuity-independent-audit.json')
    assert audit['periods'] == continuity['periods'] == 13
    assert sum(c['nightStaff'] for c in continuity['checks']) == sum(total(v['reports'], 'nightDensity') for v in reports.values())
    rows = [r for v in reports.values() for r in v['reports']]
    assert all(not r['final']['errors'] and not r['final']['fairness'] and not r['final']['independent'] for r in rows)
    html = OUT / '병동_근무표_편성검토_v0.12.2.html'
    html.write_bytes((ROOT / 'dist/index.html').read_bytes())
    assert digest(html) == digest(WORK / 'release-build.html')
    lines = [
        '# 누적 주말 OFF·7일 N 집중 개선 — v0.12.2',
        '',
        '검증일: 2026-10-31 · 가상 직원 22명 · 월별 6회 / 4주 7회',
        '',
        '## 결과',
        '',
        '| 비교 항목 | 이전 v0.12.1 | 수정 v0.12.2 |',
        '|---|---:|---:|',
    ]
    for k, label in [('month', '월별'), ('4week', '4주')]:
        before, after = baseline[k]['reports'], reports[k]['reports']
        lines.append(f'| {label} 누적 주말 OFF 최대 차이 | {peak(before,"weekendRollingGap")}일 | {peak(after,"weekendRollingGap")}일 |')
        lines.append(f'| {label} 마지막 편성의 누적 주말 OFF 차이 | {before[-1]["final"]["weekendRollingGap"]}일 | {after[-1]["final"]["weekendRollingGap"]}일 |')
    old_n = sum(total(v['reports'], 'nightDensity') for v in baseline.values())
    new_n = sum(total(v['reports'], 'nightDensity') for v in reports.values())
    old_weekend_alerts = sum((r['final']['weekendRollingGap'] or 0) >= 3 for v in baseline.values() for r in v['reports'])
    new_weekend_alerts = sum((r['final']['weekendRollingGap'] or 0) >= 3 for r in rows)
    lines.extend([
        f'| 누적 주말 OFF 차이가 3일 이상인 편성기간 | {old_weekend_alerts}회 | {new_weekend_alerts}회 |',
        f'| 7일 안에 N 4회 이상인 직원·기간 | {old_n}건 | {new_n}건 |',
        f'| 이번 편성 주말 OFF 최대 차이 | 2일 | {peak(rows,"weekendGap")}일 |',
        '| 채택한 표의 필수조건·기존 공평성 한도 위반 | 0건 | 0건 |',
        '',
        '**누적 주말 OFF 1일 이내는 여전히 목표이며, 이 표의 최대 차이가 1일을 넘는 기간에서는 목표가 미달한 것이다.** 남은 편차를 불가능한 조건이라고 단정하지 않는다. 이번 편성 최대 2일, 누적 목표 미달 안내, 반복 밀집 안내의 기존 정책은 유지한다.',
        '',
        '이 수치는 같은 직원 구성과 운영 시나리오로 각각 새 실제 이력을 이어 만든 연속 시험의 비교다. 과거 이력이 두 버전에서 달라지므로 모든 달의 입력이 동일한 엄밀한 A/B 시험은 아니다. 모든 병원별 조건에서 N 집중이나 누적 편차가 없어짐을 보장하는 결과도 아니다.',
        '',
        '## 확인한 원인과 수정',
        '',
        '1. 누적 주말 OFF를 평가하더라도 이후 휴식 조정과 자동연차 재구성이 이를 되돌릴 수 있었다. 해당 단계에 누적 균형 보호 검사를 넣고, 초안의 D/E뿐 아니라 N 배치에도 과거 주말 부족을 반영했다. 누적 편차 중 가장 큰 목표 미달부터 줄인다.',
        '2. 자동연차 재구성의 일부 경로는 분산 검사를 생략했다. 이 경로에도 알려진 직전·다음 근무를 연결한 N 집중 검사를 적용한다.',
        '3. 중간판의 월별 3회차를 추적하니 초안의 N 집중은 0이었으나 근무횟수 조정이 집중을 만들었다. 해당 입력에서 공평성 한도 미충족 3개를 0으로 줄이면서 N 집중도 0으로 유지하도록 보호 검사를 보완했다. 같은 입력의 전체 생성도 N 집중 0을 확인했다.',
        '4. N과 회복일을 묶어 이동하고, 두 명 또는 세 명의 기간 전체 순서를 함께 탐색한다. 한 사람의 N 집중을 다른 사람에게 넘기는 변경은 받지 않는다. 날짜 미지정 자동 보건휴가는 본인의 일수를 유지하며 평일 안에서 이동할 수 있다. 지정 날짜와 주말 보건휴가는 보호해 주말 비교에서 날짜를 빼는 방식으로 수치를 낮추지 않는다.',
        '5. 내부 교환 판정이 겹치는 7일 창의 개수까지 늘지 못하게 해 주말 보정을 막았다. 최종 주말 조정은 새 반복 2회나 기존 반복 증가, 새로운 7일 모두 근무를 막는다. 같은 밀집 구간을 옮겨 겹친 창 수가 달라진 것만으로 유효한 주말 보정을 거절하지 않는다. 첫 밀집 구간까지 일괄 금지하지는 않는다. 가능한 한 직원의 평일·주말 날짜 이동부터 확인한다.',
        '',
        '최소인원·선임 최소, 확정조건과 반영된 신청, 기본 OFF, 자동연차 동의·본인·달·일수, 확보한 보강, 기존 N/OFF 공평성 한도, 선임 집중 기준을 재검사한다. 과거 실제 근무는 바꾸지 않는다. 새로운 설정이나 확인 클릭은 추가하지 않았다.',
        '',
        '## 연속 운영 시험',
        '',
        '- 월별: 2026-08-01~2027-01-31, 6회·184일. 4주: 2026-08-03~2027-02-14, 7회·196일.',
        '- 가상 직원 22명, 초기 선임 8명, D/E/N 최소 4/3/2명. 교육·신규 독립, 임신 단계 변화·출산휴가, 육아휴직·복귀, 파견, N 전담을 포함한다. 고정 OFF는 한 요일만 지정하고 다음 편성마다 하루씩 순환한다.',
        '- 지정 연차·신청·보건휴가·이번 기간 자동연차 동의 및 과거 동의를 포함한다. 연차 우선 → D/E 보강 → D/E/N 보강을 반복한다.',
        '- 매회 초안 48개를 탐색한다. 자동배분 후 시험 관리자가 연차를 한 차수 추가하고 현재 배치를 유지한다. 계획 확정 → 실제 근무 확인 → 가능한 자동연차 1일 취소·근무 변경 → 재확인 → 저장·복원 → 다음 편성으로 진행한다.',
        '- 실제 근무로 확인된 직전 14일과 누적 이력을 이어받는다. 계획만 확정한 표는 실제 이력에 넣지 않고, 재확인에 따른 중복과 과거 기록 변경도 검사한다.',
        '- 연속 검증 중 발견한 문제를 수정한 뒤 첫 3기간의 모의 확정 실제 이력은 보존하고, 4회차부터 마지막까지 최종판으로 다시 생성했다. 첫 3기간은 N 집중 0, 누적 주말 차이 최대 2일이며 최종판으로 집계·검증도 다시 했다. 따라서 최종 코드만으로 처음부터 13개 표를 모두 새로 생성한 시험과는 구분한다. 수정 전 후반 표와 중단한 초안도 원자료에 남겼다.',
        '',
        '다음 수치는 관리자 배분 후 확정한 계획 기준이다. 누적은 당월을 포함한 달력상 3개월의 실제 기록과 현재 계획을 합산한다. 4주 편성이 두 달에 걸치면 각 달의 구간을 모두 보고 그중 최대 차이를 쓴다. 고정 주말 OFF를 포함하며, 비교 가능한 공통 날짜만 센다. N 전담은 일반 직원의 7일 N 집중 비교에서 제외한다.',
        '',
        '| 방식·회차 | 이번 주말 OFF 차이 | 누적 주말 OFF 차이 | 누적 N 차이 | N 집중 직원 | 밀집 반복 2회 이상 직원 | 생성 시도 |',
        '|---|---:|---:|---:|---:|---:|---:|',
    ])
    for k, label in [('month', '월별'), ('4week', '4주')]:
        for r in reports[k]['reports']:
            q = r['final']
            lines.append(f'| {label} {r["index"]} | {q["weekendGap"]}일 | {str(q["weekendRollingGap"])+"일" if q["weekendRollingGap"] is not None else "—"} | {str(q["rollingN"])+"회" if q["rollingN"] is not None else "—"} | {q["nightDensity"]}명 | {q["repeated"]}명 | {r["attempt"]}회 |')
    lines.extend(['', '## 기존 N 집중 입력 세 건의 별도 확인', '',
                  '이전 v0.12.1의 과거 실제 이력을 고정했다. 새 N 배치·근무횟수 보호 검사로 후보를 재생성한 뒤 최종 주말 조정을 적용했다. 아래는 해당 후보를 검증한 결과이며, 위 연속 시험과는 별개의 시험이다.', '',
                  '| 기존 입력 | 누적 주말 차이 이전 → 조정 후 | 7일 N 4회 이상 |', '|---|---:|---|'])
    for key, kind, index, label in [('month-6', 'month', 6, '월별 6회차'), ('4week-2', '4week', 2, '4주 2회차'), ('4week-7', '4week', 7, '4주 7회차')]:
        case = read(WORK / 'release-frozen' / (key + '.json'))
        after = case['report']['after']
        old = baseline[kind]['reports'][index - 1]['final']['weekendRollingGap']
        assert not [e for e in case['result']['issues'] if e['level'] == 'error']
        assert not case['result']['fairness']['breaches']
        lines.append(f'| {label} | {old}일 → {after["rolling"]}일 | 있음 → {"없음" if after["night"] == 0 else "잔여 있음"} |')
    lines.extend(['', '세 후보의 현재 편성 주말 최대 2일, 필수조건 및 기존 공평성 한도를 유지했다. 최종 주말 조정에서 기존 밀집 반복을 늘리거나 새 2회 반복을 만들지 않았다. 다만 같은 구간의 겹친 창 개수는 달라질 수 있으며, 이것을 별도 반복으로 세지 않는다.'])
    lines.extend(['', '## 휴식분산과 남은 한계', ''])
    for k, label in [('month', '월별'), ('4week', '4주')]:
        lines.append(f'- {label}의 겹치지 않는 7일 밀집 구간이 2회 이상인 직원·기간 합계: 이전 {total(baseline[k]["reports"],"repeated")}건 → 수정 {total(reports[k]["reports"],"repeated")}건.')
    lines.extend([
        '- 위 합계는 동일 직원이 여러 기간에 반복 포함될 수 있다. 같은 직원 수가 아니며, 실제 피로 감소를 측정한 값도 아니다. 기간별로 다른 품질 항목의 개선과 악화가 함께 있을 수 있다.',
        '- 휴식은 OFF·연차·보건휴가·병가 등 비출근일로 판단한다. 겹치지 않는 7일 구간에서 근무 6일 이상이 2회 이상이어도 합의대로 안내만 하고 생성·확정은 막지 않는다.',
        '- 시간 제한이 있는 탐색이다. 최종 안내가 남으면 실제 제약과 날짜를 확인해야 하며, 탐색 실패를 불가능성 증명으로 표시하지 않는다.',
        '- 재생성 빈도를 개선하는 정책은 이번에 변경하지 않았다. 필요한 재시도와 실패 표는 숨기지 않고 원자료에 기록했다.',
        '- 기존 확정표·실제 근무를 자동으로 고치지 않는다. 기존 저장자료를 불러온 뒤 새로 생성하면 새 배정 기준을 적용한다. 모바일 테스트 환경은 만들지 않았다.',
        '',
        '## 검증 증거',
        '',
        f'- 최종 채택 13개 표. 완료된 생성 시도 {sum(len(v["attempts"]) for v in reports.values())}회 중 확정 한도 미충족 {sum(not t["pass"] for v in reports.values() for t in v["attempts"])}회. 필수 위반이 있는 표는 채택하지 않았다.',
        f'- 누적 N 원시 합산 대조 {sum(c["checkedN"] for c in audit["checks"])}개 직원·달력구간, 주말 날짜 대조 {sum(c["weekendRows"] for c in audit["checks"])}개 직원·기간, 휴식구간 대조 {sum(c["restRows"] for c in audit["checks"])}개 직원·기간.',
        f'- 별도 날짜·셀 재집계: 이번 기간 비교 {sum(c["currentPairs"] for c in continuity["checks"])}개, 누적 주말 비교 {sum(c["rollingPairs"] for c in continuity["checks"])}개. 모든 직원의 알려진 기간 경계까지 연결해 7일 N 창도 대조했다.',
        '- 새 핵심 회귀 9개 묶음, 기존 배분 정책 18개, 휴무 규칙 7개, 야간 전환 8개, 반복 안내·확정·저장/복원 화면 동작 검사를 통과했다. 실제 브라우저의 모바일 화면 시험은 수행하지 않았다.',
        '- 중간판 연속 시험과 기존 실패표 재조정의 미해결 결과도 보존한다. 기존 완성표에서 일부 날짜만 바꾸는 시험은 전체 재생성과 다르며, 과거 실제 이력이나 모든 완성표를 완벽히 복구했다고 주장하지 않는다.',
        '',
        f'검증·배포 HTML SHA-256: `{digest(html)}`',
        '',
        '원자료 ZIP에는 최종·중간 연속 결과, 각 시도 입력과 단계별 표, 실제 기록, 실행 로그, 독립 집계, 문제 원인 추적 및 재현용 소스·테스트를 포함한다.',
    ])
    OUT.mkdir(exist_ok=True)
    report = OUT / '근무표_주말OFF_N집중_개선검증_v0.12.2_20261031.md'
    report.write_text('\n'.join(lines) + '\n')
    print(json.dumps({'html': str(html), 'report': str(report), 'hash': digest(html), 'nightCases': new_n}, ensure_ascii=False))


if __name__ == '__main__':
    main()
