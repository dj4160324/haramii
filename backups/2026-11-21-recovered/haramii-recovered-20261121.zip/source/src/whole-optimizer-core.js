(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory;else root.createRosterWholeCore=factory;})(globalThis,function(a){
'use strict';
const SH=['D','E','N','OFF'],WORK=['D','E','N','MID'],REST=['OFF','LEAVE','M-LEAVE','SICK','MATERNITY','PARENTAL'];
const cmp=(u,v)=>a.Recovery.cmp(u,v),sum=v=>v.reduce((n,t)=>n+t,0);
function brief(x,m,q=a.Recovery.current(x,m)){const counts=q.spread.rows.map(r=>r.episodes.length);
 let seven=0;for(let i=0;i<m.length;i++){const prev=x.staff[i].previousShifts||[],next=a.T.nextShifts(x,x.staff[i])||[],seq=[...prev,...m[i],...next],h=prev.length;
 for(let d=0;d<Math.min(m[i].length+next.length,m[i].length+6);d++){const b=seq.slice(Math.max(0,h+d-6),h+d+1);seven+=Number(b.length===7&&b.every(v=>WORK.includes(v)));}}
 return {hard:q.issues.filter(e=>e.level==='error').length,fair:q.fair.breaches.length,night:q.spread.score[0],seven,
 episodes:sum(counts),repeated:counts.filter(n=>n>=2).length,max:Math.max(...counts),distribution:[0,1,2,3,4].map(k=>counts.filter(n=>n===k).length),counts,
 windows:sum(q.spread.rows.map(r=>r.restWindows.length)),weekend:q.weekend.currentGap,rollingWeekend:q.weekend.rollingGap,
 weekendSquares:sum(q.weekend.pairs.map(p=>p.gap*p.gap))};}
function score(q,flags){const c=q.spread.rows.map(r=>r.episodes.length),total=sum(c),windows=sum(q.spread.rows.map(r=>r.restWindows.length));
 const burden=flags.C?[c.filter(n=>n>=2).length,Math.max(...c),total,windows]:[...c.slice().sort((a,b)=>b-a),windows];
 // P allows weekend distribution to move within the same existing peak limits;
 // without P each weekend scope's current squared imbalance also stays protected.
 return [q.spread.score[0],...burden,sum(q.weekend.pairs.map(p=>p.gap*p.gap))];}
function mutable(x,m,i,d){const s=x.staff[i];return a.Recovery.mutable(x,m,i,d)&&
 !x.staff.some(t=>t.precId===s.id)&&!s.isNewbie&&
 !a.B.protectedRequest?.(x,s,d,m[i][d])&&
 !(s.reqShiftsMap?.[x.dates[d].date]&&a.P.matches(s.reqShiftsMap[x.dates[d].date],m[i][d]));}
function prepare(x,m){const q=a.Recovery.current(x,m),n=m.length,days=x.dates.length;
 const domains=m.map((r,i)=>r.map((v,d)=>mutable(x,m,i,d)?SH.filter(sh=>!x.staff[i].isNightOnly||!['D','E'].includes(sh)):[v]));
 const rows=x.staff.map((s,i)=>{const prev=s.previousShifts||[],next=a.T.nextShifts(x,s)||[],all=[...prev,...m[i],...next];
 return {previous:prev,next,nightOnly:!!s.isNightOnly,dispatch:!!s.isDispatch,
 offlike:all.map((v,k)=>a.R.countsAsOff(x,s,k-prev.length,v)),manualLeave:all.map((v,k)=>v==='LEAVE'&&!a.R.automatic(x,s,k-prev.length,v)),
 excluded:x.dates.map((_,d)=>s.isDispatch||Array.from({length:Math.min(7,d+1)},(_,k)=>d-k).every(k=>a.T.trainee(x,s,k)||['MATERNITY','PARENTAL'].includes(m[i][k]))),
 episodes:q.spread.rows[i].episodes.length,nightRun:q.spread.rows[i].nightRun,singles:q.spread.rows[i].singleNights+q.spread.rows[i].edgeSingles};});
 const daily=x.dates.map((_,d)=>SH.slice(0,3).map(sh=>{
 const ids=x.staff.flatMap((s,i)=>a.E.eligible(s,x.rules,x,d)&&a.E.covers(x,s,d,sh)?[i]:[]);
 const senior=x.staff.flatMap((s,i)=>s.isSenior&&!s.isDispatch&&a.E.covers(x,s,d,sh)?[i]:[]);
 return {shift:sh,ids,count:ids.filter(i=>m[i][d]===sh).length,senior,seniorCount:senior.filter(i=>m[i][d]===sh).length};}));
 const plan=a.Weekend.prepare(x,m),pairs=a.Weekend.evaluate(m,plan).pairs;
 const groups=[];for(const type of ['ordinary','night'])for(const w of [{scope:'current'},...plan.windows.map(w=>({...w,scope:'rolling'}))]){
 const rr=plan.rows.filter(r=>r.kind===type&&r.days.length&&(w.scope==='current'||[...r.past.keys()].some(d=>d>=w.start&&d<=w.end)));
 if(!rr.some(r=>r.senior)||!rr.some(r=>!r.senior))continue;
 const points=rr.map(r=>new Map([...r.past,...r.days.map(d=>[x.dates[d].iso,Number(['OFF','LEAVE'].includes(m[r.i][d]))])].filter(([d])=>w.scope==='current'?d>=x.dates[0].iso:d>=w.start&&d<=w.end)));
 const common=[...points[0].keys()].filter(d=>points.every(p=>p.has(d))).sort();if(!common.length||w.scope==='rolling'&&!common.some(d=>d<x.dates[0].iso))continue;
 const ns=rr.filter(r=>r.senior).length,nr=rr.length-ns,terms=[];let constant=0,base=0;
 rr.forEach((r,i)=>common.forEach(date=>{const c=r.senior?nr:-ns,d=x.dates.findIndex(t=>t.iso===date);base+=c*points[i].get(date);if(d<0)constant+=c*points[i].get(date);else terms.push({i:r.i,d,c});}));groups.push({constant,terms,limit:Math.abs(base)});
 }
 return {matrix:m,domains,rows,daily,pairs,groups,rules:x.rules,months:x.dates.map(t=>t.iso.slice(0,7)),days,n,
 baseline:brief(x,m),scopeLimits:Object.fromEntries([...new Set(pairs.map(p=>p.scope+'|'+(p.month||'')))].map(k=>{
 const pp=pairs.filter(p=>p.scope+'|'+(p.month||'')===k);return [k,{peak:Math.max(...pp.map(p=>Math.abs(p.gap))),squares:sum(pp.map(p=>p.gap*p.gap))}];}))};}
function audit(x,before,m,flags,base=a.Recovery.current(x,before)){
 const errors=[],q=a.Recovery.current(x,m),out=brief(x,m,q);if(out.hard||out.fair||out.seven)errors.push('hard/fair/seven');
 if(q.spread.score[0]>base.spread.score[0])errors.push('night');
 if(a.Recovery.floorBlockers(x,m).length)errors.push('floor');
 for(let i=0;i<m.length;i++){
 for(let d=0;d<m[i].length;d++)if(m[i][d]!==before[i][d]&&!mutable(x,before,i,d))errors.push('immutable');
 if(!a.B.preservesRequests(x,before,m,[i]))errors.push('request');
 for(const month of new Set(x.dates.map(t=>t.iso.slice(0,7))))for(const sh of SH){const count=r=>r.reduce((n,v,d)=>n+Number(v===sh&&x.dates[d].iso.startsWith(month)),0);if(count(m[i])!==count(before[i]))errors.push('monthly-count');}
 const b=base.spread.rows[i],r=q.spread.rows[i];
 if(r.episodes.length>(flags.C?Math.max(1,b.episodes.length):b.episodes.length))errors.push('individual-episodes');
 if(r.score[0]>b.score[0]||r.singleNights+r.edgeSingles>b.singleNights+b.edgeSingles||r.nightRun>Math.max(2,b.nightRun))errors.push('night-block');
 }
 if(q.spread.independentWindows>base.spread.independentWindows)errors.push('total-episodes');
 if(q.fair.counts.some((c,i)=>c.protectedOff!==base.fair.counts[i].protectedOff))errors.push('protected-off');
 for(const k of Object.keys(base.metrics)){
 // P changes only secondary weekend variance, not the existing peak limits.
 if(flags.P&&k.startsWith('weekend|')&&k.endsWith('|squares'))continue;
 if(q.metrics[k]>base.metrics[k]+1e-8)errors.push('metric:'+k);
 }
 if(q.weekend.currentGap>2)errors.push('weekend-limit');
 // Preserve the exact coverage profile in this first screening experiment.
 for(let d=0;d<x.dates.length;d++)for(const sh of SH.slice(0,3)){
 for(const senior of [false,true]){const count=matrix=>x.staff.reduce((n,s,i)=>n+Number(matrix[i][d]===sh&&(senior?s.isSenior&&!s.isDispatch:a.E.eligible(s,x.rules,x,d))&&a.E.covers(x,s,d,sh)),0);if(count(m)!==count(before))errors.push('daily-count');}}
 return {ok:!errors.length,errors:[...new Set(errors)],brief:out,q};}
return {prepare,audit,score,brief,mutable};
});
