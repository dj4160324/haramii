// Independent date/cell recount of the two v0.12.2 quality targets.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {domains}=require('./helpers.cjs'),a=domains(),dir=process.argv[2],checks=[];
const identity=s=>s.personId||String(s.id),isWeekend=iso=>[0,6].includes(new Date(iso+'T00:00:00Z').getUTCDay());
const kind=(x,s)=>s.isDispatch||s.isPregnant||a.T.fairnessReason(x,s)?'':s.isNightOnly?'night':'ordinary';
function points(x,m,s,grants){
 const i=x.staff.findIndex(t=>identity(t)===identity(s)),out=new Map();if(i<0)return out;
 x.dates.forEach((t,d)=>{const sh=m[i][d],auto=sh==='LEAVE'&&grants.some(g=>g.key===identity(s)&&g.date===t.iso);
  if(isWeekend(t.iso)&&!a.A.familyAt(x,s,d)&&(['D','E','N','OFF'].includes(sh)||auto))out.set(t.iso,Number(sh==='OFF'||auto));
 });return out;
}
for(const family of ['month','4week'])for(let n=1;n<=(family==='month'?6:7);n++){
 const file=path.join(dir,family+'-period-'+n+'-final.json');if(!fs.existsSync(file))continue;
 const saved=JSON.parse(fs.readFileSync(file)),x=saved.input,m=saved.result.matrix,w=a.Weekend.report(x,m),b=a.B.report(x,m);
 const all=x.staff.map(s=>{const past=new Map(),current=points(x,m,s,x.surplusPlan?.grants||[]),type=kind(x,s);
  for(const p of x.surplusHistory?.periods||[]){if(p.status!=='actual'||p.end>=x.dates[0].iso)continue;const old=p.input.staff.find(t=>identity(t)===identity(s));if(!old||!type||kind(p.input,old)!==type)continue;
   for(const point of points(p.input,p.actual,old,p.actualGrants||[]))past.set(...point);
  }return {past,current};
 });
 let rollingPairs=0,currentPairs=0;
 for(const pair of w.pairs){const left=all[pair.a],right=all[pair.b],lc=new Map([...pair.scope==='rolling'?left.past:[],...left.current]),rc=new Map([...pair.scope==='rolling'?right.past:[],...right.current]);
  const windowStart=pair.scope==='rolling'?new Date(Date.UTC(Number(pair.month.slice(0,4)),Number(pair.month.slice(5))-3,1)).toISOString().slice(0,10):x.dates[0].iso;
  const windowEnd=pair.scope==='rolling'?x.dates.filter(t=>t.iso.slice(0,7)<=pair.month).at(-1).iso:x.dates.at(-1).iso;
  const dates=[...lc.keys()].filter(date=>date>=windowStart&&date<=windowEnd&&rc.has(date));
  assert.equal(pair.own,dates.reduce((sum,date)=>sum+lc.get(date),0),'left weekend cells');assert.equal(pair.other,dates.reduce((sum,date)=>sum+rc.get(date),0),'right weekend cells');
  assert.equal(pair.gap,dates.reduce((sum,date)=>sum+lc.get(date)-rc.get(date),0),'weekend cumulative gap');
  if(pair.scope==='rolling')rollingPairs++;else currentPairs++;
 }
 const nightCases=[];
 for(const row of b.rows){const s=x.staff[row.i],prev=s.previousShifts||[],future=a.T.nextShifts(x,s),get=d=>d<0?prev[prev.length+d]:d>=m[row.i].length?future[d-m[row.i].length]:m[row.i][d];let severity=0;
  if(!s.isDispatch&&!s.isNightOnly)for(let from=-6;from<m[row.i].length;from++){
   const dates=Array.from({length:7},(_,j)=>from+j),active=dates.filter(d=>d>=0&&d<m[row.i].length);
   if(active.every(d=>a.T.trainee(x,s,d)||['MATERNITY','PARENTAL','DISPATCH'].includes(m[row.i][d])))continue;
   const count=dates.filter(d=>get(d)==='N').length;severity+=Math.max(0,count-3)**2;
   if(count>=4)nightCases.push({staff:identity(s),from,to:from+6,count});
  }
  assert.equal(row.score[0],severity,'independent rolling seven-day N scan');
 }
 checks.push({kind:family,period:n,currentPairs,rollingPairs,nightStaff:new Set(nightCases.map(v=>v.staff)).size,nightWindows:nightCases.length,nightCases});
}
const out={periods:checks.length,checks};fs.writeFileSync(path.join(dir,'continuity-independent-audit.json'),JSON.stringify(out,null,2));console.log(JSON.stringify(out));
