const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {domains,json}=require('./helpers.cjs'),a=domains(),source=process.argv[2],out=process.argv[3],ids=(process.argv[4]||'4week-2,month-6,4week-7').split(',');
fs.mkdirSync(out,{recursive:true});
(async()=>{const summary=[];for(const id of ids){
 const [kind,n]=id.split('-'),full=path.join(source,kind+'-period-'+n+'-final.json'),old=JSON.parse(fs.readFileSync(fs.existsSync(full)?full:path.join(source,id+'-final.json'))),x=json(old.input);x.continuityPolicy=1;delete x.surplusPlan.decision;delete x.surplusPlan.accepted;
 const frozen=json({staff:x.staff,ph:x.preferenceHistory,wh:x.workloadHistory,history:x.surplusHistory}),before=a.Continuity.quality(x,old.result.matrix);
 const r=a.B.checked(x,await a.Continuity.improve(x,old.result,{maxMs:Number(process.env.CONTINUITY_CASE_MS||25000)}),'checked');
 assert.deepEqual(json({staff:x.staff,ph:x.preferenceHistory,wh:x.workloadHistory,history:x.surplusHistory}),frozen);
 assert.equal(a.E.validate(x,r.matrix).filter(e=>e.level==='error').length,0);assert.equal(a.F.analyse(x,r.matrix).breaches.length,0);assert(a.Weekend.report(x,r.matrix).currentGap<=2);
 assert(a.B.preservesRequests(x,old.result.matrix,r.matrix,x.staff.map((_,i)=>i)));assert(a.Continuity.weekendSafe(x,old.result.matrix,r.matrix));assert(a.Continuity.nightSafe(x,old.result.matrix,r.matrix,x.staff.map((_,i)=>i)));
 const report={id,before,after:a.Continuity.quality(x,r.matrix),run:r.continuity};summary.push(report);fs.writeFileSync(path.join(out,id+'.json'),JSON.stringify({input:x,result:r,report}));fs.writeFileSync(path.join(out,'summary.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(report));
}})().catch(e=>{console.error(e.stack);process.exit(1)});
