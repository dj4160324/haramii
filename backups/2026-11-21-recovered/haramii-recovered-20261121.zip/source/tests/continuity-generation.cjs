const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {domains,json}=require('./helpers.cjs'),a=domains(),source=process.argv[2],out=process.argv[3],id=process.argv[4],attempts=Number(process.argv[5]||48),[kind,n]=id.split('-');
fs.mkdirSync(out,{recursive:true});
(async()=>{const old=JSON.parse(fs.readFileSync(path.join(source,kind+'-period-'+n+'-final.json'))),x=json(old.input);x.continuityPolicy=1;delete x.surplusPlan;delete x.weekendPlan;
 const start=Date.now();let last=start;const progress=(n,t,stage)=>{if(Date.now()-last>25000){console.log(id,stage?.phase||'drafts',n,t,Date.now()-start);last=Date.now();}};
 let r=await a.E.generate(x,{attempts,seed:old.report.seed,onProgress:progress});fs.writeFileSync(path.join(out,id+'-generated.json'),JSON.stringify({input:x,result:r,quality:a.Continuity.quality(x,r.matrix)}));
 r=await a.S.apply(x,r,{decision:'OFF',onProgress:progress});const report={id,ms:Date.now()-start,quality:a.Continuity.quality(x,r.matrix),hard:a.E.validate(x,r.matrix).filter(e=>e.level==='error'),fair:a.F.analyse(x,r.matrix).breaches,continuity:r.continuity};
 fs.writeFileSync(path.join(out,id+'-final.json'),JSON.stringify({input:x,result:r,report}));console.log(JSON.stringify(report));
})().catch(e=>{console.error(e.stack);process.exit(1)});
