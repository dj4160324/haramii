const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../dist/index.html'),'utf8');let source=html.match(/<script>([\s\S]*?)<\/script>/)[1].split('    window.koreanHolidays')[0];
const data=JSON.parse(fs.readFileSync(process.argv[2])),x=data.input||data,out=process.argv[3],seed=Number(process.argv[4]||50777),stages=[];
function replace(a,b){if(!source.includes(a))throw Error(a);source=source.replace(a,b);}
replace('pool=SearchRules.retain(pool,candidate,5);',"traceStage('draft-'+n,input,candidate);pool=SearchRules.retain(pool,candidate,5);");
replace('best=balance(input,repair(input,best),fairnessPlan);',"traceStage('before-repair-balance',input,best);best=balance(input,repair(input,best),fairnessPlan);traceStage('after-repair-balance',input,best);");
replace('best=await refine(input,pool,{seed,onProgress});',"best=await refine(input,pool,{seed,onProgress});traceStage('after-refine',input,best);");
replace("if(RosterComposition.enabled(input)){onProgress", "traceStage('before-composition',input,best);if(RosterComposition.enabled(input)){onProgress");
replace("if(typeof RosterSurplus!=='undefined'&&RosterSurplus.enabled(input))", "traceStage('before-surplus',input,best);if(typeof RosterSurplus!=='undefined'&&RosterSurplus.enabled(input))");
source+="\nfunction traceStage(stage,x,r){globalThis.record(stage,x,r,RosterSpread.report(x,r.matrix));}\nglobalThis.E=RosterEngine;globalThis.B=RosterSpread;";
const ctx={console,setTimeout,clearTimeout,Date,performance,structuredClone,record:(stage,x,r,b)=>{const item={stage,seed:r.seed,hard:r.issues.filter(e=>e.level==='error').length,fair:r.fairness.breaches.length,night:b.score[0],people:b.rows.filter(v=>v.score[0]).map(v=>v.i)};if(!stage.startsWith('draft'))item.matrix=r.matrix.map(row=>row.slice());stages.push(item);if(!stage.startsWith('draft'))console.log(JSON.stringify({...item,matrix:undefined}));}};vm.createContext(ctx);vm.runInContext(source,ctx);
(async()=>{const r=await ctx.E.generate(x,{attempts:48,seed});stages.push({stage:'generated',hard:r.issues.filter(e=>e.level==='error').length,fair:r.fairness.breaches.length,night:ctx.B.report(x,r.matrix).score[0]});fs.writeFileSync(out,JSON.stringify({input:x,result:r,stages}));console.log(stages.at(-1));})().catch(e=>{console.error(e);process.exit(1)});
