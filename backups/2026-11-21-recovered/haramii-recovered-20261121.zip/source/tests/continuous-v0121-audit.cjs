const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const {domains}=require('./helpers.cjs'),a=domains(),dir=process.argv[2],all=[];
for(const kind of ['month','4week'])for(let n=1;n<=(kind==='month'?6:7);n++){
 const file=path.join(dir,kind+'-period-'+n+'-final.json');if(!fs.existsSync(file))continue;
 const v=JSON.parse(fs.readFileSync(file)),x=v.input,m=v.result.matrix,f=a.F.analyse(x,m),w=a.Weekend.report(x,m),b=a.B.report(x,m);let checkedN=0;
 for(const window of f.rolling.windows)for(const row of window.rows){
  const s=x.staff[row.index],id=s.personId||String(s.id);let past=0,current=0;
  for(const p of x.surplusHistory.periods){if(p.status!=='actual'||p.end>=x.dates[0].iso)continue;const i=p.input.staff.findIndex(t=>(t.personId||String(t.id))===id);if(i<0)continue;
   p.input.dates.forEach((t,d)=>{if(t.iso>=window.start&&t.iso<=window.end&&p.actual[i][d]==='N')past++;});}
  x.dates.forEach((t,d)=>{if(t.iso>=window.start&&t.iso<=window.end&&m[row.index][d]==='N')current++;});
  assert.equal(row.past.N,past,kind+n+' past N '+id+'/'+window.month);assert.equal(row.current.N,current,kind+n+' current N '+id+'/'+window.month);assert.equal(row.total.N,past+current);checkedN++;
 }
 for(const row of w.rows.filter(r=>r.kind)){
  const s=x.staff[row.i],expected=x.dates.filter((t,d)=>[0,6].includes(new Date(t.iso+'T00:00:00Z').getUTCDay())&&(m[row.i][d]==='OFF'||m[row.i][d]==='LEAVE'&&x.surplusPlan.grants.some(g=>g.key===s.personId&&g.date===t.iso))).length;
  assert.equal(row.rest,expected,'weekend actual days '+kind+n+'/'+row.i);
 }
 for(const row of b.rows){
  const s=x.staff[row.i],prev=s.previousShifts||[],full=[...prev,...m[row.i]],dp=Array(x.dates.length+1).fill(0);let windows=0;
  for(let end=0;end<x.dates.length;end++){
   dp[end+1]=dp[end];if(s.isDispatch||end+prev.length<6)continue;
   const seg=full.slice(prev.length+end-6,prev.length+end+1);if(seg.length!==7||seg.includes('DISPATCH')||seg.some(v=>v==null))continue;
   if(Array.from({length:Math.min(7,end+1)},(_,j)=>end-j).every(d=>a.T.trainee(x,s,d)||['MATERNITY','PARENTAL'].includes(m[row.i][d])))continue;
   if(seg.filter(v=>['D','E','N','MID'].includes(v)).length<6)continue;
   windows++;dp[end+1]=Math.max(dp[end+1],1+dp[Math.max(0,end-6)]);
  }
  assert.equal(row.restWindows.length,windows,'rolling seven-day scan');assert.equal(row.episodes.length,dp.at(-1),'independent repetition');
 }
 all.push({kind,n,checkedN,weekendRows:w.rows.filter(r=>r.kind).length,restRows:b.rows.length,historyPeriods:x.surplusHistory.periods.length});
}
const result={hash:crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'../dist/index.html'))).digest('hex'),periods:all.length,checks:all};
fs.writeFileSync(path.join(dir,'independent-audit.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
