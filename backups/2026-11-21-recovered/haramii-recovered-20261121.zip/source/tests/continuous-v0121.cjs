// Six-month chained validation: each next period uses newly recorded actual work.
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const {domains,json}=require('./helpers.cjs'),a=domains();
const [archive,out,kind]=process.argv.slice(2),total=kind==='month'?6:7;
assert(['month','4week'].includes(kind));fs.mkdirSync(out,{recursive:true});
const read=p=>JSON.parse(fs.readFileSync(p,'utf8')),write=(p,v)=>fs.writeFileSync(path.join(out,kind+'-'+p+'.json'),JSON.stringify(v));
const hash=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const stateFile=path.join(out,kind+'-checkpoint.json');
let state=fs.existsSync(stateFile)?read(stateFile):{ledger:{version:1,periods:[]},ph:{version:1,periods:[]},wh:{version:1,periods:[]},reports:[],attempts:[]};
function audit(x,r,label){
 const errors=a.E.validate(x,r.matrix).filter(v=>v.level==='error'),fair=a.F.analyse(x,r.matrix),weekend=a.Weekend.report(x,r.matrix),spread=a.B.report(x,r.matrix,r.spread),independent=[];
 x.dates.forEach((t,d)=>{for(const sh of ['D','E','N']){const ids=x.staff.flatMap((s,i)=>r.matrix[i][d]===sh&&a.E.eligible(s,x.rules,x,d)&&a.E.covers(x,s,d,sh)?[i]:[]);if(ids.length<a.E.quota(x,d,sh))independent.push('coverage '+t.iso+'/'+sh);}});
 x.staff.forEach((s,i)=>x.dates.forEach((t,d)=>{const f=a.E.fixed(x,s,d);if(f.length&&!f.includes(r.matrix[i][d]))independent.push('fixed '+s.personId+'/'+t.iso);}));
 for(const g of x.surplusPlan?.grants||[]){const i=x.staff.findIndex(s=>a.S.identity(s)===g.key),d=x.dates.findIndex(t=>t.iso===g.date);if(i<0||d<0||r.matrix[i][d]!=='LEAVE'||!a.Annual.consent(x,x.staff[i]))independent.push('annual '+g.key+'/'+g.date);}
 for(const f of x.surplusPlan?.floors||[])if(x.staff.reduce((n,s,i)=>n+Number(r.matrix[i][f.d]===f.shift&&a.E.eligible(s,x.rules,x,f.d)&&a.E.covers(x,s,f.d,f.shift)),0)<f.floor)independent.push('floor '+f.d+'/'+f.shift);
 // Independent interval-scheduling DP checks maximum non-overlapping count.
 spread.rows.forEach(row=>{const wins=row.restWindows||[],dp=Array(x.dates.length+1).fill(0);for(let e=0;e<x.dates.length;e++){dp[e+1]=dp[e];for(const w of wins.filter(w=>w.to===e))dp[e+1]=Math.max(dp[e+1],1+dp[Math.max(0,w.from)]);}assert.equal(row.episodes.length,dp.at(-1),'non-overlap '+row.i);});
 const gaps=(groups,sh)=>Math.max(0,...groups.filter(g=>g.comparable).map(g=>g.stats[sh]?.gap||0));
 const rolling=fair.rolling.windows.filter(w=>w.recordedPast>0);
 return {label,errors,fairness:fair.breaches,independent,weekendGap:weekend.currentGap,weekendRollingGap:weekend.rollingGap,weekendGroupAlerts:weekend.groupAlerts.map(g=>({scope:g.scope,gap:g.gap,level:g.level})),weekendBounds:weekend.bounds,N:gaps(fair.groups,'N'),rollingN:rolling.length?Math.max(...rolling.map(w=>gaps(w.groups,'N'))):null,ordinaryOff:gaps(fair.groups,'OFF'),rollingOff:rolling.length?Math.max(...rolling.map(w=>gaps(w.groups,'OFF'))):null,restStaff:spread.restStaff,repeated:spread.repeatedStaff,episodes:spread.independentWindows,nightDensity:spread.rows.filter(v=>v.score[0]>0).length,annual:x.surplusPlan?.grants?.length||0,health:r.matrix.flat().filter(v=>v==='M-LEAVE').length,fallback:r.restFallback||null,spreadFinal:!!r.spread?.finalChecked};
}
const okay=q=>!q.errors.length&&!q.fairness.length&&!q.independent.length&&q.weekendGap<=2;
(async()=>{
 for(let n=state.reports.length+1;n<=total;n++){
  const template=read(path.join(archive,kind+'-period-'+n+'-input.json'));
  // Agreed operational fixture: one fixed weekday moves forward each period.
  // The old benchmark kept Sunday forever; that is not the rotating policy.
  for(const s of template.staff)if(s.offDayIndicesArray?.length===1)s.offDayIndicesArray=[(s.offDayIndicesArray[0]+n-1)%7];
  const originalSeed=(kind==='month'?48103:48714)+(n-1)*1337;
  let chosen=null;
  for(let attempt=1;attempt<=3;attempt++){
   const x=json(template);Object.assign(x,{weekendPolicy:2,nightBalancePolicy:1,restSpreadPolicy:2,automaticRestPolicy:1,preferenceHistory:json(state.ph),workloadHistory:json(state.wh),surplusHistory:json(state.ledger)});
   if(process.env.CONTINUITY_POLICY==='1')x.continuityPolicy=1;
   delete x.surplusPlan;delete x.weekendPlan;delete x.actualRecording;
   if(n>1)for(const s of x.staff){s.previousShifts=[];delete s.previousText;delete s.previousAutomaticLeaveDates;delete s.previousShiftTimes;}
   a.S.actualContext(x);
   if(n>1){const prior=state.ledger.periods.at(-1);for(const s of x.staff){const i=prior.input.staff.findIndex(v=>a.S.identity(v)===a.S.identity(s));assert.deepEqual(json(s.previousShifts),prior.actual[i].slice(-14),'new actual carryover');}}
   const immutable=hash({staff:x.staff,ph:x.preferenceHistory,wh:x.workloadHistory,ledger:x.surplusHistory}),start=Date.now(),seed=originalSeed+(attempt-1)*110000,prefix='period-'+n+'-attempt-'+attempt;
   write(prefix+'-input',x);console.log(JSON.stringify({kind,n,attempt,stage:'start',seed,start:x.dates[0].iso,end:x.dates.at(-1).iso}));
   let last=Date.now();const progress=(i,t,s)=>{if(Date.now()-last>25000){console.log(JSON.stringify({kind,n,attempt,stage:s?.phase||'working',i,t,ms:Date.now()-start}));last=Date.now();}};
   let r=await a.E.generate(x,{attempts:48,seed,onProgress:progress,maxBlockMs:8000});
   const initial=audit(x,r,'generated');write(prefix+'-generated',{input:x,result:r,audit:initial});
   r=await a.S.apply(x,r,{decision:'OFF',onProgress:progress});const manager=audit(x,r,'manager-next-annual-round');write(prefix+'-manager',{input:x,result:r,audit:manager});
   r=await a.S.apply(x,r,{decision:'KEEP',onProgress:progress});const final=audit(x,r,'keep');
   assert.equal(hash({staff:x.staff,ph:x.preferenceHistory,wh:x.workloadHistory,ledger:x.surplusHistory}),immutable,'input/history unchanged');
   const entry={period:n,attempt,seed,ms:Date.now()-start,pass:okay(final),initial,manager,final};state.attempts.push(entry);write(prefix+'-final',{input:x,result:r,audit:final});write('attempts',state.attempts);
   console.log(JSON.stringify({kind,n,attempt,stage:'final',pass:entry.pass,ms:entry.ms,hard:final.errors.length,fairness:final.fairness.length,independent:final.independent,weekend:final.weekendGap,rollingWeekend:final.weekendRollingGap,N:final.N,rollingN:final.rollingN,repeated:final.repeated}));
   if(entry.pass){chosen={x,r,entry};break;}
  }
  if(!chosen){write('checkpoint',state);write('report',{status:'blocked',blockedPeriod:n,...state});throw Error(kind+' period '+n+' did not satisfy confirmation gates in 3 attempts');}
  const {x,r,entry}=chosen,priorHashes=state.ledger.periods.map(hash),key=a.S.period(x).key,today=x.dates.at(-1).iso,now=today+'T23:00:00.000Z';
  let ledger=a.S.savePlan(state.ledger,x,r,now);assert.equal(ledger.periods.length,n);assert.equal(ledger.periods.at(-1).status,'planned');
  const beforeHistory=a.S.actualHistories(ledger,state.ph,state.wh);assert.equal(beforeHistory.workload.periods.length,n-1,'plan does not count as actual');
  ledger=a.S.confirmActual(ledger,key,r.matrix,{today,now});
  const actual=json(r.matrix);let actualChange=null;
  // Simulate one genuinely recorded automatic-leave cancellation, only where safe.
  outer:for(const g of ledger.periods.at(-1).actualGrants){const i=x.staff.findIndex(s=>a.S.identity(s)===g.key),d=x.dates.findIndex(t=>t.iso===g.date);
   for(const sh of [...new Set([g.from,'D','E'])].filter(v=>['D','E','N'].includes(v))){actual[i][d]=sh;const nx=json(x);nx.surplusPlan.grants=nx.surplusPlan.grants.filter(v=>v.key!==g.key||v.date!==g.date);
    if(!a.E.validate(nx,actual).some(v=>v.level==='error')&&!a.F.analyse(nx,actual).breaches.length&&a.Weekend.report(nx,actual).currentGap<=2){actualChange={key:g.key,date:g.date,from:'LEAVE',to:sh};break outer;}actual[i][d]='LEAVE';}
  }
  ledger=a.S.confirmActual(ledger,key,actual,{today,now});const last=ledger.periods.at(-1);
  if(actualChange)assert(!last.actualGrants.some(g=>g.key===actualChange.key&&g.date===actualChange.date),'cancelled benefit removed');
  assert.equal(last.actualGrants.length,x.surplusPlan.grants.length-(actualChange?1:0));
  const duplicate=a.S.confirmActual(ledger,key,actual,{today,now});assert.deepEqual(json(duplicate),json(ledger),'actual reconfirm idempotent');
  const histories=a.S.actualHistories(ledger,state.ph,state.wh);assert.equal(histories.workload.periods.length,n);assert.equal(histories.preferences.periods.length,n);assert(histories.workload.periods.every(p=>p.basis==='actual'));
  priorHashes.forEach((h,i)=>assert.equal(hash(ledger.periods[i]),h,'past actual immutable'));
  ledger=json(a.S.validateHistory(json(ledger)));assert.deepEqual(json(a.S.validateHistory(ledger)),ledger,'save/restore');
  const ax={...json(x),surplusPlan:{...json(x.surplusPlan),grants:json(last.actualGrants)},actualRecording:true},actualAudit=audit(ax,{...r,matrix:actual},'actual');assert(okay(actualAudit));
  const report={index:n,start:x.dates[0].iso,end:today,days:x.dates.length,mode:x.rules.surplus.mode,attempt:entry.attempt,seed:entry.seed,initial:entry.initial,final:entry.final,actual:actualAudit,actualChange,actualPeriods:n,historyHash:hash(ledger),ms:state.attempts.filter(v=>v.period===n).reduce((s,v)=>s+v.ms,0)};
  write('period-'+n+'-final',{input:x,result:r,actual,actualGrants:last.actualGrants,report});
  state={...state,ledger,ph:json(histories.preferences),wh:json(histories.workload),reports:[...state.reports,report]};write('checkpoint',state);write('report',{status:n===total?'complete':'running',kind,reports:state.reports,attempts:state.attempts});console.log(JSON.stringify({kind,n,stage:'actual-confirmed',actualPeriods:n,actualChange}));
 }
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
