const assert=require('node:assert/strict');
const {domains,fixture,result,json}=require('./helpers.cjs');
const a=domains(),{E,S}=a;
const fresh=(days=7)=>fixture({days,n:1,seniors:0,quota:{D:0,E:0,N:0},enabled:false});
const codes=(x,row)=>E.patternIssuesForSurplus(x,x.staff[0],row).filter(p=>p.code==='WORK_SEVEN');
let passed=0;
async function test(name,fn){await fn();console.log('PASS '+name);passed++;}
(async()=>{
 await test('optional streak setting cannot permit seven consecutive duties',()=>{
  for(const cap of [null,0,5,6,10]){const x=fresh();x.rules.maxWork=cap;assert(codes(x,Array(7).fill('D')).length);assert(E.validate(x,[Array(7).fill('D')]).some(p=>p.code==='WORK_SEVEN'&&p.level==='error'));}
  const x=fresh();assert(codes(x,['D','D','MID','E','E','N','N']).length);
 });
 await test('six duties and each known rest code remain allowed by this rule',()=>{
  for(const rest of ['OFF','LEAVE','M-LEAVE','SICK','MATERNITY','PARENTAL']){const x=fresh();assert.equal(codes(x,['D','D','D',rest,'D','D','D']).length,0);}
  assert.equal(codes(fresh(6),Array(6).fill('D')).length,0);
 });
 await test('both roster boundaries and a 28-day month boundary are checked',()=>{
  const x=fresh(1);x.staff[0].previousShifts=Array(6).fill('D');assert(codes(x,['D']).length);
  x.staff[0].previousShifts=['OFF'];x.staff[0].nextShifts=Array(6).fill('D');assert(codes(x,['D']).length);
  x.schema=9;assert(codes(x,['D']).length);
  const y=fixture({start:'2026-10-19',days:28,n:1,seniors:0,quota:{D:0,E:0,N:0},enabled:false});const row=Array(28).fill('OFF');row.fill('D',10,17);assert(codes(y,row).length);
 });
 await test('unknown dates are not inferred and unrelated history/future is excluded',()=>{
  const x=fresh(1);x.staff[0].previousShifts=['D','D',null,'D','D','D'];assert.equal(codes(x,['D']).length,0);
  x.staff[0].previousShifts=Array(7).fill('D');x.staff[0].nextShifts=Array(7).fill('D');assert.equal(codes(x,['OFF']).length,0);
  x.staff[0].previousShifts=[];assert(E.validate(x,[['OFF']]).some(p=>p.code==='HISTORY'));
 });
 await test('candidate placement, fixed conflict and direct confirmation reject seven',()=>{
  const x=fresh();const row=Array(6).fill('D').concat(null);assert.equal(E.canAssign(x,[row],0,6,'D'),false);
  x.staff[0].reqShiftsMap=Object.fromEntries(x.dates.map(d=>[d.date,'D']));
  x.schema=7;assert(E.preflightDetails(x).issues.some(p=>p.code==='WORK_SEVEN'));
  const r={matrix:Array(1).fill(Array(7).fill('D'))};assert.throws(()=>S.savePlan(null,x,r),/7일 연속/);
 });
 await test('manual editing blocks confirmation in the UI',()=>{
  const ui=require('./ui-harness.cjs')();const x=fresh(),m=[Array(6).fill('D').concat('OFF')];
  ui.ctx.x=json(x);ui.ctx.r=json(result(a,x,m));ui.run('lastInput=x;lastResult=r;globalStaffData=x.staff;dirty=false;renderAll()');
  ui.run('openCell(0,6)');ui.el('editShift').value='D';ui.run('applyCell();audit()');
  assert(ui.run("lastResult.issues.some(x=>x.code==='WORK_SEVEN')"));assert(ui.el('confirmScheduleBtn').disabled);
 });
 await test('actual history records the violation without rewriting the facts',async()=>{
  const x=fresh(),m=[Array(6).fill('D').concat('OFF')],r=await S.apply(x,result(a,x,m),{decision:'KEEP'});let h=S.savePlan(null,x,r);
  h=S.confirmActual(h,h.periods[0].key,[Array(7).fill('D')],{today:'2026-11-10'});
  assert(h.periods[0].actualIssues.some(p=>p.code==='WORK_SEVEN'));assert.equal(h.periods[0].actual[0].filter(s=>s==='D').length,7);
 });
 await test('two independent six-duty episodes do not block confirmation',async()=>{
  const x=fresh(14),m=[Array.from({length:14},(_,i)=>i%7===3?'OFF':'D')];
  assert.equal(E.validate(x,m).filter(p=>p.level==='error').length,0);const r=await S.apply(x,result(a,x,m),{decision:'KEEP'});assert(S.savePlan(null,x,r).periods.length===1);
 });
 console.log(JSON.stringify({passed}));
})().catch(e=>{console.error(e);process.exit(1)});
