const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {domains,json}=require('./helpers.cjs'),a=domains();
const source=process.argv[2],out=process.argv[3];fs.mkdirSync(out,{recursive:true});
const summary=[];
const brief=(x,m)=>{const q=a.Recovery.current(x,m);return {errors:q.issues.filter(e=>e.level==='error').length,
 fairness:q.fair.breaches.length,night:q.spread.score[0],repeated:q.spread.repeatedStaff,
 episodes:q.spread.independentWindows,weekend:q.weekend.currentGap,rollingWeekend:q.weekend.rollingGap,
 future:json(a.Future.evaluate(m,a.Future.prepare(x,m)).score)};};
(async()=>{
 for(const family of ['4week','month'])for(let n=1;n<=(family==='4week'?7:6);n++){
  const name=family+'-period-'+n+'-final.json',old=JSON.parse(fs.readFileSync(path.join(source,name))),x=json(old.input);
  Object.assign(x,{continuityPolicy:1,futureBalancePolicy:1,restRebuildPolicy:1});
  delete x.surplusPlan.decision;delete x.surplusPlan.accepted;
  const frozen=JSON.stringify(x),before=brief(x,old.result.matrix),prior=a.Recovery.current(x,old.result.matrix);
  const rest=await a.Rebuild.improve(x,old.result,{maxMs:1800});
  assert(a.Recovery.noWorse(prior.metrics,a.Recovery.current(x,rest.matrix).metrics));
  x.staff.forEach((s,i)=>{for(const month of new Set(x.dates.map(t=>t.iso.slice(0,7))))for(const sh of ['D','E','N','OFF']){
   const count=m=>m[i].filter((v,d)=>v===sh&&x.dates[d].iso.startsWith(month)).length;
   assert.equal(count(rest.matrix),count(old.result.matrix),'rest preserves monthly counts');
  }});
  const final=await a.Future.improve(x,rest,{maxMs:1800}),after=brief(x,final.matrix),now=a.Recovery.current(x,final.matrix);
  assert.equal(JSON.stringify(x),frozen,'input and all histories immutable');
  assert(a.Recovery.noWorse(prior.metrics,now.metrics));assert.equal(after.errors,0);assert.equal(after.fairness,0);
  assert(after.night<=before.night);assert(after.repeated<=before.repeated);assert(after.episodes<=before.episodes);
  x.staff.forEach((s,i)=>{const history=[...(s.previousShifts||[]),...final.matrix[i]];
   for(let d=0;d<final.matrix[i].length;d++){
    const end=(s.previousShifts||[]).length+d,block=history.slice(Math.max(0,end-6),end+1);
    if(block.length===7)assert(block.filter(v=>['D','E','N','MID'].includes(v)).length<7,'all employees: no seven working days');
   }
  });
  assert(a.B.preservesRequests(x,old.result.matrix,final.matrix,x.staff.map((_,i)=>i)));
  const report={family,n,before,after,rest:final.restRebuild,future:final.futureBalance};summary.push(report);
  fs.writeFileSync(path.join(out,name),JSON.stringify({input:x,result:final,report}));
  fs.writeFileSync(path.join(out,'summary.json'),JSON.stringify(summary,null,2));
  console.log(JSON.stringify({family,n,before,after,restMoves:report.rest?.moves,futureMoves:report.future?.moves}));
 }
})().catch(e=>{console.error(e.stack);process.exit(1)});
