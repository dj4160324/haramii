// Cell/date recount, independent of the optimizer's objective values.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {domains,json,html}=require('./helpers.cjs'),a=domains(),dir=process.argv[2],partial=process.argv.includes('--partial');
const id=s=>a.S.identity(s),WORK=new Set(['D','E','N','MID']);
const dp=flags=>{const values=[0];for(let d=0;d<flags.length;d++)values.push(Math.max(values[d],values[Math.max(0,d-6)]+flags[d]));return values.at(-1);};
const periods=[];
for(let n=1;n<=7;n++){
 const f=path.join(dir,'4week-period-'+n+'-final.json');if(!fs.existsSync(f))break;
 periods.push(JSON.parse(fs.readFileSync(f)));
}
assert(periods.length>0,'at least one adopted period');if(!partial)assert.equal(periods.length,7);
const checkpoint=JSON.parse(fs.readFileSync(path.join(dir,'4week-checkpoint.json')));
assert.equal(checkpoint.reports.length,periods.length,'complete checkpoint and adopted files agree');
assert.equal(checkpoint.ledger.periods.length,periods.length);
periods.forEach((v,p)=>assert.deepEqual(checkpoint.ledger.periods[p].actual,v.result.matrix,'adopted matrix equals recorded simulated actual'));
const dates=periods.flatMap(p=>p.input.dates.map(t=>t.iso)),staff=periods[0].input.staff.map(s=>({id:id(s),name:s.name,periods:[],flags:[],matrix:[]})),reports=[];
for(const [p,v] of periods.entries()){
 const x=v.input,m=v.result.matrix,errors=a.E.validate(x,m).filter(e=>e.level==='error'),fair=a.F.analyse(x,m),spread=a.B.report(x,m),weekend=a.Weekend.report(x,m);
 assert.equal(errors.length,0);assert.equal(fair.breaches.length,0);assert(weekend.currentGap<=2);assert.equal(spread.score[0],0);
 const current=[];
 for(const [i,s] of x.staff.entries()){
  const r=staff.find(r=>r.id===id(s)),before=s.previousShifts||[],full=[...before,...m[i]],flags=[];let seven=0,peak=0;
  if(p){const old=periods[p-1],j=old.input.staff.findIndex(t=>id(t)===id(s));assert.deepEqual(json(before),old.result.matrix[j].slice(-14));}
  for(let end=0;end<m[i].length;end++){
   const at=before.length+end,block=full.slice(Math.max(0,at-6),at+1),known=block.length===7&&!block.some(v=>v==null||v==='DISPATCH');
   const work=block.filter(v=>WORK.has(v)).length;peak=Math.max(peak,work);seven+=known&&work===7;
   const active=Array.from({length:Math.min(7,end+1)},(_,j)=>end-j);
   const excluded=s.isDispatch||active.every(d=>a.T.trainee(x,s,d)||['MATERNITY','PARENTAL'].includes(m[i][d]));
   flags.push(Number(known&&!excluded&&work>=6));
  }
  assert.equal(seven,0,'no seven workdays for any employee');
  const episodes=dp(flags);assert.equal(episodes,spread.rows[i].episodes.length);assert.equal(flags.reduce((n,v)=>n+v,0),spread.rows[i].restWindows.length);
  r.flags.push(...flags);r.matrix.push(...m[i]);r.periods.push(episodes);current.push(episodes);
 }
 const boundary={checked:false,errors:[],pending:[]};
 if(periods[p+1]){
  const nx=json(x),next=periods[p+1];
  nx.staff.forEach(s=>{const j=next.input.staff.findIndex(t=>id(t)===id(s));s.nextShifts=json(next.result.matrix[j].slice(0,7));s.nextShiftTimes=json(next.input.rules.shiftTimes);});
  // Future LEAVE codes need their recorded provenance for automatic-rest caps.
  nx.surplusHistory.periods.push({status:'actual',start:next.input.dates[0].iso,end:next.input.dates.at(-1).iso,
   input:json(next.input),plan:json(next.input.surplusPlan),actual:json(next.result.matrix),actualGrants:json(next.input.surplusPlan.grants)});
  boundary.checked=true;boundary.errors=a.E.validate(nx,m).filter(e=>e.level==='error');assert.equal(boundary.errors.length,0,'known next-period recovery');
  assert.equal(a.B.report(nx,m).score[0],0,'night concentration across known next-period boundary');
 }else boundary.pending=a.E.validate(x,m).filter(e=>e.code==='N_RECOVERY_PENDING');
 reports.push({period:p+1,start:x.dates[0].iso,end:x.dates.at(-1).iso,mode:x.rules.surplus.mode,
  distribution:[0,1,2,3,4].map(n=>current.filter(c=>c===n).length),repeated:current.filter(c=>c>=2).length,
  episodes:current.reduce((n,v)=>n+v,0),nightConcentration:spread.score[0],weekend:weekend.currentGap,
  rollingWeekend:weekend.rollingGap,hardErrors:errors.length,fairnessBreaches:fair.breaches.length,boundary,
  attempts:v.report.attempt,seed:v.report.seed,ms:v.report.ms});
}
for(const r of staff){
 r.total=dp(r.flags);r.sumPeriodCounts=r.periods.reduce((a,b)=>a+b,0);
 r.rolling28=r.flags.map((_,d)=>dp(r.flags.slice(Math.max(0,d-27),d+1)));
 r.rolling28Max=Math.max(...r.rolling28);r.repeatedPeriods=r.periods.filter(n=>n>=2).length;
 r.periods.forEach((n,p)=>assert.equal(n,r.rolling28[p*28+27]));
 const first=periods[0].input.staff.find(s=>id(s)===r.id),full=[...(first.previousShifts||[]),...r.matrix],offset=(first.previousShifts||[]).length;
 let run=0,maxRun=0,maxSeven=0;
 for(let d=0;d<full.length;d++){run=WORK.has(full[d])?run+1:0;if(d>=offset){maxRun=Math.max(maxRun,run);const block=full.slice(Math.max(0,d-6),d+1);if(block.length===7&&!block.some(v=>v==null||v==='DISPATCH'))maxSeven=Math.max(maxSeven,block.filter(v=>WORK.has(v)).length);}}
 r.maxConsecutiveWork=maxRun;r.maxWorkInSeven=maxSeven;assert(maxSeven<7);assert(maxRun<=5);
 delete r.flags;delete r.matrix;
}
const summary={version:'v0.12.4-recovery.1',status:periods.length===7?'complete':'partial',
 htmlSHA256:crypto.createHash('sha256').update(html).digest('hex'),periods:reports,staff,
 totals:{repeatedStaffPeriods:reports.reduce((n,p)=>n+p.repeated,0),sumPeriodEpisodes:reports.reduce((n,p)=>n+p.episodes,0),
 wholeSpanEpisodes:staff.reduce((n,r)=>n+r.total,0),maxPersonalEpisodes:Math.max(...staff.map(r=>r.total)),
 rolling28Max:Math.max(...staff.map(r=>r.rolling28Max)),maxConsecutiveWork:Math.max(...staff.map(r=>r.maxConsecutiveWork)),
 maxWorkInSeven:Math.max(...staff.map(r=>r.maxWorkInSeven)),checkedBoundaries:reports.filter(r=>r.boundary.checked).length},
 start:dates[0],end:dates.at(-1),days:dates.length,
 limitations:['Reconstructed build, not original v0.12.4 source or the lost CP-SAT experiment.',
 'Simulated actual history equals the adopted roster. No invented future shifts.',
 'Last-period recovery requires checking the following roster when available.',
 'Per-period non-overlapping counts can sum differently from whole-span non-overlapping counts.']};
fs.writeFileSync(path.join(dir,'quality-audit.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify({status:summary.status,periods:reports.length,...summary.totals}));
