const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {domains,json}=require('./helpers.cjs'),a=domains(),source=process.argv[2],out=process.argv[3];fs.mkdirSync(out,{recursive:true});
const brief=(x,m)=>{const q=a.Recovery.current(x,m);return {hard:q.issues.filter(e=>e.level==='error').length,fair:q.fair.breaches.length,
 repeated:q.spread.repeatedStaff,episodes:q.spread.independentWindows,windows:q.spread.rows.reduce((n,r)=>n+r.restWindows.length,0),
 night:q.spread.score[0],weekend:q.weekend.currentGap,rollingWeekend:q.weekend.rollingGap};};
(async()=>{const summary=[];
 for(let n=1;n<=7;n++){
  const v=JSON.parse(fs.readFileSync(path.join(source,`4week-period-${n}-final.json`))),x=json(v.input);
  delete x.surplusPlan.decision;delete x.surplusPlan.accepted;
  const before=brief(x,v.result.matrix),q=a.Recovery.current(x,v.result.matrix),frozen=JSON.stringify(x);
  let r=await a.Rebuild.improve(x,v.result,{maxMs:3000});r=await a.Future.improve(x,r,{maxMs:1500});
  const after=brief(x,r.matrix);assert.equal(JSON.stringify(x),frozen);
  assert.equal(after.hard,0);assert.equal(after.fair,0);assert.equal(after.night,0);
  assert(after.episodes<=before.episodes);assert(after.repeated<=before.repeated);
  assert(a.Recovery.noWorse(q.metrics,a.Recovery.current(x,r.matrix).metrics));
  assert.equal(a.Recovery.floorBlockers(x,r.matrix).length,0);
  for(const [i,s] of x.staff.entries())for(let d=0;d<x.dates.length;d++){
   if(!['D','E','N','OFF'].includes(v.result.matrix[i][d]))assert.equal(r.matrix[i][d],v.result.matrix[i][d]);
   const prev=s.previousShifts||[],all=[...prev,...r.matrix[i]],end=prev.length+d,b=all.slice(Math.max(0,end-6),end+1);
   if(b.length===7)assert(b.filter(sh=>['D','E','N','MID'].includes(sh)).length<7);
  }
  const report={n,before,after,rest:r.restRebuild,future:r.futureBalance};summary.push(report);
  fs.writeFileSync(path.join(out,`case-${n}.json`),JSON.stringify({input:x,result:r,report}));
  fs.writeFileSync(path.join(out,'summary.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify({n,before,after,moves:r.restRebuild?.moves,blocked:r.restRebuild?.boostDiagnostics}));
 }
})().catch(e=>{console.error(e.stack);process.exit(1)});
