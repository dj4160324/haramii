const fs=require('node:fs'),assert=require('node:assert/strict');
const {domains,fixture,json}=require('./helpers.cjs'),a=domains(),out=process.argv[2];fs.mkdirSync(out,{recursive:true});
(async()=>{
 const x={...fixture({start:'2026-11-02',days:14,n:12,seniors:6,quota:{D:2,E:1,N:1},realistic:true,minOff:4}),
  detailPolicy:1,pregnancyHolidayPolicy:1,restPolicy:1,automaticRestPolicy:1,weekendPolicy:2,nightBalancePolicy:1,
  restSpreadPolicy:2,continuityPolicy:1,futureBalancePolicy:1,restRebuildPolicy:1};
 x.rules.surplus.annual=1;x.rules.maxOff=3;x.rules.noNOD=true;x.rules.noNOE=true;x.rules.leaveOffLimit=1;
 x.staff.forEach(s=>s.annualConsent={period:a.Annual.period(x),status:'YES'});
 const history=JSON.stringify([x.staff,x.surplusHistory,x.workloadHistory,x.preferenceHistory]);
 let last=0;const started=Date.now();
 const r=await a.E.generate(x,{attempts:8,seed:20261103,maxBlockMs:2000,onProgress:()=>{if(Date.now()-last>15000){console.log('generating',Date.now()-started);last=Date.now();}}});
 const q=a.Recovery.current(x,r.matrix),report={hard:q.issues.filter(e=>e.level==='error'),fair:q.fair.breaches,
  night:q.spread.score[0],weekend:q.weekend.currentGap,repeated:q.spread.repeatedStaff,episodes:q.spread.independentWindows,
  restRebuild:r.restRebuild,future:r.futureBalance,ms:Date.now()-started};
 fs.writeFileSync(out+'/generation.json',JSON.stringify({input:x,result:r,report}));
 assert.equal(report.hard.length,0);assert.equal(report.fair.length,0);assert.equal(report.night,0);assert(report.weekend<=2);
 assert.equal(r.restRebuild.version,2);assert(r.futureBalance);assert.equal(a.Recovery.floorBlockers(x,r.matrix).length,0);
 assert.equal(JSON.stringify([x.staff,x.surplusHistory,x.workloadHistory,x.preferenceHistory]),history);
 console.log(JSON.stringify(report));
})().catch(e=>{console.error(e.stack);process.exit(1)});
