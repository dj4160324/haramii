const assert=require('node:assert/strict');
const {domains,fixture,result,json}=require('./helpers.cjs'),a=domains();
(async()=>{
 const x={...fixture({days:14,n:1,seniors:0,quota:{D:0,E:0,N:0},minOff:2}),restSpreadPolicy:2,weekendPolicy:2,nightBalancePolicy:1},m=['D D D OFF D D D D D OFF D D D D'.split(' ')];
 x.rules.maxWork=5;x.rules.surplus={enabled:true,mode:'OFF',annual:1};x.dates.forEach((t,d)=>x.staff[0].reqShiftsMap[t.date]=m[0][d]);
 let r=await a.B.improve(x,result(a,x,m));r=await a.S.apply(x,r,{decision:'KEEP'});
 const ui=require('./ui-harness.cjs')();ui.ctx.inputFixture=json(x);ui.ctx.resultFixture=json(r);
 ui.run('lastInput=inputFixture;lastResult=resultFixture;globalStaffData=lastInput.staff;dirty=false;generating=false;renderAll()');
 assert.match(ui.el('triageSummary').textContent,/N·휴무 배치 확인 1명/);assert.equal(ui.el('metricErrors').textContent,'0묶음');
 ui.run("selectDiagnosticFilter('review')");assert.match(ui.el('diagnosticList').innerHTML,/중복 없는 구간 2회/);assert.equal(ui.el('confirmScheduleBtn').disabled,false);
 const before=json(ui.run('lastResult.matrix'));ui.run('audit()');assert.deepEqual(json(ui.run('lastResult.matrix')),before);
 let download;ui.ctx.URL={createObjectURL:b=>{download=b;return 'blob:rest-balance'},revokeObjectURL(){}};
 ui.run('saveFile()');const text=await download.text(),data=JSON.parse(text);assert.equal(data.input.restSpreadPolicy,2);
 ui.ctx.testFile={size:text.length,text:async()=>text};await ui.run('loadFile(testFile)');assert.equal(ui.run('lastInput.restSpreadPolicy'),2);assert.deepEqual(json(ui.run('lastResult.matrix')),before);assert.equal(ui.el('confirmScheduleBtn').disabled,false);
 ui.run('confirmSchedule()');assert.equal(ui.run('surplusHistory.periods.length'),1);assert.equal(ui.run('surplusHistory.periods[0].status'),'planned');
 const saved=json(ui.run('surplusHistory'));assert.equal(saved.periods[0].input.restSpreadPolicy,2);
 const invalid=json(data);invalid.input.restSpreadPolicy=999;const bad=JSON.stringify(invalid);ui.ctx.badFile={size:bad.length,text:async()=>bad};await ui.run('loadFile(badFile)');assert.equal(ui.run('lastInput.restSpreadPolicy'),2);assert.deepEqual(json(ui.run('lastResult.matrix')),before);assert(ui.notices.some(t=>t.includes('휴식 분산 기준')));
 console.log('PASS 반복 2회 경고·비차단·확정·저장/복원·잘못된 정책 입력 보호');
})().catch(e=>{console.error(e);process.exit(1)});
