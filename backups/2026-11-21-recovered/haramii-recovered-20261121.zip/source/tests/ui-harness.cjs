/* Shared interaction harness. Browser layout is checked separately. */
module.exports=function createUIHarness(){
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const {script,fixture,json}=require('./helpers.cjs');
const elements=new Map(),notices=[];
const decode=s=>String(s).replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
function hydrate(html){
 for(const match of html.matchAll(/<(input|textarea|select|section|p|div)\b([^>]*\bid="([^"]+)"[^>]*)>([\s\S]*?)(?=<\/(?:textarea|select)>|$)/g)){
  const [whole,tag,attrs,id]=match,node=new Element({id,tag,hidden:/\bhidden\b/.test(attrs)}),value=attrs.match(/\bvalue="([^"]*)"/);
  if(value)node.value=decode(value[1]);node.type=attrs.match(/\btype="([^"]*)"/)?.[1]||'';
  if(tag==='select'){const body=match[4].split('</select>')[0],opts=[...body.matchAll(/<option value="([^"]*)"([^>]*)>/g)],selected=opts.find(x=>/selected/.test(x[2]))||opts[0];node.value=decode(selected?.[1]||'');}
  if(tag==='textarea')node.value=decode(match[4].split('</textarea>')[0]);
  elements.set(id,node);
 }
 // IDs on wrapper divs may precede inputs; independently discover all controls.
 for(const m of html.matchAll(/<(input|select|textarea)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){
  const [,tag,attrs,id]=m;let n=elements.get(id)||new Element({id,tag});n.value=decode(attrs.match(/\bvalue="([^"]*)"/)?.[1]||'');n.type=attrs.match(/\btype="([^"]*)"/)?.[1]||'';
  const after=html.slice(m.index+m[0].length);if(tag==='select'){const opts=[...after.split('</select>')[0].matchAll(/<option value="([^"]*)"([^>]*)>/g)];n.value=decode((opts.find(x=>/selected/.test(x[2]))||opts[0])?.[1]||'');}if(tag==='textarea')n.value=decode(after.split('</textarea>')[0]);elements.set(id,n);
 }
 for(const m of html.matchAll(/<(p|div|section)\b[^>]*\bid="([^"]+)"[^>]*>/g))if(!elements.has(m[2]))elements.set(m[2],new Element({id:m[2],tag:m[1]}));
}
class Element{
 constructor(x={}){Object.assign(this,{id:'',tag:'div',type:'',value:'',checked:false,hidden:false,disabled:false,text:'',input:false},x);this.tagName=this.tag.toUpperCase();this.textContent=this.text;this._html='';this.style={};this.dataset={};this.attrs={};this.events={};this.classList={add(){},remove(){},toggle(){},contains(){return false}};}
 set innerHTML(s){this._html=s;hydrate(s)}get innerHTML(){return this._html}
 insertAdjacentHTML(_,s){this._html+=s;hydrate(s)}appendChild(){}addEventListener(k,f){(this.events[k]??=[]).push(f)}setAttribute(k,v){this.attrs[k]=v}getAttribute(k){return this.attrs[k]}closest(sel){return sel==='#appInputs'&&this.input?elements.get('appInputs'):null}querySelectorAll(){return []}querySelector(){return null}showModal(){this.open=true}close(){if(this.open){this.open=false;for(const f of this.events.close||[])f();}}scrollIntoView(){}focus(){}click(){}remove(){}
}
for(const d of JSON.parse(fs.readFileSync(__dirname+'/dom-nodes.json','utf8')))elements.set(d.id,new Element(d));
const radio=new Element({value:'MONTH',checked:true}),body=new Element(),document={body,activeElement:body,getElementById:id=>elements.get(id)||null,addEventListener(){},createElement:()=>new Element(),querySelector(sel){if(sel.includes('schType'))return radio;if(sel==='#staffEditTable tbody')return body;return null;},querySelectorAll(sel){if(sel.includes('#appInputs')&&sel.includes('[id]'))return [...elements.values()].filter(n=>n.input&&['INPUT','SELECT','TEXTAREA'].includes(n.tagName));if(sel==='[name="schType"]')return [radio];return [];}};
const ctx={console,setTimeout,clearTimeout,Date,Intl,performance,structuredClone,Blob,URL,document,alert:x=>notices.push(x),confirm:()=>true,requestAnimationFrame:cb=>cb(),innerWidth:1200};ctx.window=ctx;ctx.addEventListener=()=>{};ctx.scrollTo=()=>{};vm.createContext(ctx);vm.runInContext(script.replace('initApp();initUX();',''),ctx);const run=s=>vm.runInContext(s,ctx),el=id=>elements.get(id),set=(id,value)=>{assert(el(id),'missing rendered control '+id);el(id).value=value;};ctx.showToast=x=>notices.push(x);

return {ctx,run,el,set,notices,Element,elements,document};
};
